-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2023 at 06:46 AM
-- Server version: 5.7.23-23
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kcgwebse_omartyDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `AdsAndOffers`
--

CREATE TABLE `AdsAndOffers` (
  `ID` int(11) NOT NULL,
  `Tittle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Body` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Owner` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `StartDate` timestamp NULL DEFAULT NULL,
  `EndDate` timestamp NULL DEFAULT NULL,
  `StatusID` int(11) DEFAULT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovernateID` int(11) DEFAULT NULL,
  `CityID` int(11) DEFAULT NULL,
  `RegionID` int(11) DEFAULT NULL,
  `CompoundID` int(11) DEFAULT NULL,
  `StreetID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `AdsAndOffers`
--

INSERT INTO `AdsAndOffers` (`ID`, `Tittle`, `Body`, `Owner`, `Image`, `StartDate`, `EndDate`, `StatusID`, `UserID`, `ApartmentID`, `BlockID`, `CountryID`, `GovernateID`, `CityID`, `RegionID`, `CompoundID`, `StreetID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'FirstTestOffers', 'FirstTestOffersFirstTestOffersFirstTestOffers', 'MuhammadWaheed', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-08 03:24:05', NULL, NULL),
(2, 'FirstTestOffers', 'FirstTestOffersFirstTestOffersFirstTestOffers', 'MuhammadWaheed', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-08 03:55:06', NULL, NULL),
(3, 'FirstTestOffers', 'FirstTestOffersFirstTestOffersFirstTestOffers', 'MuhammadWaheed531', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-23 10:10:54', NULL, NULL),
(4, 'FirstTestOffers', 'FirstTestOffersFirstTestOffersFirstTestOffers', 'MuhammadWaheed531', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-23 10:11:41', NULL, NULL),
(5, 'FirstTestOffers', 'FirstTestOffersFirstTestOffersFirstTestOffers', 'MuhammadWaheed531', 'MTYzZjcyMDZlNGQ4Y2E0LjY5MDMxNzY1.png', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-02-23 10:14:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Apartment`
--

CREATE TABLE `Apartment` (
  `ID` int(11) NOT NULL,
  `FloorNum` int(11) DEFAULT NULL,
  `ApartmentNumber` int(11) DEFAULT NULL,
  `balance` int(11) NOT NULL,
  `Fees` int(11) NOT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `StatusID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL,
  `ApartmentName` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Apartment`
--

INSERT INTO `Apartment` (`ID`, `FloorNum`, `ApartmentNumber`, `balance`, `Fees`, `BlockID`, `StatusID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`, `ApartmentName`) VALUES
(2, 1, 1, 0, 0, 1, 2, NULL, NULL, 1, 'W1'),
(21, 1, 1, 0, 0, 1, 2, '2023-02-27 22:07:22', '2023-03-28 10:58:36', NULL, 'W1'),
(73, 5, 20, 0, 0, 70, 2, '2023-02-19 11:07:37', NULL, NULL, NULL),
(74, 5, 20, 0, 0, 71, 2, '2023-02-22 02:16:18', NULL, NULL, NULL),
(75, 1, 1, 0, 0, 1, 2, '2023-02-22 02:52:39', '2023-03-28 10:59:26', 26, 'W1'),
(76, 1, 1, 0, 0, 72, 2, '2023-02-22 04:55:53', NULL, NULL, NULL),
(77, 5, 20, 0, 0, 73, 2, '2023-02-22 05:09:24', NULL, NULL, NULL),
(78, 1, 1, 0, 0, 74, 2, '2023-02-22 05:13:44', NULL, NULL, NULL),
(79, 1, 1, 0, 0, 75, 2, '2023-02-23 12:19:07', NULL, NULL, NULL),
(80, 1, 1, 0, 0, 76, 2, '2023-02-23 02:37:20', NULL, NULL, NULL),
(81, 1, 1, 0, 0, 77, 2, '2023-02-23 02:52:24', NULL, NULL, NULL),
(82, 5, 107, 0, 0, 78, 2, '2023-02-27 02:42:37', NULL, NULL, NULL),
(83, 5, 20, 0, 0, 84, 2, '2023-03-06 06:48:46', NULL, NULL, NULL),
(84, 3, 8, 0, 0, 90, 2, '2023-03-07 05:41:32', NULL, NULL, NULL),
(85, 3, 2, 0, 0, 91, 2, '2023-03-09 10:12:12', NULL, NULL, NULL),
(86, 5, 20, 0, 0, 92, 2, '2023-03-09 03:25:41', NULL, NULL, NULL),
(87, 16, 3, 0, 0, 93, 2, '2023-03-10 10:53:35', NULL, NULL, NULL),
(88, 13, 27, 0, 0, 94, 2, '2023-03-13 07:43:29', NULL, NULL, NULL),
(89, 6, 8, 0, 0, 95, 2, '2023-03-15 05:11:55', NULL, NULL, NULL),
(90, 1, 1, 0, 0, 96, 2, '2023-03-27 05:15:35', NULL, NULL, 'A1'),
(91, NULL, 2, 0, 0, 96, 2, '2023-03-27 17:15:35', '2023-03-28 13:17:48', NULL, '4A'),
(92, NULL, 3, 0, 0, 96, 1, '2023-03-27 17:15:35', '2023-03-28 13:32:45', NULL, '4A'),
(93, NULL, 4, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(94, NULL, 5, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(95, NULL, 6, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(96, NULL, 7, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(97, NULL, 8, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(98, NULL, 9, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(99, NULL, 10, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(100, NULL, 11, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(101, NULL, 12, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(102, NULL, 13, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(103, NULL, 14, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(104, NULL, 15, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(105, NULL, 16, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(106, NULL, 17, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(107, NULL, 18, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(108, NULL, 19, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(109, NULL, 20, 0, 0, 96, NULL, '2023-03-27 17:15:35', NULL, NULL, NULL),
(110, 1, 1, 0, 0, 1, 2, '2023-03-28 13:36:39', NULL, NULL, 'W1'),
(111, 1, 1, 0, 0, 1, 2, '2023-03-28 13:39:00', NULL, NULL, 'W1'),
(112, 1, 1, 0, 0, 1, 2, '2023-03-28 13:40:08', NULL, NULL, 'W1'),
(113, 1, 1, 0, 0, 1, 2, '2023-03-28 14:47:03', NULL, NULL, 'W1'),
(114, 1, 1, 0, 0, 1, 2, '2023-03-28 14:48:26', NULL, NULL, 'W1'),
(115, 1, 1, 0, 0, 1, 2, '2023-03-28 14:51:01', NULL, NULL, 'W1'),
(116, 1, 1, 0, 0, 1, 2, '2023-03-28 14:52:18', NULL, NULL, 'W1'),
(117, 1, 1, 0, 0, 1, 2, '2023-03-28 14:54:33', NULL, NULL, 'W1'),
(118, 1, 1, 0, 0, 1, 2, '2023-03-28 14:55:21', NULL, NULL, 'W1'),
(119, 1, 1, 0, 0, 1, 2, '2023-03-28 14:58:31', NULL, NULL, 'W1'),
(120, 1, 1, 0, 0, 1, 2, '2023-03-28 15:00:11', NULL, NULL, 'W1');

-- --------------------------------------------------------

--
-- Table structure for table `Attendees`
--

CREATE TABLE `Attendees` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `TableName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RecordID` int(11) DEFAULT NULL,
  `Attend` int(11) NOT NULL,
  `Absent` int(11) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Attendees`
--

INSERT INTO `Attendees` (`ID`, `ResidentID`, `ApartmentID`, `BlockID`, `TableName`, `RecordID`, `Attend`, `Absent`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(4, 1, 2, 1, 'Event', 12, 1, 0, '2023-02-28 17:53:00', NULL, NULL),
(5, 1, 2, 1, 'Event', 11, 0, 1, '2023-02-28 17:54:40', '2023-03-01 02:20:03', 1),
(6, 34, 82, 78, 'Event', 29, 1, 0, '2023-02-28 20:41:15', '2023-03-06 12:43:28', 34),
(7, 26, 77, 73, 'Meeting', 23, 0, 1, '2023-03-05 14:29:17', '2023-03-05 14:43:18', 26),
(8, 26, 77, 73, 'Meeting', 21, 1, 0, '2023-03-05 14:29:35', NULL, NULL),
(9, 34, 82, 78, 'Event', 30, 1, 0, '2023-03-06 12:45:56', NULL, NULL),
(10, 1, 2, 1, 'Meeting', 41, 0, 1, '2023-03-07 13:15:33', '2023-03-07 13:15:47', 1),
(11, 1, 2, 1, 'Event', 34, 0, 1, '2023-03-07 13:18:35', '2023-03-07 13:18:45', 1),
(12, 26, 77, 73, 'Meeting', 39, 0, 1, '2023-03-07 14:27:07', '2023-03-09 14:49:03', 26),
(13, 26, 77, 73, 'Event', 25, 0, 1, '2023-03-09 14:08:30', '2023-03-09 14:08:34', 26),
(14, 26, 77, 73, 'Event', 41, 1, 0, '2023-03-09 14:24:09', NULL, NULL),
(15, 34, 82, 78, 'Event', 31, 1, 0, '2023-03-09 18:11:27', NULL, NULL),
(16, 34, 82, 78, 'Meeting', 42, 1, 0, '2023-03-09 21:59:21', '2023-03-15 20:46:50', 34),
(17, 34, 87, 93, 'Event', 45, 1, 0, '2023-03-15 10:19:45', NULL, NULL),
(18, 34, 82, 78, 'Meeting', 44, 0, 1, '2023-03-16 10:00:00', '2023-03-16 10:51:32', 34),
(19, 34, 82, 78, 'Meeting', 43, 0, 1, '2023-03-16 10:51:18', '2023-03-16 10:53:07', 34),
(20, 1, 2, 1, 'Meeting', 67, 1, 0, '2023-05-22 16:20:34', '2023-05-22 16:21:05', 1);

-- --------------------------------------------------------

--
-- Table structure for table `BILL`
--

CREATE TABLE `BILL` (
  `ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BillImage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PaymentID` int(11) DEFAULT NULL,
  `Block` int(11) DEFAULT NULL,
  `Apartment` int(11) DEFAULT NULL,
  `LastBillInBlock` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `BILL`
--

INSERT INTO `BILL` (`ID`, `BillImage`, `Date`, `PaymentID`, `Block`, `Apartment`, `LastBillInBlock`, `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`) VALUES
('B1A2I1', 'MTYzZjE1NTQxNWM3Y2I0LjY3MzA4Nzk0.png', '2023/02/19 12:46:25am', NULL, 1, 2, 0, '2023-02-19 00:46:25', 1, NULL, NULL),
('B1A2I10', 'B1A2I10.pdf', '2023/03/25 05:05:36pm', NULL, 1, 2, 0, '2023-03-25 17:05:36', 1, NULL, NULL),
('B1A2I11', 'B1A2I11.pdf', '2023/03/25 05:08:21pm', NULL, 1, 2, 0, '2023-03-25 17:08:21', 1, NULL, NULL),
('B1A2I12', 'B1A2I12.pdf', '2023/03/25 09:47:01pm', NULL, 1, 2, 0, '2023-03-25 21:47:01', 1, NULL, NULL),
('B1A2I13', 'B1A2I13.pdf', '2023/03/25 09:47:24pm', NULL, 1, 2, 0, '2023-03-25 21:47:24', 1, NULL, NULL),
('B1A2I14', 'B1A2I14.pdf', '2023/03/26 04:32:14pm', NULL, 1, 2, 0, '2023-03-26 16:32:14', 1, NULL, NULL),
('B1A2I15', 'B1A2I15.pdf', '2023/03/26 04:36:26pm', NULL, 1, 2, 0, '2023-03-26 16:36:26', 1, NULL, NULL),
('B1A2I16', 'B1A2I16.pdf', '2023/03/26 04:41:44pm', NULL, 1, 2, 0, '2023-03-26 16:41:44', 1, NULL, NULL),
('B1A2I17', 'B1A2I17.pdf', '2023/03/26 04:44:10pm', NULL, 1, 2, 0, '2023-03-26 16:44:10', 1, NULL, NULL),
('B1A2I18', 'B1A2I18.pdf', '2023/03/26 04:52:11pm', 45, 1, 2, 0, '2023-03-26 16:52:11', 1, NULL, NULL),
('B1A2I19', 'B1A2I19.pdf', '2023/03/26 05:02:05pm', 46, 1, 2, 0, '2023-03-26 17:02:05', 1, NULL, NULL),
('B1A2I2', 'MTYzZjE1NTQzMWQ4ZWYwLjUwNDU0NTg2.png', '2023/02/19 12:46:27am', NULL, 1, 2, 0, '2023-02-19 00:46:27', 1, NULL, NULL),
('B1A2I20', 'B1A2I20.pdf', '2023/03/26 05:09:52pm', 47, 1, 2, 0, '2023-03-26 17:09:52', 1, NULL, NULL),
('B1A2I21', 'B1A2I21.pdf', '2023/03/26 05:12:38pm', 48, 1, 2, 0, '2023-03-26 17:12:38', 1, NULL, NULL),
('B1A2I22', 'B1A2I22.pdf', '2023/03/26 05:16:32pm', 49, 1, 2, 0, '2023-03-26 17:16:32', 1, NULL, NULL),
('B1A2I23', 'B1A2I23.pdf', '2023/03/26 05:29:42pm', 50, 1, 2, 0, '2023-03-26 17:29:42', 1, NULL, NULL),
('B1A2I24', 'B1A2I24.pdf', '2023/03/26 05:33:29pm', 51, 1, 2, 0, '2023-03-26 17:33:29', 1, NULL, NULL),
('B1A2I25', 'B1A2I25.pdf', '2023/03/26 05:37:00pm', 52, 1, 2, 1, '2023-03-26 17:37:00', 1, NULL, NULL),
('B1A2I3', 'MTYzZjE1NTQ0YWNkMWY2Ljk1NTY5MDUx.png', '2023/02/19 12:46:28am', NULL, 1, 2, 0, '2023-02-19 00:46:28', 1, NULL, NULL),
('B1A2I4', NULL, '2023/03/22 05:38:39pm', NULL, 1, 2, 0, '2023-03-22 17:38:39', 1, NULL, NULL),
('B1A2I5', 'B1A2I5.pdf', '2023/03/22 08:44:31pm', NULL, 1, 2, 0, '2023-03-22 20:44:31', 1, NULL, NULL),
('B1A2I6', 'B1A2I6.pdf', '2023/03/22 08:46:47pm', NULL, 1, 2, 0, '2023-03-22 20:46:47', 1, NULL, NULL),
('B1A2I7', 'B1A2I7.pdf', '2023/03/22 08:48:39pm', NULL, 1, 2, 0, '2023-03-22 20:48:39', 1, NULL, NULL),
('B1A2I8', 'B1A2I8.pdf', '2023/03/22 08:50:10pm', NULL, 1, 2, 0, '2023-03-22 20:50:10', 1, NULL, NULL),
('B1A2I9', 'B1A2I9.pdf', '2023/03/22 08:51:05pm', NULL, 1, 2, 0, '2023-03-22 20:51:05', 1, NULL, NULL),
('B92A86I12', 'B92A86I12.pdf', '2023/03/22 07:51:16pm', 28, 92, 86, 0, '2023-03-22 19:51:16', 1, NULL, NULL),
('B92A86I13', 'B92A86I13.pdf', '2023/03/22 08:06:21pm', 28, 92, 86, 1, '2023-03-22 20:06:21', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Block`
--

CREATE TABLE `Block` (
  `ID` int(11) NOT NULL,
  `BlockNum` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumberOfAppartments` int(11) DEFAULT NULL,
  `NumberOfFloors` int(11) NOT NULL,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Balance` int(11) DEFAULT NULL,
  `Fees` int(11) DEFAULT NULL,
  `Longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountryID` int(11) NOT NULL,
  `GovernateID` int(11) NOT NULL,
  `CityID` int(11) NOT NULL,
  `RegionID` int(11) NOT NULL,
  `CompoundID` int(11) NOT NULL,
  `StreetID` int(11) NOT NULL,
  `StatusID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL,
  `BlockName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Block`
--

INSERT INTO `Block` (`ID`, `BlockNum`, `NumberOfAppartments`, `NumberOfFloors`, `Image`, `Password`, `Balance`, `Fees`, `Longitude`, `Latitude`, `CountryID`, `GovernateID`, `CityID`, `RegionID`, `CompoundID`, `StreetID`, `StatusID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`, `BlockName`) VALUES
(1, '117ز', 20, 0, '', NULL, 12334, 0, '', '', 67, 1, 10, 8, 1, 3, 2, NULL, '2023-05-23 14:42:41', 1, 'WaheedBlock'),
(57, '1', 20, 5, '', '', 0, 0, '', '', 67, 1, 10, 8, 5, 16, 2, '2023-02-14 02:32:27', NULL, NULL, NULL),
(58, '1', 20, 5, '', '', 0, 0, '', '', 67, 1, 12, 10, 5, 17, 2, '2023-02-14 02:37:59', NULL, NULL, NULL),
(59, '1', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 44, 2, '2023-02-15 06:15:41', NULL, NULL, NULL),
(60, '1', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:19:50', NULL, NULL, NULL),
(61, '2', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:23:15', NULL, NULL, NULL),
(62, '3', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:28:47', NULL, NULL, NULL),
(63, '4', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:31:53', NULL, NULL, NULL),
(64, '5', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:34:54', NULL, NULL, NULL),
(65, '6', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:35:46', NULL, NULL, NULL),
(66, '7', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-15 06:44:32', NULL, NULL, NULL),
(67, '8', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-19 11:03:03', NULL, NULL, NULL),
(68, '9', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-19 11:04:12', NULL, NULL, NULL),
(69, '10', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-19 11:06:24', NULL, NULL, NULL),
(70, '11', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 45, 2, '2023-02-19 11:07:37', NULL, NULL, NULL),
(71, '12', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 46, 2, '2023-02-22 02:16:18', NULL, NULL, NULL),
(72, '8', 3, 3, '', '', 0, 0, '30.739819686859846', '30.572716296602188', 67, 3, 6, 5, 29, 47, 2, '2023-02-22 04:55:53', NULL, NULL, NULL),
(73, '13', 20, 5, '', '', 0, 0, '', '', 67, 3, 37, 35, 1, 46, 2, '2023-02-22 05:09:24', NULL, NULL, NULL),
(74, '9', 3, 3, '', '', 0, 0, '30.739816334098577', '30.572715719267194', 67, 10, 6, 5, 1, 47, 2, '2023-02-22 05:13:44', NULL, NULL, NULL),
(75, '7', 5, 5, '', '', 0, 0, '30.739812646061182', '30.57271600793469', 67, 10, 6, 5, 1, 47, 2, '2023-02-23 12:19:07', NULL, NULL, NULL),
(76, 'Hi', 10, 10, '', '', 0, 0, '-122.0839218981564', '37.42209333893312', 240, 1, 38, 36, 1, 48, 2, '2023-02-23 02:37:20', NULL, NULL, NULL),
(77, '8', 10, 10, '', '', 0, 0, '-122.0839218981564', '37.42209333893312', 240, 1, 38, 36, 1, 47, 2, '2023-02-23 02:52:24', NULL, NULL, NULL),
(78, '11', 20, 5, '', '', 0, 0, '31.096944753080606', '29.980251680180558', 67, 1, 31, 29, 1, 2, 2, '2023-02-27 02:42:37', NULL, NULL, NULL),
(84, '13', 20, 5, '', '', 0, 0, '0', '0', 67, 1, 10, 8, 1, 9, 2, '2023-03-06 06:48:46', NULL, NULL, NULL),
(90, 'السلام ', 3, 2, '', '', 0, 0, '31.09695279970765', '29.980364628809408', 10, 1, 8, 4, 1, 9, 2, '2023-03-07 05:41:32', NULL, NULL, NULL),
(91, 'السلام ', 8, 8, '', '', 0, 0, '31.666908636689186', '28.599388983087316', 67, 1, 8, 43, 1, 9, 2, '2023-03-09 10:12:12', NULL, NULL, NULL),
(92, '1', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 1, 10, 8, 1, 9, 2, '2023-03-09 03:25:41', NULL, NULL, 'عمارة وحيد'),
(93, '3', 13, 27, 'Default.jpg', '', 0, 0, '31.196433249861002', '30.055450647515705', 67, 1, 46, 44, 2, 2, 2, '2023-03-10 10:53:35', NULL, NULL, ''),
(94, 'برج الحمد', 30, 16, 'Default.jpg', '', 0, 0, '31.196427550166845', '30.05543236442857', 67, 1, 46, 44, 3, 13, 2, '2023-03-13 07:43:29', NULL, NULL, ''),
(95, 'الفردوس', 15, 6, 'Default.jpg', '', 0, 0, '30.885023083537817', '28.827399560396977', 67, 20, 47, 45, 1, 2, 2, '2023-03-15 05:11:55', NULL, NULL, ''),
(96, 'عمارة وحيد2', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 1, 10, 8, 1, 9, 2, '2023-03-27 05:15:35', NULL, NULL, 'عمارة وحيد2'),
(97, 'عمارة وحيد2', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 2, 10, 8, 1, 9, 2, '2023-05-26 04:49:23', NULL, NULL, 'عمارة وحيد2'),
(98, 'عمارة وحيد1', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 2, 10, 8, 1, 9, 2, '2023-05-26 05:11:18', NULL, NULL, 'عمارة وحيد1'),
(99, 'عمارة وحيد3', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 2, 10, 8, 1, 9, 2, '2023-05-26 05:12:42', NULL, NULL, 'عمارة وحيد3'),
(100, 'عمارة وحيد1', 20, 5, 'Default.jpg', '', 0, 0, '0', '0', 67, 1, 1, 8, 1, 8, 2, '2023-05-26 05:23:16', NULL, NULL, 'عمارة وحيد1');

-- --------------------------------------------------------

--
-- Table structure for table `BlockManager`
--

CREATE TABLE `BlockManager` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Lname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfVoting` int(11) DEFAULT NULL,
  `NumOfDecisons` int(11) DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `BlockPaymentMethod`
--

CREATE TABLE `BlockPaymentMethod` (
  `ID` int(11) NOT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `PaymentMethodName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PaymentMethod` text COLLATE utf8_unicode_ci,
  `CreatedAt` datetime DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `BlockPaymentMethod`
--

INSERT INTO `BlockPaymentMethod` (`ID`, `BlockID`, `PaymentMethodName`, `PaymentMethod`, `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, 'Vodafone Cash', '01014584099, 01144338618', '2023-03-05 01:22:05', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Cashier`
--

CREATE TABLE `Cashier` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Lname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Chat`
--

CREATE TABLE `Chat` (
  `ID` int(11) NOT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `UserIDs` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `City`
--

CREATE TABLE `City` (
  `ID` int(11) NOT NULL,
  `Name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfRegions` int(11) DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovID` int(11) DEFAULT NULL,
  `NameEN` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `City`
--

INSERT INTO `City` (`ID`, `Name`, `NumOfRegions`, `CountryID`, `GovID`, `NameEN`) VALUES
(1, NULL, NULL, NULL, NULL, NULL),
(2, 'EL-Haram', 10, 1, 1, NULL),
(3, 'Chelsea', 10, 2, 2, NULL),
(4, 'القاهرة الجديدة', 20, 2, 4, NULL),
(5, '6 اكتوبر', 20, 2, 2, NULL),
(6, 'Omar Makram', NULL, 67, 8, NULL),
(7, 'Ahmed Oraby', NULL, 67, 8, NULL),
(8, 'الهرم', NULL, 67, 17, NULL),
(9, 'القاهرة', NULL, 67, 7, NULL),
(10, 'اوسيم', NULL, 67, 16, NULL),
(11, 'اوسيم', NULL, 67, 7, NULL),
(12, 'test', NULL, 67, 18, NULL),
(31, 'test1', NULL, 67, 36, NULL),
(32, 'test2', NULL, 67, 37, NULL),
(33, 'test3', NULL, 67, 38, NULL),
(34, 'test4', NULL, 67, 39, NULL),
(35, 'test5', NULL, 67, 40, NULL),
(36, 'test6', NULL, 67, 41, NULL),
(37, 'ابوقير', NULL, 67, 42, NULL),
(38, 'Mountain View', NULL, 240, 43, NULL),
(46, 'Gazirat Mit Oqbah', NULL, 67, 2, NULL),
(47, 'Madinet Al Fashn', NULL, 67, 48, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Comment`
--

CREATE TABLE `Comment` (
  `ID` int(11) NOT NULL,
  `CommentText` text COLLATE utf8_unicode_ci,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `OriginalPostID` int(11) DEFAULT NULL,
  `OriginalPostTable` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Likes` int(11) NOT NULL,
  `DisLikes` int(11) NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Comment`
--

INSERT INTO `Comment` (`ID`, `CommentText`, `ResidentID`, `ApartmentID`, `BlockID`, `OriginalPostID`, `OriginalPostTable`, `Likes`, `DisLikes`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'CommentTest1', 1, 2, 1, 1, 'Decision', 1, 1, '2023-02-17 10:11:24', NULL, NULL),
(2, 'commentTest2', 1, 2, 1, 1, 'Decision', 13, 2, '2023-02-20 20:13:42', NULL, NULL),
(3, 'CommentServiceTest1', 1, 2, 1, 1, 'Service', 12, 1, '2023-02-20 22:25:30', NULL, NULL),
(4, 'CommentServiceTest2', 1, 2, 1, 1, 'Service', 12, 0, '2023-02-20 22:27:53', NULL, NULL),
(5, 'CommentTest1', 1, 2, 1, 29, 'Decision', 0, 0, '2023-03-05 08:30:19', NULL, NULL),
(6, 'CommentTest2', 1, 2, 1, 29, 'Decision', 0, 0, '2023-03-05 08:31:32', NULL, NULL),
(7, 'Hossam', 26, 77, 73, 32, 'Meeting', 0, 0, '2023-03-06 02:08:18', NULL, NULL),
(8, 'Hossam', 26, 77, 73, 32, 'Meeting', 0, 0, '2023-03-06 02:08:48', NULL, NULL),
(9, 'Hossam', 26, 77, 73, 32, 'Meeting', 0, 1, '2023-03-06 02:09:11', NULL, NULL),
(10, 'Hossam', 26, 77, 73, 32, 'Meeting', 1, 0, '2023-03-06 02:09:51', NULL, NULL),
(11, 'CommentTest2', 1, 2, 1, 34, 'Decision', 0, 0, '2023-03-06 04:26:13', NULL, NULL),
(12, 'CommentTest2', 1, 2, 1, 34, 'Decision', 0, 0, '2023-03-06 07:19:05', NULL, NULL),
(13, 'Hossam', 26, 77, 73, 2, 'Complaint', 0, 0, '2023-03-06 09:48:50', NULL, NULL),
(14, 'Hossam', 26, 77, 73, 10, 'Complaint', 0, 0, '2023-03-06 09:50:20', NULL, NULL),
(15, 'Comment Test1', 26, 77, 73, 9, 'Complaint', 0, 0, '2023-03-06 09:51:43', NULL, NULL),
(16, 'Hossam Comment Hi Waheed', 26, 77, 73, 9, 'Complaint', 0, 0, '2023-03-06 09:52:01', NULL, NULL),
(17, 'CommentTest2', 1, 2, 1, 11, 'Complaint', 0, 0, '2023-03-06 10:01:15', NULL, NULL),
(18, 'Hi Wahed', 26, 77, 73, 32, 'Decision', 0, 0, '2023-03-07 02:43:14', NULL, NULL),
(19, 'welcome Wahed and update UI', 26, 77, 73, 32, 'Decision', 0, 0, '2023-03-07 03:09:55', NULL, NULL),
(20, 'hi', 26, 77, 73, 32, 'Decision', 0, 0, '2023-03-09 02:33:23', NULL, NULL),
(21, 'Welcome', 26, 75, 1, 1, 'Service', 0, 0, '2023-03-13 05:21:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Complaint`
--

CREATE TABLE `Complaint` (
  `ID` int(11) NOT NULL,
  `Cause` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Complaint` text COLLATE utf8_unicode_ci,
  `Likes` int(11) NOT NULL,
  `DisLikes` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime NOT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Complaint`
--

INSERT INTO `Complaint` (`ID`, `Cause`, `Complaint`, `Likes`, `DisLikes`, `ResidentID`, `BlockID`, `ApartmentID`, `Date`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(4, NULL, 'complaint Test 1 Waheed', 12, 132, 1, 1, 2, '2023-02-17 17:41:57', '2023-02-18 01:41:57', '0000-00-00 00:00:00', NULL),
(5, NULL, 'complaint Test 1 Waheed', 0, 0, 2, 1, 2, '2023-02-17 17:44:01', '2023-02-18 01:44:01', '0000-00-00 00:00:00', NULL),
(6, NULL, 'complaint Test 1 Waheed', 0, 0, 1, 1, 2, NULL, '2023-02-18 01:52:07', '0000-00-00 00:00:00', NULL),
(7, NULL, 'complaint Test 1 Waheed', 0, 0, 1, 1, 2, '2023-02-18 01-54-17am', '2023-02-18 01:54:17', '2023-02-18 00:57:00', NULL),
(8, NULL, 'complaint Test 1 Waheed', 1, 0, 2, 1, 2, '2023-02-18 01-56-06am', '2023-02-18 01:56:42', '0000-00-00 00:00:00', NULL),
(9, NULL, 'Complain', 0, 0, 26, 73, 77, '2023-03-06 08-00-46pm', '2023-03-06 20:00:46', '0000-00-00 00:00:00', NULL),
(10, NULL, 'complaint Test 1 Waheed', 0, 0, 26, 73, 77, '2023-03-06 09-13-11pm', '2023-03-06 21:13:11', '0000-00-00 00:00:00', NULL),
(11, NULL, 'complaint Test 1 Waheed', 0, 1, 1, 1, 2, '2023-03-06 09-41-22pm', '2023-03-06 21:41:22', '0000-00-00 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Compound`
--

CREATE TABLE `Compound` (
  `ID` int(11) NOT NULL,
  `CompundName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfBlocks` int(11) DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovID` int(11) DEFAULT NULL,
  `CityID` int(11) DEFAULT NULL,
  `RegionID` int(11) DEFAULT NULL,
  `CompoundNameEN` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Compound`
--

INSERT INTO `Compound` (`ID`, `CompundName`, `NumOfBlocks`, `CountryID`, `GovID`, `CityID`, `RegionID`, `CompoundNameEN`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'الرحاب', 10000, 2, 4, 4, 2, NULL),
(3, 'Test compound', NULL, 67, 8, 6, 5, NULL),
(5, 'test', NULL, 67, 18, 12, 10, NULL),
(24, 'test1', NULL, 67, 36, 31, 29, NULL),
(25, 'test2', NULL, 67, 37, 32, 30, NULL),
(26, 'test3', NULL, 67, 38, 33, 31, NULL),
(27, 'test4', NULL, 67, 39, 34, 32, NULL),
(29, 'test6', NULL, 67, 41, 36, 34, NULL),
(30, 'رحاب أكتوبر سيتي', NULL, 67, 2, NULL, 63, 'Rehab October City'),
(31, 'أستوريا بارك', NULL, 67, 2, NULL, 63, 'Astoria Park'),
(32, 'بداية 1', NULL, 67, 2, NULL, 63, 'Bedaya 1'),
(33, 'بداية 2', NULL, 67, 2, NULL, 63, 'Bedaya 2'),
(34, 'الحي الايطالي', NULL, 67, 2, NULL, 63, 'Italian District'),
(35, 'الحي الاسباني', NULL, 67, 2, NULL, 63, 'Spanish District');

-- --------------------------------------------------------

--
-- Table structure for table `Country`
--

CREATE TABLE `Country` (
  `ID` int(11) NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `capital` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `continent` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `continent_code` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alpha_3` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `countryId` int(11) DEFAULT NULL,
  `sympol` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Country`
--

INSERT INTO `Country` (`ID`, `name`, `phone`, `capital`, `continent`, `continent_code`, `alpha_3`, `countryId`, `sympol`, `currency`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Afghanistan', '93', 'Kabul', 'Asia', 'AS', 'AFG', 0, '؋', 'AFN'),
(3, 'Aland Islands', '358', 'Mariehamn', 'Europe', 'EU', 'ALA', 0, '€', 'EUR'),
(4, 'Albania', '355', 'Tirana', 'Europe', 'EU', 'ALB', 0, 'Lek', 'ALL'),
(5, 'Algeria', '213', 'Algiers', 'Africa', 'AF', 'DZA', 0, 'دج', 'DZD'),
(6, 'American Samoa', '1684', 'Pago Pago', 'Oceania', 'OC', 'ASM', 0, '$', 'USD'),
(7, 'Andorra', '376', 'Andorra la Vella', 'Europe', 'EU', 'AND', 0, '€', 'EUR'),
(8, 'Angola', '244', 'Luanda', 'Africa', 'AF', 'AGO', 0, 'Kz', 'AOA'),
(9, 'Anguilla', '1264', 'The Valley', 'North America', 'NA', 'AIA', 0, '$', 'XCD'),
(10, 'Antarctica', '672', 'Antarctica', 'Antarctica', 'AN', 'ATA', 0, '$', 'AAD'),
(11, 'Antigua and Barbuda', '1268', 'St. John\'s', 'North America', 'NA', 'ATG', 0, '$', 'XCD'),
(12, 'Argentina', '54', 'Buenos Aires', 'South America', 'SA', 'ARG', 0, '$', 'ARS'),
(13, 'Armenia', '374', 'Yerevan', 'Asia', 'AS', 'ARM', 0, '֏', 'AMD'),
(14, 'Aruba', '297', 'Oranjestad', 'North America', 'NA', 'ABW', 0, 'ƒ', 'AWG'),
(15, 'Australia', '61', 'Canberra', 'Oceania', 'OC', 'AUS', 0, '$', 'AUD'),
(16, 'Austria', '43', 'Vienna', 'Europe', 'EU', 'AUT', 0, '€', 'EUR'),
(17, 'Azerbaijan', '994', 'Baku', 'Asia', 'AS', 'AZE', 0, 'm', 'AZN'),
(18, 'Bahamas', '1242', 'Nassau', 'North America', 'NA', 'BHS', 0, 'B$', 'BSD'),
(19, 'Bahrain', '973', 'Manama', 'Asia', 'AS', 'BHR', 0, '.د.ب', 'BHD'),
(20, 'Bangladesh', '880', 'Dhaka', 'Asia', 'AS', 'BGD', 0, '৳', 'BDT'),
(21, 'Barbados', '1246', 'BrcountryIDgetown', 'North America', 'NA', 'BRB', 0, 'Bds$', 'BBD'),
(22, 'Belarus', '375', 'Minsk', 'Europe', 'EU', 'BLR', 0, 'Br', 'BYN'),
(23, 'Belgium', '32', 'Brussels', 'Europe', 'EU', 'BEL', 0, '€', 'EUR'),
(24, 'Belize', '501', 'Belmopan', 'North America', 'NA', 'BLZ', 0, '$', 'BZD'),
(25, 'Benin', '229', 'Porto-Novo', 'Africa', 'AF', 'BEN', 0, 'CFA', 'XOF'),
(26, 'Bermuda', '1441', 'Hamilton', 'North America', 'NA', 'BMU', 0, '$', 'BMD'),
(27, 'Bhutan', '975', 'Thimphu', 'Asia', 'AS', 'BTN', 0, 'Nu.', 'BTN'),
(28, 'Bolivia', '591', 'Sucre', 'South America', 'SA', 'BOL', 0, 'Bs.', 'BOB'),
(29, 'Bonaire, Sint Eustatius and Saba', '599', 'Kralendijk', 'North America', 'NA', 'BES', 0, '$', 'USD'),
(30, 'Bosnia and Herzegovina', '387', 'Sarajevo', 'Europe', 'EU', 'BIH', 0, 'KM', 'BAM'),
(31, 'Botswana', '267', 'Gaborone', 'Africa', 'AF', 'BWA', 0, 'P', 'BWP'),
(32, 'Bouvet Island', '55', '', 'Antarctica', 'AN', 'BVT', 0, 'kr', 'NOK'),
(33, 'Brazil', '55', 'Brasilia', 'South America', 'SA', 'BRA', 0, 'R$', 'BRL'),
(34, 'British Indian Ocean Territory', '246', 'Diego Garcia', 'Asia', 'AS', 'IOT', 0, '$', 'USD'),
(35, 'Brunei Darussalam', '673', 'Bandar Seri Begawan', 'Asia', 'AS', 'BRN', 0, 'B$', 'BND'),
(36, 'Bulgaria', '359', 'Sofia', 'Europe', 'EU', 'BGR', 0, 'Лв.', 'BGN'),
(37, 'Burkina Faso', '226', 'Ouagadougou', 'Africa', 'AF', 'BFA', 0, 'CFA', 'XOF'),
(38, 'Burundi', '257', 'Bujumbura', 'Africa', 'AF', 'BDI', 0, 'FBu', 'BIF'),
(39, 'Cambodia', '855', 'Phnom Penh', 'Asia', 'AS', 'KHM', 0, 'KHR', 'KHR'),
(40, 'Cameroon', '237', 'Yaounde', 'Africa', 'AF', 'CMR', 0, 'FCFA', 'XAF'),
(41, 'Canada', '1', 'Ottawa', 'North America', 'NA', 'CAN', 0, '$', 'CAD'),
(42, 'Cape Verde', '238', 'Praia', 'Africa', 'AF', 'CPV', 0, '$', 'CVE'),
(43, 'Cayman Islands', '1345', 'George Town', 'North America', 'NA', 'CYM', 0, '$', 'KYD'),
(44, 'Central African Republic', '236', 'Bangui', 'Africa', 'AF', 'CAF', 0, 'FCFA', 'XAF'),
(45, 'Chad', '235', 'N\'Djamena', 'Africa', 'AF', 'TCD', 0, 'FCFA', 'XAF'),
(46, 'Chile', '56', 'Santiago', 'South America', 'SA', 'CHL', 0, '$', 'CLP'),
(47, 'China', '86', 'Beijing', 'Asia', 'AS', 'CHN', 0, '¥', 'CNY'),
(48, 'Christmas Island', '61', 'Flying Fish Cove', 'Asia', 'AS', 'CXR', 0, '$', 'AUD'),
(49, 'Cocos (Keeling) Islands', '672', 'West Island', 'Asia', 'AS', 'CCK', 0, '$', 'AUD'),
(50, 'Colombia', '57', 'Bogota', 'South America', 'SA', 'COL', 0, '$', 'COP'),
(51, 'Comoros', '269', 'Moroni', 'Africa', 'AF', 'COM', 0, 'CF', 'KMF'),
(52, 'Congo', '242', 'Brazzaville', 'Africa', 'AF', 'COG', 0, 'FC', 'XAF'),
(53, 'Congo, Democratic Republic of the Congo', '242', 'Kinshasa', 'Africa', 'AF', 'COD', 0, 'FC', 'CDF'),
(54, 'Cook Islands', '682', 'Avarua', 'Oceania', 'OC', 'COK', 0, '$', 'NZD'),
(55, 'Costa Rica', '506', 'San Jose', 'North America', 'NA', 'CRI', 0, '₡', 'CRC'),
(56, 'Cote D\'Ivoire', '225', 'Yamoussoukro', 'Africa', 'AF', 'CIV', 0, 'CFA', 'XOF'),
(57, 'Croatia', '385', 'Zagreb', 'Europe', 'EU', 'HRV', 0, 'kn', 'HRK'),
(58, 'Cuba', '53', 'Havana', 'North America', 'NA', 'CUB', 0, '$', 'CUP'),
(59, 'Curacao', '599', 'Willemstad', 'North America', 'NA', 'CUW', 0, 'ƒ', 'ANG'),
(60, 'Cyprus', '357', 'Nicosia', 'Asia', 'AS', 'CYP', 0, '€', 'EUR'),
(61, 'Czech Republic', '420', 'Prague', 'Europe', 'EU', 'CZE', 0, 'Kč', 'CZK'),
(62, 'Denmark', '45', 'Copenhagen', 'Europe', 'EU', 'DNK', 0, 'Kr.', 'DKK'),
(63, 'Djibouti', '253', 'Djibouti', 'Africa', 'AF', 'DJI', 0, 'Fdj', 'DJF'),
(64, 'Dominica', '1767', 'Roseau', 'North America', 'NA', 'DMA', 0, '$', 'XCD'),
(65, 'Dominican Republic', '1809', 'Santo Domingo', 'North America', 'NA', 'DOM', 0, '$', 'DOP'),
(66, 'Ecuador', '593', 'Quito', 'South America', 'SA', 'ECU', 0, '$', 'USD'),
(67, 'Egypt', '20', 'Cairo', 'Africa', 'AF', 'EGY', 0, 'ج.م', 'EGP'),
(68, 'El Salvador', '503', 'San Salvador', 'North America', 'NA', 'SLV', 0, '$', 'USD'),
(69, 'Equatorial Guinea', '240', 'Malabo', 'Africa', 'AF', 'GNQ', 0, 'FCFA', 'XAF'),
(70, 'Eritrea', '291', 'Asmara', 'Africa', 'AF', 'ERI', 0, 'Nfk', 'ERN'),
(71, 'Estonia', '372', 'Tallinn', 'Europe', 'EU', 'EST', 0, '€', 'EUR'),
(72, 'Ethiopia', '251', 'Addis Ababa', 'Africa', 'AF', 'ETH', 0, 'Nkf', 'ETB'),
(73, 'Falkland Islands (Malvinas)', '500', 'Stanley', 'South America', 'SA', 'FLK', 0, '£', 'FKP'),
(74, 'Faroe Islands', '298', 'Torshavn', 'Europe', 'EU', 'FRO', 0, 'Kr.', 'DKK'),
(75, 'Fiji', '679', 'Suva', 'Oceania', 'OC', 'FJI', 0, 'FJ$', 'FJD'),
(76, 'Finland', '358', 'Helsinki', 'Europe', 'EU', 'FIN', 0, '€', 'EUR'),
(77, 'France', '33', 'Paris', 'Europe', 'EU', 'FRA', 0, '€', 'EUR'),
(78, 'French Guiana', '594', 'Cayenne', 'South America', 'SA', 'GUF', 0, '€', 'EUR'),
(79, 'French Polynesia', '689', 'Papeete', 'Oceania', 'OC', 'PYF', 0, '₣', 'XPF'),
(80, 'French Southern Territories', '262', 'Port-aux-Francais', 'Antarctica', 'AN', 'ATF', 0, '€', 'EUR'),
(81, 'Gabon', '241', 'Libreville', 'Africa', 'AF', 'GAB', 0, 'FCFA', 'XAF'),
(82, 'Gambia', '220', 'Banjul', 'Africa', 'AF', 'GMB', 0, 'D', 'GMD'),
(83, 'Georgia', '995', 'Tbilisi', 'Asia', 'AS', 'GEO', 0, 'ლ', 'GEL'),
(84, 'Germany', '49', 'Berlin', 'Europe', 'EU', 'DEU', 0, '€', 'EUR'),
(85, 'Ghana', '233', 'Accra', 'Africa', 'AF', 'GHA', 0, 'GH₵', 'GHS'),
(86, 'Gibraltar', '350', 'Gibraltar', 'Europe', 'EU', 'GIB', 0, '£', 'GIP'),
(87, 'Greece', '30', 'Athens', 'Europe', 'EU', 'GRC', 0, '€', 'EUR'),
(88, 'Greenland', '299', 'Nuuk', 'North America', 'NA', 'GRL', 0, 'Kr.', 'DKK'),
(89, 'Grenada', '1473', 'St. George\'s', 'North America', 'NA', 'GRD', 0, '$', 'XCD'),
(90, 'Guadeloupe', '590', 'Basse-Terre', 'North America', 'NA', 'GLP', 0, '€', 'EUR'),
(91, 'Guam', '1671', 'Hagatna', 'Oceania', 'OC', 'GUM', 0, '$', 'USD'),
(92, 'Guatemala', '502', 'Guatemala City', 'North America', 'NA', 'GTM', 0, 'Q', 'GTQ'),
(93, 'Guernsey', '44', 'St Peter Port', 'Europe', 'EU', 'GGY', 0, '£', 'GBP'),
(94, 'Guinea', '224', 'Conakry', 'Africa', 'AF', 'GIN', 0, 'FG', 'GNF'),
(95, 'Guinea-Bissau', '245', 'Bissau', 'Africa', 'AF', 'GNB', 0, 'CFA', 'XOF'),
(96, 'Guyana', '592', 'Georgetown', 'South America', 'SA', 'GUY', 0, '$', 'GYD'),
(97, 'Haiti', '509', 'Port-au-Prince', 'North America', 'NA', 'HTI', 0, 'G', 'HTG'),
(98, 'Heard Island and Mcdonald Islands', '0', '', 'Antarctica', 'AN', 'HMD', 0, '$', 'AUD'),
(99, 'Holy See (Vatican City State)', '39', 'Vatican City', 'Europe', 'EU', 'VAT', 0, '€', 'EUR'),
(100, 'Honduras', '504', 'Tegucigalpa', 'North America', 'NA', 'HND', 0, 'L', 'HNL'),
(101, 'Hong Kong', '852', 'Hong Kong', 'Asia', 'AS', 'HKG', 0, '$', 'HKD'),
(102, 'Hungary', '36', 'Budapest', 'Europe', 'EU', 'HUN', 0, 'Ft', 'HUF'),
(103, 'Iceland', '354', 'Reykjavik', 'Europe', 'EU', 'ISL', 0, 'kr', 'ISK'),
(104, 'India', '91', 'New Delhi', 'Asia', 'AS', 'IND', 0, '₹', 'INR'),
(105, 'Indonesia', '62', 'Jakarta', 'Asia', 'AS', 'countryIDN', 0, 'Rp', 'countryIDR'),
(106, 'Iran, Islamic Republic of', '98', 'Tehran', 'Asia', 'AS', 'IRN', 0, '﷼', 'IRR'),
(107, 'Iraq', '964', 'Baghdad', 'Asia', 'AS', 'IRQ', 0, 'د.ع', 'IQD'),
(108, 'Ireland', '353', 'Dublin', 'Europe', 'EU', 'IRL', 0, '€', 'EUR'),
(109, 'Isle of Man', '44', 'Douglas, Isle of Man', 'Europe', 'EU', 'IMN', 0, '£', 'GBP'),
(110, 'Israel', '972', 'Jerusalem', 'Asia', 'AS', 'ISR', 0, '₪', 'ILS'),
(111, 'Italy', '39', 'Rome', 'Europe', 'EU', 'ITA', 0, '€', 'EUR'),
(112, 'Jamaica', '1876', 'Kingston', 'North America', 'NA', 'JAM', 0, 'J$', 'JMD'),
(113, 'Japan', '81', 'Tokyo', 'Asia', 'AS', 'JPN', 0, '¥', 'JPY'),
(114, 'Jersey', '44', 'Saint Helier', 'Europe', 'EU', 'JEY', 0, '£', 'GBP'),
(115, 'Jordan', '962', 'Amman', 'Asia', 'AS', 'JOR', 0, 'ا.د', 'JOD'),
(116, 'Kazakhstan', '7', 'Astana', 'Asia', 'AS', 'KAZ', 0, 'лв', 'KZT'),
(117, 'Kenya', '254', 'Nairobi', 'Africa', 'AF', 'KEN', 0, 'KSh', 'KES'),
(118, 'Kiribati', '686', 'Tarawa', 'Oceania', 'OC', 'KIR', 0, '$', 'AUD'),
(119, 'Korea, Democratic People\'s Republic of', '850', 'Pyongyang', 'Asia', 'AS', 'PRK', 0, '₩', 'KPW'),
(120, 'Korea, Republic of', '82', 'Seoul', 'Asia', 'AS', 'KOR', 0, '₩', 'KRW'),
(121, 'Kosovo', '381', 'Pristina', 'Europe', 'EU', 'XKX', 0, '€', 'EUR'),
(122, 'Kuwait', '965', 'Kuwait City', 'Asia', 'AS', 'KWT', 0, 'ك.د', 'KWD'),
(123, 'Kyrgyzstan', '996', 'Bishkek', 'Asia', 'AS', 'KGZ', 0, 'лв', 'KGS'),
(124, 'Lao People\'s Democratic Republic', '856', 'Vientiane', 'Asia', 'AS', 'LAO', 0, '₭', 'LAK'),
(125, 'Latvia', '371', 'Riga', 'Europe', 'EU', 'LVA', 0, '€', 'EUR'),
(126, 'Lebanon', '961', 'Beirut', 'Asia', 'AS', 'LBN', 0, '£', 'LBP'),
(127, 'Lesotho', '266', 'Maseru', 'Africa', 'AF', 'LSO', 0, 'L', 'LSL'),
(128, 'Liberia', '231', 'Monrovia', 'Africa', 'AF', 'LBR', 0, '$', 'LRD'),
(129, 'Libyan Arab Jamahiriya', '218', 'Tripolis', 'Africa', 'AF', 'LBY', 0, 'د.ل', 'LYD'),
(130, 'Liechtenstein', '423', 'Vaduz', 'Europe', 'EU', 'LIE', 0, 'CHf', 'CHF'),
(131, 'Lithuania', '370', 'Vilnius', 'Europe', 'EU', 'LTU', 0, '€', 'EUR'),
(132, 'Luxembourg', '352', 'Luxembourg', 'Europe', 'EU', 'LUX', 0, '€', 'EUR'),
(133, 'Macao', '853', 'Macao', 'Asia', 'AS', 'MAC', 0, '$', 'MOP'),
(134, 'Macedonia, the Former Yugoslav Republic of', '389', 'Skopje', 'Europe', 'EU', 'MKD', 0, 'ден', 'MKD'),
(135, 'Madagascar', '261', 'Antananarivo', 'Africa', 'AF', 'MDG', 0, 'Ar', 'MGA'),
(136, 'Malawi', '265', 'Lilongwe', 'Africa', 'AF', 'MWI', 0, 'MK', 'MWK'),
(137, 'Malaysia', '60', 'Kuala Lumpur', 'Asia', 'AS', 'MYS', 0, 'RM', 'MYR'),
(138, 'Maldives', '960', 'Male', 'Asia', 'AS', 'MDV', 0, 'Rf', 'MVR'),
(139, 'Mali', '223', 'Bamako', 'Africa', 'AF', 'MLI', 0, 'CFA', 'XOF'),
(140, 'Malta', '356', 'Valletta', 'Europe', 'EU', 'MLT', 0, '€', 'EUR'),
(141, 'Marshall Islands', '692', 'Majuro', 'Oceania', 'OC', 'MHL', 0, '$', 'USD'),
(142, 'Martinique', '596', 'Fort-de-France', 'North America', 'NA', 'MTQ', 0, '€', 'EUR'),
(143, 'Mauritania', '222', 'Nouakchott', 'Africa', 'AF', 'MRT', 0, 'MRU', 'MRO'),
(144, 'Mauritius', '230', 'Port Louis', 'Africa', 'AF', 'MUS', 0, '₨', 'MUR'),
(145, 'Mayotte', '262', 'Mamoudzou', 'Africa', 'AF', 'MYT', 0, '€', 'EUR'),
(146, 'Mexico', '52', 'Mexico City', 'North America', 'NA', 'MEX', 0, '$', 'MXN'),
(147, 'Micronesia, Federated States of', '691', 'Palikir', 'Oceania', 'OC', 'FSM', 0, '$', 'USD'),
(148, 'Moldova, Republic of', '373', 'Chisinau', 'Europe', 'EU', 'MDA', 0, 'L', 'MDL'),
(149, 'Monaco', '377', 'Monaco', 'Europe', 'EU', 'MCO', 0, '€', 'EUR'),
(150, 'Mongolia', '976', 'Ulan Bator', 'Asia', 'AS', 'MNG', 0, '₮', 'MNT'),
(151, 'Montenegro', '382', 'Podgorica', 'Europe', 'EU', 'MNE', 0, '€', 'EUR'),
(152, 'Montserrat', '1664', 'Plymouth', 'North America', 'NA', 'MSR', 0, '$', 'XCD'),
(153, 'Morocco', '212', 'Rabat', 'Africa', 'AF', 'MAR', 0, 'DH', 'MAD'),
(154, 'Mozambique', '258', 'Maputo', 'Africa', 'AF', 'MOZ', 0, 'MT', 'MZN'),
(155, 'Myanmar', '95', 'Nay Pyi Taw', 'Asia', 'AS', 'MMR', 0, 'K', 'MMK'),
(156, 'Namibia', '264', 'Windhoek', 'Africa', 'AF', 'NAM', 0, '$', 'NAD'),
(157, 'Nauru', '674', 'Yaren', 'Oceania', 'OC', 'NRU', 0, '$', 'AUD'),
(158, 'Nepal', '977', 'Kathmandu', 'Asia', 'AS', 'NPL', 0, '₨', 'NPR'),
(159, 'Netherlands', '31', 'Amsterdam', 'Europe', 'EU', 'NLD', 0, '€', 'EUR'),
(160, 'Netherlands Antilles', '599', 'Willemstad', 'North America', 'NA', 'ANT', 0, 'NAf', 'ANG'),
(161, 'New Caledonia', '687', 'Noumea', 'Oceania', 'OC', 'NCL', 0, '₣', 'XPF'),
(162, 'New Zealand', '64', 'Wellington', 'Oceania', 'OC', 'NZL', 0, '$', 'NZD'),
(163, 'Nicaragua', '505', 'Managua', 'North America', 'NA', 'NIC', 0, 'C$', 'NIO'),
(164, 'Niger', '227', 'Niamey', 'Africa', 'AF', 'NER', 0, 'CFA', 'XOF'),
(165, 'Nigeria', '234', 'Abuja', 'Africa', 'AF', 'NGA', 0, '₦', 'NGN'),
(166, 'Niue', '683', 'Alofi', 'Oceania', 'OC', 'NIU', 0, '$', 'NZD'),
(167, 'Norfolk Island', '672', 'Kingston', 'Oceania', 'OC', 'NFK', 0, '$', 'AUD'),
(168, 'Northern Mariana Islands', '1670', 'Saipan', 'Oceania', 'OC', 'MNP', 0, '$', 'USD'),
(169, 'Norway', '47', 'Oslo', 'Europe', 'EU', 'NOR', 0, 'kr', 'NOK'),
(170, 'Oman', '968', 'Muscat', 'Asia', 'AS', 'OMN', 0, '.ع.ر', 'OMR'),
(171, 'Pakistan', '92', 'Islamabad', 'Asia', 'AS', 'PAK', 0, '₨', 'PKR'),
(172, 'Palau', '680', 'Melekeok', 'Oceania', 'OC', 'PLW', 0, '$', 'USD'),
(173, 'Palestinian Territory, Occupied', '970', 'East Jerusalem', 'Asia', 'AS', 'PSE', 0, '₪', 'ILS'),
(174, 'Panama', '507', 'Panama City', 'North America', 'NA', 'PAN', 0, 'B/.', 'PAB'),
(175, 'Papua New Guinea', '675', 'Port Moresby', 'Oceania', 'OC', 'PNG', 0, 'K', 'PGK'),
(176, 'Paraguay', '595', 'Asuncion', 'South America', 'SA', 'PRY', 0, '₲', 'PYG'),
(177, 'Peru', '51', 'Lima', 'South America', 'SA', 'PER', 0, 'S/.', 'PEN'),
(178, 'Philippines', '63', 'Manila', 'Asia', 'AS', 'PHL', 0, '₱', 'PHP'),
(179, 'Pitcairn', '64', 'Adamstown', 'Oceania', 'OC', 'PCN', 0, '$', 'NZD'),
(180, 'Poland', '48', 'Warsaw', 'Europe', 'EU', 'POL', 0, 'zł', 'PLN'),
(181, 'Portugal', '351', 'Lisbon', 'Europe', 'EU', 'PRT', 0, '€', 'EUR'),
(182, 'Puerto Rico', '1787', 'San Juan', 'North America', 'NA', 'PRI', 0, '$', 'USD'),
(183, 'Qatar', '974', 'Doha', 'Asia', 'AS', 'QAT', 0, 'ق.ر', 'QAR'),
(184, 'Reunion', '262', 'Saint-Denis', 'Africa', 'AF', 'REU', 0, '€', 'EUR'),
(185, 'Romania', '40', 'Bucharest', 'Europe', 'EU', 'ROM', 0, 'lei', 'RON'),
(186, 'Russian Federation', '70', 'Moscow', 'Asia', 'AS', 'RUS', 0, '₽', 'RUB'),
(187, 'Rwanda', '250', 'Kigali', 'Africa', 'AF', 'RWA', 0, 'FRw', 'RWF'),
(188, 'Saint Barthelemy', '590', 'Gustavia', 'North America', 'NA', 'BLM', 0, '€', 'EUR'),
(189, 'Saint Helena', '290', 'Jamestown', 'Africa', 'AF', 'SHN', 0, '£', 'SHP'),
(190, 'Saint Kitts and Nevis', '1869', 'Basseterre', 'North America', 'NA', 'KNA', 0, '$', 'XCD'),
(191, 'Saint Lucia', '1758', 'Castries', 'North America', 'NA', 'LCA', 0, '$', 'XCD'),
(192, 'Saint Martin', '590', 'Marigot', 'North America', 'NA', 'MAF', 0, '€', 'EUR'),
(193, 'Saint Pierre and Miquelon', '508', 'Saint-Pierre', 'North America', 'NA', 'SPM', 0, '€', 'EUR'),
(194, 'Saint Vincent and the Grenadines', '1784', 'Kingstown', 'North America', 'NA', 'VCT', 0, '$', 'XCD'),
(195, 'Samoa', '684', 'Apia', 'Oceania', 'OC', 'WSM', 0, 'SAT', 'WST'),
(196, 'San Marino', '378', 'San Marino', 'Europe', 'EU', 'SMR', 0, '€', 'EUR'),
(197, 'Sao Tome and Principe', '239', 'Sao Tome', 'Africa', 'AF', 'STP', 0, 'Db', 'STD'),
(198, 'Saudi Arabia', '966', 'Riyadh', 'Asia', 'AS', 'SAU', 0, '﷼', 'SAR'),
(199, 'Senegal', '221', 'Dakar', 'Africa', 'AF', 'SEN', 0, 'CFA', 'XOF'),
(200, 'Serbia', '381', 'Belgrade', 'Europe', 'EU', 'SRB', 0, 'din', 'RSD'),
(201, 'Serbia and Montenegro', '381', 'Belgrade', 'Europe', 'EU', 'SCG', 0, 'din', 'RSD'),
(202, 'Seychelles', '248', 'Victoria', 'Africa', 'AF', 'SYC', 0, 'SRe', 'SCR'),
(203, 'Sierra Leone', '232', 'Freetown', 'Africa', 'AF', 'SLE', 0, 'Le', 'SLL'),
(204, 'Singapore', '65', 'Singapur', 'Asia', 'AS', 'SGP', 0, '$', 'SGD'),
(205, 'Sint Maarten', '1', 'Philipsburg', 'North America', 'NA', 'SXM', 0, 'ƒ', 'ANG'),
(206, 'Slovakia', '421', 'Bratislava', 'Europe', 'EU', 'SVK', 0, '€', 'EUR'),
(207, 'Slovenia', '386', 'Ljubljana', 'Europe', 'EU', 'SVN', 0, '€', 'EUR'),
(208, 'Solomon Islands', '677', 'Honiara', 'Oceania', 'OC', 'SLB', 0, 'Si$', 'SBD'),
(209, 'Somalia', '252', 'Mogadishu', 'Africa', 'AF', 'SOM', 0, 'Sh.so.', 'SOS'),
(210, 'South Africa', '27', 'Pretoria', 'Africa', 'AF', 'ZAF', 0, 'R', 'ZAR'),
(211, 'South Georgia and the South Sandwich Islands', '500', 'Grytviken', 'Antarctica', 'AN', 'SGS', 0, '£', 'GBP'),
(212, 'South Sudan', '211', 'Juba', 'Africa', 'AF', 'SSD', 0, '£', 'SSP'),
(213, 'Spain', '34', 'MadrcountryID', 'Europe', 'EU', 'ESP', 0, '€', 'EUR'),
(214, 'Sri Lanka', '94', 'Colombo', 'Asia', 'AS', 'LKA', 0, 'Rs', 'LKR'),
(215, 'Sudan', '249', 'Khartoum', 'Africa', 'AF', 'SDN', 0, '.س.ج', 'SDG'),
(216, 'Suriname', '597', 'Paramaribo', 'South America', 'SA', 'SUR', 0, '$', 'SRD'),
(217, 'Svalbard and Jan Mayen', '47', 'Longyearbyen', 'Europe', 'EU', 'SJM', 0, 'kr', 'NOK'),
(218, 'Swaziland', '268', 'Mbabane', 'Africa', 'AF', 'SWZ', 0, 'E', 'SZL'),
(219, 'Sweden', '46', 'Stockholm', 'Europe', 'EU', 'SWE', 0, 'kr', 'SEK'),
(220, 'Switzerland', '41', 'Berne', 'Europe', 'EU', 'CHE', 0, 'CHf', 'CHF'),
(221, 'Syrian Arab Republic', '963', 'Damascus', 'Asia', 'AS', 'SYR', 0, 'LS', 'SYP'),
(222, 'Taiwan, Province of China', '886', 'Taipei', 'Asia', 'AS', 'TWN', 0, '$', 'TWD'),
(223, 'Tajikistan', '992', 'Dushanbe', 'Asia', 'AS', 'TJK', 0, 'SM', 'TJS'),
(224, 'Tanzania, United Republic of', '255', 'Dodoma', 'Africa', 'AF', 'TZA', 0, 'TSh', 'TZS'),
(225, 'Thailand', '66', 'Bangkok', 'Asia', 'AS', 'THA', 0, '฿', 'THB'),
(226, 'Timor-Leste', '670', 'Dili', 'Asia', 'AS', 'TLS', 0, '$', 'USD'),
(227, 'Togo', '228', 'Lome', 'Africa', 'AF', 'TGO', 0, 'CFA', 'XOF'),
(228, 'Tokelau', '690', '', 'Oceania', 'OC', 'TKL', 0, '$', 'NZD'),
(229, 'Tonga', '676', 'Nuku\'alofa', 'Oceania', 'OC', 'TON', 0, '$', 'TOP'),
(230, 'TrincountryIDad and Tobago', '1868', 'Port of Spain', 'North America', 'NA', 'TTO', 0, '$', 'TTD'),
(231, 'Tunisia', '216', 'Tunis', 'Africa', 'AF', 'TUN', 0, 'ت.د', 'TND'),
(232, 'Turkey', '90', 'Ankara', 'Asia', 'AS', 'TUR', 0, '₺', 'TRY'),
(233, 'Turkmenistan', '7370', 'Ashgabat', 'Asia', 'AS', 'TKM', 0, 'T', 'TMT'),
(234, 'Turks and Caicos Islands', '1649', 'Cockburn Town', 'North America', 'NA', 'TCA', 0, '$', 'USD'),
(235, 'Tuvalu', '688', 'Funafuti', 'Oceania', 'OC', 'TUV', 0, '$', 'AUD'),
(236, 'Uganda', '256', 'Kampala', 'Africa', 'AF', 'UGA', 0, 'USh', 'UGX'),
(237, 'Ukraine', '380', 'Kiev', 'Europe', 'EU', 'UKR', 0, '₴', 'UAH'),
(238, 'United Arab Emirates', '971', 'Abu Dhabi', 'Asia', 'AS', 'ARE', 0, 'إ.د', 'AED'),
(239, 'United Kingdom', '44', 'London', 'Europe', 'EU', 'GBR', 0, '£', 'GBP'),
(240, 'United States', '1', 'Washington', 'North America', 'NA', 'USA', 0, '$', 'USD'),
(241, 'United States Minor Outlying Islands', '1', '', 'North America', 'NA', 'UMI', 0, '$', 'USD'),
(242, 'Uruguay', '598', 'MontevcountryIDeo', 'South America', 'SA', 'URY', 0, '$', 'UYU'),
(243, 'Uzbekistan', '998', 'Tashkent', 'Asia', 'AS', 'UZB', 0, 'лв', 'UZS'),
(244, 'Vanuatu', '678', 'Port Vila', 'Oceania', 'OC', 'VUT', 0, 'VT', 'VUV'),
(245, 'Venezuela', '58', 'Caracas', 'South America', 'SA', 'VEN', 0, 'Bs', 'VEF'),
(246, 'Viet Nam', '84', 'Hanoi', 'Asia', 'AS', 'VNM', 0, '₫', 'VND'),
(247, 'Virgin Islands, British', '1284', 'Road Town', 'North America', 'NA', 'VGB', 0, '$', 'USD'),
(248, 'Virgin Islands, U.s.', '1340', 'Charlotte Amalie', 'North America', 'NA', 'VIR', 0, '$', 'USD'),
(249, 'Wallis and Futuna', '681', 'Mata Utu', 'Oceania', 'OC', 'WLF', 0, '₣', 'XPF'),
(250, 'Western Sahara', '212', 'El-Aaiun', 'Africa', 'AF', 'ESH', 0, 'MAD', 'MAD'),
(251, 'Yemen', '967', 'Sanaa', 'Asia', 'AS', 'YEM', 0, '﷼', 'YER'),
(252, 'Zambia', '260', 'Lusaka', 'Africa', 'AF', 'ZMB', 0, 'ZK', 'ZMW'),
(253, 'Zimbabwe', '263', 'Harare', 'Africa', 'AF', 'ZWE', 0, '$', 'ZWL');

-- --------------------------------------------------------

--
-- Table structure for table `Decision`
--

CREATE TABLE `Decision` (
  `ID` int(11) NOT NULL,
  `Cause` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Decision` text COLLATE utf8_unicode_ci,
  `Likes` int(11) NOT NULL,
  `DisLikes` int(11) NOT NULL,
  `MeetingID` int(11) DEFAULT NULL,
  `BlockManagerID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `Date` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Decision`
--

INSERT INTO `Decision` (`ID`, `Cause`, `Decision`, `Likes`, `DisLikes`, `MeetingID`, `BlockManagerID`, `BlockID`, `Date`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, 1, 1, 1, '0000-00-00', '2023-02-04 12:26:30', NULL, NULL),
(2, 'decisionTest2', 'decision1Test1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, 2, 1, 1, '0000-00-00', '2023-02-04 12:26:34', NULL, NULL),
(7, 'decisionTest7', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, 1, 1, 1, '4/2/2023', '2023-02-13 04:35:25', NULL, NULL),
(8, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-22 02:58:25', NULL, NULL),
(9, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-22 02:58:41', NULL, NULL),
(10, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-23 10:16:45', NULL, NULL),
(11, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-23 10:16:54', NULL, NULL),
(12, NULL, 'Decision in meeting test1', 0, 0, 19, 1, NULL, '2023-02-26 01:21:22am', '2023-02-26 01:21:22', NULL, NULL),
(13, NULL, 'Decision in meeting test1', 0, 0, 20, 1, NULL, '2023-02-26 01:28:28am', '2023-02-26 01:28:28', NULL, NULL),
(14, NULL, '[Decision in meeting test1', 0, 0, 31, 1, NULL, '2023-02-27 03:25:24pm', '2023-02-27 15:25:24', NULL, NULL),
(15, NULL, ' Decision in meeting test1]', 0, 0, 31, 1, NULL, '2023-02-27 03:25:24pm', '2023-02-27 15:25:24', NULL, NULL),
(16, NULL, 'Decision in meeting test3', 0, 0, 32, 1, NULL, '2023-02-27 03:26:20pm', '2023-02-27 15:26:20', NULL, NULL),
(17, NULL, ' Decision in meeting test4', 0, 0, 32, 1, NULL, '2023-02-27 03:26:20pm', '2023-02-27 15:26:20', NULL, NULL),
(18, NULL, 'Decision in meeting test3', 0, 0, 33, 1, NULL, '2023-02-27 03:26:46pm', '2023-02-27 15:26:46', NULL, NULL),
(19, NULL, 'Decision in meeting test3', 0, 0, 34, 1, NULL, '2023-02-27 10:19:00pm', '2023-02-27 22:19:00', NULL, NULL),
(20, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-27 10:47:22', NULL, NULL),
(21, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-27 10:59:23', NULL, NULL),
(22, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-27 11:00:52', NULL, NULL),
(23, 'decisionTest1', 'decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1decisionTest1', 0, 0, NULL, 1, 1, '4/2/2023', '2023-02-27 11:01:36', NULL, NULL),
(24, NULL, 'Decision in meeting test3', 0, 0, 35, 1, NULL, '2023-02-27 11:19:28pm', '2023-02-27 23:19:28', NULL, NULL),
(25, NULL, 'Decision in meeting test3', 0, 0, 36, 1, NULL, '2023-02-28 07:07:59pm', '2023-02-28 19:07:59', NULL, NULL),
(26, NULL, 'Decision in meeting test3', 0, 0, 37, 1, NULL, '2023-03-05 01:17:41pm', '2023-03-05 13:17:41', NULL, NULL),
(27, NULL, 'ajasjlhdls', 0, 0, 37, 1, NULL, '2023-03-05 01:17:41pm', '2023-03-05 13:17:41', NULL, NULL),
(28, NULL, 'test D4', 0, 0, 37, 1, NULL, '2023-03-05 01:17:41pm', '2023-03-05 13:17:41', NULL, NULL),
(29, NULL, 'Decision in meeting test3', 0, 0, 38, 1, NULL, '2023-03-05 02:56:04pm', '2023-03-05 14:56:04', NULL, NULL),
(30, NULL, 'Vote 1', 0, 0, 39, 26, NULL, '2023-03-05 03:01:33pm', '2023-03-05 15:01:33', NULL, NULL),
(31, NULL, 'Vore 2', 0, 1, 39, 26, NULL, '2023-03-05 03:01:33pm', '2023-03-05 15:01:33', NULL, NULL),
(32, NULL, 'Vote 3', 0, 1, 39, 26, NULL, '2023-03-05 03:01:33pm', '2023-03-05 15:01:33', NULL, NULL),
(33, NULL, 'Decision in meeting test4', 0, 0, 40, 1, NULL, '2023-03-06 04:25:01pm', '2023-03-06 16:25:01', NULL, NULL),
(34, NULL, ' DecisionTest5', 0, 0, 40, 1, NULL, '2023-03-06 04:25:01pm', '2023-03-06 16:25:01', NULL, NULL),
(35, NULL, 'Decision in meeting test4', 0, 0, 41, 1, NULL, '2023-03-07 10:31:39am', '2023-03-07 10:31:39', NULL, NULL),
(36, NULL, ' DecisionTest5', 0, 0, 41, 1, NULL, '2023-03-07 10:31:39am', '2023-03-07 10:31:39', NULL, NULL),
(37, NULL, 'تغيير الاصانصير ميزانية ١٠٠ الف', 1, 0, 42, 34, NULL, '2023-03-09 09:59:13pm', '2023-03-09 21:59:13', NULL, NULL),
(38, NULL, 'تزيين المدخل ٢٠ الف', 1, 0, 42, 34, NULL, '2023-03-09 09:59:13pm', '2023-03-09 21:59:13', NULL, NULL),
(39, NULL, 'تركيب مواسير صرف تكيفات ١٥ الف', 1, 0, 43, 34, NULL, '2023-03-16 09:53:45am', '2023-03-16 09:53:45', NULL, NULL),
(40, NULL, 'تركيب دش مركزي ٣٥ الف', 0, 1, 44, 34, NULL, '2023-03-16 09:59:14am', '2023-03-16 09:59:14', NULL, NULL),
(41, NULL, 'خط شكاوي ١٢ الف', 1, 0, 44, 34, NULL, '2023-03-16 09:59:14am', '2023-03-16 09:59:14', NULL, NULL),
(42, NULL, 'Decision in meeting test4', 0, 0, 45, 1, NULL, '2023-04-11 02:49:01pm', '2023-04-11 14:49:01', NULL, NULL),
(43, NULL, ' DecisionTest5', 0, 0, 45, 1, NULL, '2023-04-11 02:49:01pm', '2023-04-11 14:49:01', NULL, NULL),
(44, NULL, 'Decision in meeting test4', 0, 0, 46, 1, NULL, '2023-04-12 12:57:20am', '2023-04-12 00:57:20', NULL, NULL),
(45, NULL, ' DecisionTest5', 0, 0, 46, 1, NULL, '2023-04-12 12:57:20am', '2023-04-12 00:57:20', NULL, NULL),
(46, NULL, 'Decision in meeting test4', 0, 0, 47, 1, NULL, '2023-04-12 01:27:30am', '2023-04-12 01:27:30', NULL, NULL),
(47, NULL, ' DecisionTest5', 0, 0, 47, 1, NULL, '2023-04-12 01:27:30am', '2023-04-12 01:27:30', NULL, NULL),
(48, NULL, 'Decision in meeting test4', 0, 0, 48, 1, NULL, '2023-04-12 01:27:59am', '2023-04-12 01:27:59', NULL, NULL),
(49, NULL, ' DecisionTest5', 0, 0, 48, 1, NULL, '2023-04-12 01:27:59am', '2023-04-12 01:27:59', NULL, NULL),
(50, NULL, 'Decision in meeting test4', 0, 0, 49, 1, NULL, '2023-04-12 01:30:43am', '2023-04-12 01:30:43', NULL, NULL),
(51, NULL, ' DecisionTest5', 0, 0, 49, 1, NULL, '2023-04-12 01:30:43am', '2023-04-12 01:30:43', NULL, NULL),
(52, NULL, 'Decision in meeting test4', 0, 0, 50, 1, NULL, '2023-04-12 01:31:41am', '2023-04-12 01:31:41', NULL, NULL),
(53, NULL, ' DecisionTest5', 0, 0, 50, 1, NULL, '2023-04-12 01:31:41am', '2023-04-12 01:31:41', NULL, NULL),
(54, NULL, 'Decision in meeting test4', 0, 0, 51, 1, NULL, '2023-04-12 01:32:06am', '2023-04-12 01:32:06', NULL, NULL),
(55, NULL, ' DecisionTest5', 0, 0, 51, 1, NULL, '2023-04-12 01:32:06am', '2023-04-12 01:32:06', NULL, NULL),
(56, NULL, 'Decision in meeting test4', 0, 0, 52, 1, NULL, '2023-04-12 01:59:00am', '2023-04-12 01:59:00', NULL, NULL),
(57, NULL, ' DecisionTest5', 0, 0, 52, 1, NULL, '2023-04-12 01:59:00am', '2023-04-12 01:59:00', NULL, NULL),
(58, NULL, 'Decision in meeting test4', 0, 0, 53, 1, NULL, '2023-04-12 02:00:56am', '2023-04-12 02:00:56', NULL, NULL),
(59, NULL, ' DecisionTest5', 0, 0, 53, 1, NULL, '2023-04-12 02:00:56am', '2023-04-12 02:00:56', NULL, NULL),
(60, NULL, 'Decision in meeting test4', 0, 0, 54, 1, NULL, '2023-04-12 02:01:41am', '2023-04-12 02:01:41', NULL, NULL),
(61, NULL, ' DecisionTest5', 0, 0, 54, 1, NULL, '2023-04-12 02:01:41am', '2023-04-12 02:01:41', NULL, NULL),
(62, NULL, 'Decision in meeting test4', 0, 0, 55, 1, NULL, '2023-04-12 02:02:09am', '2023-04-12 02:02:09', NULL, NULL),
(63, NULL, ' DecisionTest5', 0, 0, 55, 1, NULL, '2023-04-12 02:02:09am', '2023-04-12 02:02:09', NULL, NULL),
(64, NULL, 'Decision in meeting test4', 0, 0, 56, 1, NULL, '2023-04-12 02:02:30am', '2023-04-12 02:02:30', NULL, NULL),
(65, NULL, ' DecisionTest5', 0, 0, 56, 1, NULL, '2023-04-12 02:02:30am', '2023-04-12 02:02:30', NULL, NULL),
(66, NULL, 'Decision in meeting test4', 0, 0, 57, 1, NULL, '2023-04-12 02:12:57am', '2023-04-12 02:12:57', NULL, NULL),
(67, NULL, ' DecisionTest5', 0, 0, 57, 1, NULL, '2023-04-12 02:12:57am', '2023-04-12 02:12:57', NULL, NULL),
(68, NULL, 'Decision in meeting test4', 0, 0, 58, 1, NULL, '2023-04-12 02:14:30am', '2023-04-12 02:14:30', NULL, NULL),
(69, NULL, ' DecisionTest5', 0, 0, 58, 1, NULL, '2023-04-12 02:14:30am', '2023-04-12 02:14:30', NULL, NULL),
(70, NULL, 'Decision in meeting test4', 0, 0, 59, 1, NULL, '2023-04-12 02:16:19am', '2023-04-12 02:16:19', NULL, NULL),
(71, NULL, ' DecisionTest5', 0, 0, 59, 1, NULL, '2023-04-12 02:16:19am', '2023-04-12 02:16:19', NULL, NULL),
(72, NULL, 'Decision in meeting test4', 0, 0, 60, 1, NULL, '2023-04-12 02:18:24am', '2023-04-12 02:18:24', NULL, NULL),
(73, NULL, ' DecisionTest5', 0, 0, 60, 1, NULL, '2023-04-12 02:18:24am', '2023-04-12 02:18:24', NULL, NULL),
(74, NULL, 'Decision in meeting test4', 0, 0, 61, 1, NULL, '2023-04-12 03:08:53am', '2023-04-12 03:08:53', NULL, NULL),
(75, NULL, ' DecisionTest5', 0, 0, 61, 1, NULL, '2023-04-12 03:08:53am', '2023-04-12 03:08:53', NULL, NULL),
(76, NULL, 'Decision in meeting test4', 0, 0, 62, 1, NULL, '2023-04-12 03:09:15am', '2023-04-12 03:09:15', NULL, NULL),
(77, NULL, ' DecisionTest5', 0, 0, 62, 1, NULL, '2023-04-12 03:09:15am', '2023-04-12 03:09:15', NULL, NULL),
(78, NULL, 'Decision in meeting test4', 0, 0, 63, 1, NULL, '2023-05-06 07:10:26pm', '2023-05-06 19:10:26', NULL, NULL),
(79, NULL, ' DecisionTest5', 0, 0, 63, 1, NULL, '2023-05-06 07:10:26pm', '2023-05-06 19:10:26', NULL, NULL),
(80, NULL, 'Decision in meeting test4', 0, 0, 67, 1, NULL, '2023-05-11 10:11:15pm', '2023-05-11 22:11:15', NULL, NULL),
(81, NULL, ' DecisionTest5', 0, 0, 67, 1, NULL, '2023-05-11 10:11:15pm', '2023-05-11 22:11:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Emails`
--

CREATE TABLE `Emails` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `Email` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Hide` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Emails`
--

INSERT INTO `Emails` (`ID`, `UserID`, `ServiceID`, `Email`, `Hide`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, NULL, 'hm123454321@gmail.com', 1, '2023-03-30 20:17:07', NULL, NULL),
(2, 1, NULL, 'mody.man531@yahoo.com', 0, '2023-04-02 14:55:03', NULL, NULL),
(3, 1, NULL, 'mody.man531@yahoo.net', 0, '2023-05-23 12:26:04', NULL, NULL),
(4, 1, NULL, 'mody.man531@yahoo.ne', 0, '2023-05-23 12:45:09', NULL, NULL),
(5, 1, NULL, 'mody.man531@hotmail.com', 0, '2023-05-23 12:49:13', NULL, NULL),
(6, 1, NULL, 'mody.man531@mail.com', 0, '2023-05-23 12:54:42', NULL, NULL),
(7, 1, NULL, 'mody.man531@Wmail.com', 0, '2023-05-23 13:53:28', NULL, NULL),
(8, 1, NULL, 'mody.man531@Wmail.com', 0, '2023-05-23 13:56:37', NULL, NULL),
(9, 1, NULL, 'mody.man531@Wmail.com', 0, '2023-05-23 13:57:26', NULL, NULL),
(10, 1, NULL, 'mody.man531@Wmail.com', 0, '2023-05-23 13:57:54', NULL, NULL),
(11, 1, NULL, 'mody.man531@Wmail.com', 0, '2023-05-23 13:58:35', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Event`
--

CREATE TABLE `Event` (
  `ID` int(11) NOT NULL,
  `Tittle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Body` text COLLATE utf8_unicode_ci,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ImagePath` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `EventLocation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfAttendees` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Event`
--

INSERT INTO `Event` (`ID`, `Tittle`, `Body`, `Image`, `ImagePath`, `Date`, `EventLocation`, `NumOfAttendees`, `UserID`, `ApartmentID`, `BlockID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'testUpdate1', '2 Update test 8/3/2023', 'MTY0NmM4NjFkNTM3ZDI5LjM4MjIwOTM2.png', NULL, '2023-02-18 06:00:00', 'arm leg', 33, 1, 2, 1, '2023-02-04 12:05:31', '2023-05-23 12:23:41', 1),
(2, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 6, 1, 2, 1, '2023-02-04 12:08:41', '2023-02-17 08:49:52', NULL),
(3, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-04 12:10:08', '2023-02-17 08:49:52', NULL),
(4, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-04 12:15:26', '2023-02-17 08:49:52', NULL),
(5, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 01:18:29', '2023-02-17 08:49:52', NULL),
(6, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 01:18:50', '2023-02-17 08:49:52', NULL),
(8, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 02:58:14', '2023-02-17 08:49:52', NULL),
(9, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 02:59:06', '2023-02-17 08:49:52', NULL),
(10, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 03:00:30', '2023-02-17 08:49:52', NULL),
(11, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-05 03:02:59', '2023-02-17 08:49:52', NULL),
(12, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 2, 1, 2, 1, '2023-02-13 04:07:02', '2023-02-17 08:49:52', NULL),
(13, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-13 04:28:28', '2023-02-17 08:49:52', NULL),
(18, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-16 06:17:14', '2023-02-17 08:49:52', NULL),
(19, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-16 06:18:58', '2023-02-17 08:49:52', NULL),
(20, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-16 06:19:38', '2023-02-17 08:49:52', NULL),
(21, 'testUpdate', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '0000-00-00 00:00:00', '', 0, 1, 2, 1, '2023-02-16 06:20:57', '2023-02-17 08:49:52', NULL),
(22, 'New event', 'Test description', 'MjY2M2ZiNjExMDU4Y2I0Ny40MTI4Nzk0Ng==.jpg', NULL, '0000-00-00 00:00:00', 'Event location', 0, 26, 77, 73, '2023-02-26 03:39:28', NULL, NULL),
(23, 'Neew one ', 'New description ', 'MjY2M2ZiNjFiZTlhYTM1Mi4zMjc2ODY4MA==.jpg', NULL, '0000-00-00 00:00:00', 'New location ', 0, 26, 77, 73, '2023-02-26 03:42:22', NULL, NULL),
(24, 'Meeting for IT', 'Event description', 'MjY2M2ZiNzkxOGJlMzVlNS40MTg2OTQ0NQ==.jpg', NULL, '2023-02-26 15:20:49', 'Egypt ', 1, 26, 77, 73, '2023-02-26 05:22:00', NULL, NULL),
(25, 'Title event ', 'Bybyb', 'MjY2M2ZiNzk1Y2NkYjAzMi40ODQ4MjY2OA==.jpg', NULL, '2023-03-15 15:20:49', 'Egypt', 0, 26, 77, 73, '2023-02-26 05:23:08', NULL, NULL),
(26, 'Event', 'Event description for some thing', 'MjY2M2ZiN2ViOGMyYTY1MS41Njc5MzAxNw==.jpg', NULL, '2023-02-28 15:44:07', 'Qiza', 0, 26, 77, 73, '2023-02-26 05:46:00', NULL, NULL),
(27, 'EventTest11', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'MTYzZmI4MTc4NjQxYTc4LjMxNjIxMzk1.png', NULL, '2023-02-26 10:00:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-02-26 05:57:44', NULL, NULL),
(28, 'EventTest11', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'MTYzZmI4NDkzNzM1NmM1LjcxODkwMDE1.png', NULL, '2023-02-26 10:00:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-02-26 06:10:59', NULL, NULL),
(29, 'إفطار رمضان ', 'إفطار الغمارة', 'MzQ2M2ZjZmY5YzJiM2EwNy45NzUzNjQ2OQ==.jpg', NULL, '2023-02-27 18:38:36', 'الأرضي جنينه العمارة', 1, 34, 82, 78, '2023-02-27 09:08:12', NULL, NULL),
(30, 'عزومة العمارة ', 'عزمه العمارة غدا وشوي', 'MzQ2NDA1YzQ0YWVjODJkNC4xMTg1NjM0NQ==.jpg', NULL, '2023-03-06 10:04:19', 'شقة ١٣', 1, 34, 82, 78, '2023-03-06 12:45:30', NULL, NULL),
(31, 'تنضيف العمارة ', 'تجمع لتنضيف العمارة ', 'MzQ2NDA1YzRhMDVkMzcwNi42NzEyMjkxNA==.jpg', NULL, '2023-03-07 10:04:19', 'المدخل', 1, 34, 82, 78, '2023-03-06 12:46:56', NULL, NULL),
(32, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-02-26 10:00:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 10:25:55', NULL, NULL),
(33, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-03-08 10:00:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 10:26:26', NULL, NULL),
(34, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 11:28:21', NULL, NULL),
(35, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 01:58:53', NULL, NULL),
(36, 'EventTest11', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-02-26 10:00:00', 'شقة الاستاذ حسن', 0, 26, 77, 73, '2023-03-07 01:59:05', NULL, NULL),
(37, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 01:59:54', NULL, NULL),
(38, 'EventTestWaheed7-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-07 02:00:39', NULL, NULL),
(39, 'EventTest11', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', '', NULL, '2023-02-26 10:00:00', 'شقة الاستاذ حسن', 0, 26, 77, 73, '2023-03-07 02:02:22', NULL, NULL),
(40, 'EventTestWaheed 9-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'Default.jpg', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-09 10:57:15', NULL, NULL),
(41, 'Event am Waheed', 'Event description ', 'Default.jpg', NULL, '2023-03-09 11:47:18', 'Egypt  / Giza', 1, 26, 77, 73, '2023-03-09 02:11:20', NULL, NULL),
(42, 'افطار رمضان ', 'كل عام وانتم بخير ', 'Default.jpg', NULL, '2023-03-23 16:13:03', 'العماره ١٠٧ ز', 0, 39, 84, 90, '2023-03-09 03:16:33', NULL, NULL),
(43, 'Hghhj', 'Ggghu', 'Default.jpg', NULL, '2023-03-14 11:46:49', 'Hhhj', 0, 34, 87, 93, '2023-03-14 02:14:57', NULL, NULL),
(44, 'EventTestWaheed 9-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'Default.jpg', NULL, '2023-03-14 11:46:49', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-03-14 02:16:20', NULL, NULL),
(45, 'Ffffff', 'Fffgfff', 'Default.jpg', NULL, '2023-03-15 10:00:49', 'Fffff', 1, 34, 87, 93, '2023-03-14 02:22:19', NULL, NULL),
(46, 'EventTestWaheed 9-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'Default.jpg', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-04-11 02:59:57', NULL, NULL),
(47, 'EventTestWaheed 9-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'MTY0MzVmNWU2YjVlZWE4LjUzMjAyNzEz.png', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-04-12 02:05:58', NULL, NULL),
(48, 'EventTestWaheed 9-3-2023', 'EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1EventTest1', 'MTY0MzYwNWFiMmY5ODkyLjA1OTk2OTM3.png', NULL, '2023-03-08 12:30:00', 'شقة الاستاذ حسن', 0, 1, 2, 1, '2023-04-12 03:13:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Expense`
--

CREATE TABLE `Expense` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explaination` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Price` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Expense`
--

INSERT INTO `Expense` (`ID`, `Name`, `Explaination`, `Price`) VALUES
(1, 'مرافق', 'فواتير الكهرباء والمياه و الغاز', 150),
(2, 'اجرة البواب', 'مرتب شهري للبواب', 2000),
(3, 'نظافة', 'مشتروات نظافة واجرة عامل النظافة', 50),
(4, 'الصيانة الشهرية', 'مبلغ الصيانة الدورية للعمارة او اشتراك عضوية اتحاد الملاك', 100);

-- --------------------------------------------------------

--
-- Table structure for table `Favourite`
--

CREATE TABLE `Favourite` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `NeighbourID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Favourite`
--

INSERT INTO `Favourite` (`ID`, `Name`, `ResidentID`, `ApartmentID`, `BlockID`, `CategoryID`, `ServiceID`, `NeighbourID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(24, 'محمود الشيمي', 1, 2, 1, 2, 63, NULL, '2023-03-12 01:52:20', NULL, NULL),
(35, 'محمود الشيمي', 26, 75, 1, 2, 63, NULL, '2023-03-12 02:57:43', NULL, NULL),
(36, 'Muhammad Waheed', 1, 2, 1, 1, NULL, 1, '2023-03-12 03:32:24', NULL, NULL),
(39, 'محمود الشيمي', 1, 2, 1, 2, 63, NULL, '2023-03-12 10:15:14', NULL, NULL),
(64, 'Muhammad Waheed531', 26, 75, 1, 1, NULL, 3, '2023-03-13 04:48:06', NULL, NULL),
(65, 'محمود الشيمي', 34, 82, 78, 2, 63, NULL, '2023-04-12 05:38:09', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Fee`
--

CREATE TABLE `Fee` (
  `ID` int(11) NOT NULL,
  `Amount` int(11) DEFAULT NULL,
  `PaymentMethod` int(11) DEFAULT NULL,
  `DueDate` datetime DEFAULT NULL,
  `PaymentDate` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RepeatStatusID` int(11) DEFAULT NULL,
  `BillID` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ExpenseID` int(11) DEFAULT NULL,
  `CashierID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL,
  `FeeStatment` text COLLATE utf8_unicode_ci NOT NULL,
  `PartialAmount` int(11) NOT NULL,
  `LastPartialDate` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Fee`
--

INSERT INTO `Fee` (`ID`, `Amount`, `PaymentMethod`, `DueDate`, `PaymentDate`, `RepeatStatusID`, `BillID`, `ExpenseID`, `CashierID`, `BlockID`, `ApartmentID`, `Date`, `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`, `FeeStatment`, `PartialAmount`, `LastPartialDate`) VALUES
(1, 150, 1, NULL, NULL, 5, 'B1A2I2', 2, 1, 1, 2, '2023-02-19 01:35:30pm', '2023-02-19 01:45:26', 1, NULL, NULL, 'تحميل حصة الشقة رقم 2 من فواتيراجرة البواب', 0, ''),
(2, 123, 1, '2023-02-20 04:17:17', NULL, NULL, NULL, 1, 1, 1, 2, '2023-01-24', '2023-02-19 04:17:17', 1, NULL, NULL, '', 0, ''),
(4, 100, 1, '2023-02-22 13:53:39', NULL, 5, NULL, 4, 1, 1, 2, '2023-01-14 12:27', '2023-02-21 13:53:39', 1, NULL, NULL, 'حصة الشقة في الصيانة الشهرية للعمارة', 0, ''),
(5, 150, NULL, '2023-04-09 15:16:58', NULL, 5, NULL, 4, 26, 73, 77, '2023-01-14 12:27', '2023-03-09 15:16:58', 26, NULL, NULL, 'الصيانة الشهرية بيقولك وحيد', 0, ''),
(6, 123, NULL, '2023-03-31 17:04:22', NULL, NULL, NULL, 1, 1, 1, 2, '2023-03-26 05:20:30pm', '2023-03-26 17:04:22', 1, NULL, NULL, 'Fee Statement Test By Waheed ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `FinancialAcount`
--

CREATE TABLE `FinancialAcount` (
  `ID` int(11) NOT NULL,
  `Balance` int(11) DEFAULT NULL,
  `MonthIncome` int(11) NOT NULL,
  `MonthExpense` int(11) NOT NULL,
  `FeeAmount` int(11) DEFAULT NULL,
  `MonthlyFeeAmount` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `FinancialAcount`
--

INSERT INTO `FinancialAcount` (`ID`, `Balance`, `MonthIncome`, `MonthExpense`, `FeeAmount`, `MonthlyFeeAmount`, `BlockID`, `ApartmentID`, `ResidentID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1000, 0, 0, 0, NULL, 1, NULL, NULL, '2023-02-19 20:55:41', NULL, NULL),
(2, 2000, 0, 0, 273, 100, 1, 2, 1, '2023-02-19 11:03:03', NULL, NULL),
(3, 3000, 0, 0, 0, 0, 68, NULL, NULL, '2023-02-19 11:04:12', NULL, NULL),
(7, 0, 0, 0, 0, 0, 70, NULL, 1, '2023-02-19 11:07:37', NULL, NULL),
(8, 0, 0, 0, 0, 0, 70, 73, 1, '2023-02-19 11:07:37', NULL, NULL),
(9, 0, 0, 0, 0, 0, 71, NULL, 1, '2023-02-22 02:16:18', NULL, NULL),
(10, 0, 0, 0, 0, 0, 71, 74, 1, '2023-02-22 02:16:18', NULL, NULL),
(11, 0, 0, 0, 0, 0, 72, NULL, 1, '2023-02-22 04:55:53', NULL, NULL),
(12, 0, 0, 0, 0, 0, 72, 76, 1, '2023-02-22 04:55:53', NULL, NULL),
(13, 0, 0, 0, 0, 0, 73, NULL, 26, '2023-02-22 05:09:24', NULL, NULL),
(14, 0, 0, 0, 0, 0, 73, 77, 26, '2023-02-22 05:09:24', NULL, NULL),
(15, 0, 0, 0, 0, 0, 74, NULL, 1, '2023-02-22 05:13:44', NULL, NULL),
(16, 0, 0, 0, 0, 0, 74, 78, 1, '2023-02-22 05:13:44', NULL, NULL),
(17, 0, 0, 0, 0, 0, 75, NULL, 1, '2023-02-23 12:19:07', NULL, NULL),
(18, 0, 0, 0, 0, 0, 75, 79, 1, '2023-02-23 12:19:07', NULL, NULL),
(19, 0, 0, 0, 0, 0, 76, NULL, 1, '2023-02-23 02:37:20', NULL, NULL),
(20, 0, 0, 0, 0, 0, 76, 80, 1, '2023-02-23 02:37:20', NULL, NULL),
(21, 0, 0, 0, 0, 0, 77, NULL, 26, '2023-02-23 02:52:24', NULL, NULL),
(22, 0, 0, 0, 0, 0, 77, 81, 26, '2023-02-23 02:52:24', NULL, NULL),
(23, 0, 0, 0, 0, 0, 78, NULL, 34, '2023-02-27 02:42:37', NULL, NULL),
(24, 0, 0, 0, 0, 0, 78, 82, 34, '2023-02-27 02:42:37', NULL, NULL),
(25, 0, 0, 0, 0, 0, 84, NULL, 1, '2023-03-06 06:48:46', NULL, NULL),
(26, 0, 0, 0, 0, 0, 84, 83, 1, '2023-03-06 06:48:46', NULL, NULL),
(27, 0, 0, 0, 0, 0, 90, NULL, 39, '2023-03-07 05:41:32', NULL, NULL),
(28, 0, 0, 0, 0, 0, 90, 84, 39, '2023-03-07 05:41:32', NULL, NULL),
(29, 0, 0, 0, 0, 0, 91, NULL, 39, '2023-03-09 10:12:12', NULL, NULL),
(30, 0, 0, 0, 0, 0, 91, 85, 39, '2023-03-09 10:12:12', NULL, NULL),
(31, 0, 0, 0, 0, 0, 92, NULL, 1, '2023-03-09 03:25:41', NULL, NULL),
(32, 0, 0, 0, 0, 0, 92, 86, 1, '2023-03-09 03:25:41', NULL, NULL),
(33, 0, 0, 0, 0, 0, 93, NULL, 34, '2023-03-10 10:53:35', NULL, NULL),
(34, 0, 0, 0, 0, 0, 93, 87, 34, '2023-03-10 10:53:35', NULL, NULL),
(35, 0, 0, 0, 0, 0, 94, NULL, 34, '2023-03-13 07:43:29', NULL, NULL),
(36, 0, 0, 0, 0, 0, 94, 88, 34, '2023-03-13 07:43:29', NULL, NULL),
(37, 0, 0, 0, 0, 0, 95, NULL, 40, '2023-03-15 05:11:55', NULL, NULL),
(38, 0, 0, 0, 0, 0, 95, 89, 40, '2023-03-15 05:11:55', NULL, NULL),
(39, 0, 0, 0, 0, 0, 96, NULL, 1, '2023-03-27 17:15:35', NULL, NULL),
(40, 0, 0, 0, 0, 0, 96, 90, 1, '2023-03-27 17:15:35', NULL, NULL),
(41, 0, 0, 0, 0, 0, 1, 21, 1, '2023-03-28 10:58:36', NULL, NULL),
(42, 0, 0, 0, 0, 0, 1, 75, 1, '2023-03-28 10:59:26', NULL, NULL),
(44, 0, 0, 0, 0, 0, 96, 91, 1, '2023-03-28 13:17:48', NULL, NULL),
(45, 0, 0, 0, 0, 0, 96, 92, 3, '2023-03-28 13:32:45', NULL, NULL),
(46, 0, 0, 0, 0, 0, 1, 114, 1, '2023-03-28 14:48:26', NULL, NULL),
(47, 0, 0, 0, 0, 0, 1, 115, 1, '2023-03-28 14:51:01', NULL, NULL),
(48, 0, 0, 0, 0, 0, 1, 116, 1, '2023-03-28 14:52:18', NULL, NULL),
(49, 0, 0, 0, 0, 0, 1, 117, 1, '2023-03-28 14:54:33', NULL, NULL),
(50, 0, 0, 0, 0, 0, 1, 118, 1, '2023-03-28 14:55:21', NULL, NULL),
(51, 0, 0, 0, 0, 0, 1, 119, 1, '2023-03-28 14:58:31', NULL, NULL),
(52, 0, 0, 0, 0, 0, 1, 120, 1, '2023-03-28 15:00:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `FinancialLog`
--

CREATE TABLE `FinancialLog` (
  `ID` double NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `LogTypeID` int(11) DEFAULT NULL,
  `PaymentID` int(11) DEFAULT NULL,
  `Action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LogRecordInActualTable` int(11) DEFAULT NULL,
  `LogActualTable` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ApartmentTotalFee` int(11) DEFAULT NULL,
  `ApartmentTotalBalance` int(11) DEFAULT NULL,
  `BlockTotalFee` int(11) DEFAULT NULL,
  `BlockTotalBalance` int(11) DEFAULT NULL,
  `Longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Governate`
--

CREATE TABLE `Governate` (
  `ID` int(11) NOT NULL,
  `GOVName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GOVNameEN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Governate`
--

INSERT INTO `Governate` (`ID`, `GOVName`, `GOVNameEN`, `CountryID`) VALUES
(1, 'الجيزة', 'Giza', 67),
(2, 'القاهرة', 'Cairo', 67),
(3, 'الاسكندرية', 'Alexandria', 67),
(4, 'بورسعيد', 'Port Said', 67),
(5, 'اسوان', 'Aswan', 67),
(6, 'اسيوط', 'Asyut', 67),
(7, 'الاسماعيلية', 'Ismailia', 67),
(8, 'الاقصر', 'Luxor', 67),
(9, 'البحر الاحمر', 'The Red Sea', 67),
(10, 'البحيرة', 'Beheira', 67),
(11, 'الدقهلية', 'Dakahlia', 67),
(12, 'السويس', 'Suez', 67),
(13, 'الشرقية', 'Sharqiya', 67),
(14, 'الغربية', 'Gharbiya', 67),
(15, 'الفيوم', 'Fayoum', 67),
(16, 'القليوبية', 'Qalyubia', 67),
(17, 'المنوفية', 'Menoufia', 67),
(18, 'المنيا', 'Minya', 67),
(19, 'الوادي الجديد', 'New Valley', 67),
(20, 'بني سويف', 'Bani Sweif', 67),
(21, 'جنوب سيناء', 'South of Sinaa', 67),
(22, 'دمياط', 'Damietta', 67),
(23, 'سوهاج', 'Sohag', 67),
(24, 'شمال سيناء', 'North Sinai', 67),
(25, 'قنا', 'Qena', 67),
(26, 'كفر الشيخ', 'Kafr El-Sheikh', 67),
(27, 'مرسى مطروح', 'Marsa Matrouh', 67);

-- --------------------------------------------------------

--
-- Table structure for table `Income`
--

CREATE TABLE `Income` (
  `ID` int(11) NOT NULL,
  `Date` date DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BillID` int(11) DEFAULT NULL,
  `FinancialAcountID` int(11) DEFAULT NULL,
  `PaymentID` int(11) DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Likes`
--

CREATE TABLE `Likes` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `TableName` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RecordID` int(11) DEFAULT NULL,
  `UpLike` int(11) NOT NULL,
  `DownDisLike` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Likes`
--

INSERT INTO `Likes` (`ID`, `ResidentID`, `ApartmentID`, `BlockID`, `TableName`, `RecordID`, `UpLike`, `DownDisLike`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, 2, 1, 'Comment', 2, 1, 0, '2023-02-28 15:58:03', NULL, NULL),
(2, 1, 2, 1, 'Comment', 1, 0, 1, '2023-02-28 16:06:55', '2023-03-06 22:51:39', 1),
(3, 26, 77, 73, 'Comment', 31, 0, 1, '2023-03-06 14:04:01', NULL, NULL),
(4, 26, 77, 73, 'Comment', 32, 1, 0, '2023-03-06 14:05:06', '2023-03-07 14:30:42', 26),
(5, 26, 77, 73, 'Comment', 1, 1, NULL, '2023-03-06 14:05:35', NULL, NULL),
(6, 26, 77, 73, 'Comment', 30, 1, NULL, '2023-03-06 14:05:48', NULL, NULL),
(7, 26, 77, 73, 'Comment', 2, 0, 1, '2023-03-06 21:44:11', NULL, NULL),
(8, 26, 77, 73, 'Comment', 10, 1, NULL, '2023-03-06 21:52:39', NULL, NULL),
(9, 26, 77, 73, 'Comment', 9, 0, 1, '2023-03-06 22:23:06', NULL, NULL),
(10, 1, 2, 1, 'Complaint', 11, 0, 1, '2023-03-06 22:52:19', NULL, NULL),
(11, 1, 2, 1, 'Complaint', 8, 1, 0, '2023-03-06 23:01:59', '2023-03-06 23:02:29', 1),
(12, 26, 77, 73, 'Decision', 32, 0, 1, '2023-03-07 14:38:06', '2023-03-07 16:03:36', 26),
(13, 26, 77, 73, 'Decision', 31, 0, 1, '2023-03-07 15:08:35', '2023-03-07 15:08:51', 26),
(14, 26, 77, 73, '', 2, 1, NULL, '2023-03-09 14:25:11', NULL, NULL),
(15, 26, 77, 73, 'Suggestion', 2, 0, 1, '2023-03-09 14:30:25', '2023-03-09 14:34:08', 26),
(16, 34, 82, 78, 'Decision', 38, 1, 0, '2023-03-09 21:59:59', '2023-03-10 10:57:22', 34),
(17, 34, 82, 78, 'Decision', 37, 1, NULL, '2023-03-10 10:57:16', NULL, NULL),
(18, 34, 82, 78, 'Decision', 39, 1, NULL, '2023-03-16 09:54:03', NULL, NULL),
(19, 34, 82, 78, 'Decision', 41, 1, NULL, '2023-03-16 10:52:06', NULL, NULL),
(20, 34, 82, 78, 'Decision', 40, 0, 1, '2023-03-16 10:52:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Logs`
--

CREATE TABLE `Logs` (
  `ID` double NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `LogTypeID` int(11) DEFAULT NULL,
  `Action` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `LogRecordIdInActualTable` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `LogActualTable` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `Longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Logs`
--

INSERT INTO `Logs` (`ID`, `UserID`, `ApartmentID`, `BlockID`, `LogTypeID`, `Action`, `LogRecordIdInActualTable`, `LogActualTable`, `Longitude`, `Latitude`, `Date`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, 118, 1, 6, 'Creating New Apartment For Block Manager', '118', 'Apartment', '2123113', '45231', '2023-03-28 02:55:21pm', '2023-03-28 14:55:21', NULL, NULL),
(2, 1, 118, 1, 3, 'Creating Relation between resident and New Apartment For Block Manager', '143', 'RES_APART_BLOCK_ROLE', '2123113', '45231', '2023-03-28 02:55:21pm', '2023-03-28 14:55:21', NULL, NULL),
(3, 1, 118, 1, 3, 'Creating Financial Acount of the New Apartment For Block Manager', '', 'FinancialAcount', '2123113', '45231', '2023-03-28 02:55:21pm', '2023-03-28 14:55:21', NULL, NULL),
(4, 1, 119, 1, 6, 'Creating New Apartment For Block Manager', '119', 'Apartment', '2123113', '45231', '2023-03-28 02:58:31pm', '2023-03-28 14:58:31', NULL, NULL),
(5, 1, 119, 1, 3, 'Creating Relation between resident and New Apartment For Block Manager', '144', 'RES_APART_BLOCK_ROLE', '2123113', '45231', '2023-03-28 02:58:31pm', '2023-03-28 14:58:31', NULL, NULL),
(6, 1, 119, 1, 3, 'Creating Financial Acount of the New Apartment For Block Manager', '', 'FinancialAcount', '2123113', '45231', '2023-03-28 02:58:31pm', '2023-03-28 14:58:31', NULL, NULL),
(7, 1, 120, 1, 6, 'Creating New Apartment For Block Manager', '120', 'Apartment', '2123113', '45231', '2023-03-28 03:00:11pm', '2023-03-28 15:00:11', NULL, NULL),
(8, 1, 120, 1, 3, 'Creating Relation between resident and New Apartment For Block Manager', '145', 'RES_APART_BLOCK_ROLE', '2123113', '45231', '2023-03-28 03:00:11pm', '2023-03-28 15:00:11', NULL, NULL),
(9, 1, 120, 1, 3, 'Creating Financial Acount of the New Apartment For Block Manager', '52', 'FinancialAcount', '2123113', '45231', '2023-03-28 03:00:11pm', '2023-03-28 15:00:11', NULL, NULL),
(10, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '', '2023-03-30 05:56:06pm', '2023-03-30 17:56:06', NULL, NULL),
(11, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-03-30 21:57:14', NULL, '2023-03-30 21:57:14', 1),
(12, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-03-30 22:18:10', NULL, '2023-03-30 22:18:10', 1),
(13, 41, NULL, NULL, 1, 'New User Registration', '41', 'Resident_User', '', '', '2023-04-05 08:34:08pm', '2023-04-05 20:34:08', NULL, NULL),
(14, 1, 2, 1, 10, 'Publish News On block', '23', 'News', '453442', '1121212', '2023-04-10 02:53:54am', '2023-04-10 02:53:54', NULL, NULL),
(15, 1, 2, 1, 10, 'Publish News On block', '24', 'News', '453442', '1121212', '2023-04-10 02:54:35am', '2023-04-10 02:54:35', NULL, NULL),
(16, 1, 2, 1, 9, 'Create New Decision While creating meeting 45', '42', 'Decision', '1233454', '1212121', '2023-04-11 02:49:01pm', '2023-04-11 14:49:01', NULL, NULL),
(17, 1, 2, 1, 9, 'Create New Decision While creating meeting 45', '43', 'Decision', '1233454', '1212121', '2023-04-11 02:49:01pm', '2023-04-11 14:49:01', NULL, NULL),
(18, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '45', 'Meeting', '1233454', '1212121', '2023-04-11 02:49:01pm', '2023-04-11 14:49:01', NULL, NULL),
(19, 1, 2, 1, 8, 'Create New Event', '46', 'Event', '673423112', '123454321', '2023-04-11 02-59-57pm', '2023-04-11 02:59:57', NULL, NULL),
(20, 1, 2, 1, 9, 'Create New Decision While creating meeting 46', '44', 'Decision', '1233454', '1212121', '2023-04-12 12:57:20am', '2023-04-12 00:57:20', NULL, NULL),
(21, 1, 2, 1, 9, 'Create New Decision While creating meeting 46', '45', 'Decision', '1233454', '1212121', '2023-04-12 12:57:20am', '2023-04-12 00:57:20', NULL, NULL),
(22, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '46', 'Meeting', '1233454', '1212121', '2023-04-12 12:57:20am', '2023-04-12 00:57:20', NULL, NULL),
(23, 1, 2, 1, 9, 'Create New Decision While creating meeting 47', '46', 'Decision', '1233454', '1212121', '2023-04-12 01:27:30am', '2023-04-12 01:27:30', NULL, NULL),
(24, 1, 2, 1, 9, 'Create New Decision While creating meeting 47', '47', 'Decision', '1233454', '1212121', '2023-04-12 01:27:30am', '2023-04-12 01:27:30', NULL, NULL),
(25, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '47', 'Meeting', '1233454', '1212121', '2023-04-12 01:27:30am', '2023-04-12 01:27:30', NULL, NULL),
(26, 1, 2, 1, 9, 'Create New Decision While creating meeting 48', '48', 'Decision', '1233454', '1212121', '2023-04-12 01:27:59am', '2023-04-12 01:27:59', NULL, NULL),
(27, 1, 2, 1, 9, 'Create New Decision While creating meeting 48', '49', 'Decision', '1233454', '1212121', '2023-04-12 01:27:59am', '2023-04-12 01:27:59', NULL, NULL),
(28, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '48', 'Meeting', '1233454', '1212121', '2023-04-12 01:27:59am', '2023-04-12 01:27:59', NULL, NULL),
(29, 1, 2, 1, 9, 'Create New Decision While creating meeting 49', '50', 'Decision', '1233454', '1212121', '2023-04-12 01:30:43am', '2023-04-12 01:30:43', NULL, NULL),
(30, 1, 2, 1, 9, 'Create New Decision While creating meeting 49', '51', 'Decision', '1233454', '1212121', '2023-04-12 01:30:43am', '2023-04-12 01:30:43', NULL, NULL),
(31, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '49', 'Meeting', '1233454', '1212121', '2023-04-12 01:30:43am', '2023-04-12 01:30:43', NULL, NULL),
(32, 1, 2, 1, 9, 'Create New Decision While creating meeting 50', '52', 'Decision', '1233454', '1212121', '2023-04-12 01:31:41am', '2023-04-12 01:31:41', NULL, NULL),
(33, 1, 2, 1, 9, 'Create New Decision While creating meeting 50', '53', 'Decision', '1233454', '1212121', '2023-04-12 01:31:41am', '2023-04-12 01:31:41', NULL, NULL),
(34, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '50', 'Meeting', '1233454', '1212121', '2023-04-12 01:31:41am', '2023-04-12 01:31:41', NULL, NULL),
(35, 1, 2, 1, 9, 'Create New Decision While creating meeting 51', '54', 'Decision', '1233454', '1212121', '2023-04-12 01:32:06am', '2023-04-12 01:32:06', NULL, NULL),
(36, 1, 2, 1, 9, 'Create New Decision While creating meeting 51', '55', 'Decision', '1233454', '1212121', '2023-04-12 01:32:06am', '2023-04-12 01:32:06', NULL, NULL),
(37, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '51', 'Meeting', '1233454', '1212121', '2023-04-12 01:32:06am', '2023-04-12 01:32:06', NULL, NULL),
(38, 1, 2, 1, 9, 'Create New Decision While creating meeting 52', '56', 'Decision', '1233454', '1212121', '2023-04-12 01:59:00am', '2023-04-12 01:59:00', NULL, NULL),
(39, 1, 2, 1, 9, 'Create New Decision While creating meeting 52', '57', 'Decision', '1233454', '1212121', '2023-04-12 01:59:00am', '2023-04-12 01:59:00', NULL, NULL),
(40, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '52', 'Meeting', '1233454', '1212121', '2023-04-12 01:59:00am', '2023-04-12 01:59:00', NULL, NULL),
(41, 1, 2, 1, 9, 'Create New Decision While creating meeting 53', '58', 'Decision', '1233454', '1212121', '2023-04-12 02:00:56am', '2023-04-12 02:00:56', NULL, NULL),
(42, 1, 2, 1, 9, 'Create New Decision While creating meeting 53', '59', 'Decision', '1233454', '1212121', '2023-04-12 02:00:56am', '2023-04-12 02:00:56', NULL, NULL),
(43, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '53', 'Meeting', '1233454', '1212121', '2023-04-12 02:00:56am', '2023-04-12 02:00:56', NULL, NULL),
(44, 1, 2, 1, 9, 'Create New Decision While creating meeting 54', '60', 'Decision', '1233454', '1212121', '2023-04-12 02:01:41am', '2023-04-12 02:01:41', NULL, NULL),
(45, 1, 2, 1, 9, 'Create New Decision While creating meeting 54', '61', 'Decision', '1233454', '1212121', '2023-04-12 02:01:41am', '2023-04-12 02:01:41', NULL, NULL),
(46, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '54', 'Meeting', '1233454', '1212121', '2023-04-12 02:01:41am', '2023-04-12 02:01:41', NULL, NULL),
(47, 1, 2, 1, 9, 'Create New Decision While creating meeting 55', '62', 'Decision', '1233454', '1212121', '2023-04-12 02:02:09am', '2023-04-12 02:02:09', NULL, NULL),
(48, 1, 2, 1, 9, 'Create New Decision While creating meeting 55', '63', 'Decision', '1233454', '1212121', '2023-04-12 02:02:09am', '2023-04-12 02:02:09', NULL, NULL),
(49, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '55', 'Meeting', '1233454', '1212121', '2023-04-12 02:02:09am', '2023-04-12 02:02:09', NULL, NULL),
(50, 1, 2, 1, 9, 'Create New Decision While creating meeting 56', '64', 'Decision', '1233454', '1212121', '2023-04-12 02:02:30am', '2023-04-12 02:02:30', NULL, NULL),
(51, 1, 2, 1, 9, 'Create New Decision While creating meeting 56', '65', 'Decision', '1233454', '1212121', '2023-04-12 02:02:30am', '2023-04-12 02:02:30', NULL, NULL),
(52, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '56', 'Meeting', '1233454', '1212121', '2023-04-12 02:02:30am', '2023-04-12 02:02:30', NULL, NULL),
(53, 1, 2, 1, 8, 'Create New Event', '47', 'Event', '673423112', '123454321', '2023-04-12 02-05-58am', '2023-04-12 02:05:58', NULL, NULL),
(54, 1, 2, 1, 9, 'Create New Decision While creating meeting 57', '66', 'Decision', '1233454', '1212121', '2023-04-12 02:12:57am', '2023-04-12 02:12:57', NULL, NULL),
(55, 1, 2, 1, 9, 'Create New Decision While creating meeting 57', '67', 'Decision', '1233454', '1212121', '2023-04-12 02:12:57am', '2023-04-12 02:12:57', NULL, NULL),
(56, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '57', 'Meeting', '1233454', '1212121', '2023-04-12 02:12:57am', '2023-04-12 02:12:57', NULL, NULL),
(57, 1, 2, 1, 9, 'Create New Decision While creating meeting 58', '68', 'Decision', '1233454', '1212121', '2023-04-12 02:14:30am', '2023-04-12 02:14:30', NULL, NULL),
(58, 1, 2, 1, 9, 'Create New Decision While creating meeting 58', '69', 'Decision', '1233454', '1212121', '2023-04-12 02:14:30am', '2023-04-12 02:14:30', NULL, NULL),
(59, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '58', 'Meeting', '1233454', '1212121', '2023-04-12 02:14:30am', '2023-04-12 02:14:30', NULL, NULL),
(60, 1, 2, 1, 9, 'Create New Decision While creating meeting 59', '70', 'Decision', '1233454', '1212121', '2023-04-12 02:16:19am', '2023-04-12 02:16:19', NULL, NULL),
(61, 1, 2, 1, 9, 'Create New Decision While creating meeting 59', '71', 'Decision', '1233454', '1212121', '2023-04-12 02:16:19am', '2023-04-12 02:16:19', NULL, NULL),
(62, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '59', 'Meeting', '1233454', '1212121', '2023-04-12 02:16:19am', '2023-04-12 02:16:19', NULL, NULL),
(63, 1, 2, 1, 9, 'Create New Decision While creating meeting 60', '72', 'Decision', '1233454', '1212121', '2023-04-12 02:18:24am', '2023-04-12 02:18:24', NULL, NULL),
(64, 1, 2, 1, 9, 'Create New Decision While creating meeting 60', '73', 'Decision', '1233454', '1212121', '2023-04-12 02:18:24am', '2023-04-12 02:18:24', NULL, NULL),
(65, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '60', 'Meeting', '1233454', '1212121', '2023-04-12 02:18:24am', '2023-04-12 02:18:24', NULL, NULL),
(66, 1, 2, 1, 9, 'Create New Decision While creating meeting 61', '74', 'Decision', '1233454', '1212121', '2023-04-12 03:08:53am', '2023-04-12 03:08:53', NULL, NULL),
(67, 1, 2, 1, 9, 'Create New Decision While creating meeting 61', '75', 'Decision', '1233454', '1212121', '2023-04-12 03:08:53am', '2023-04-12 03:08:53', NULL, NULL),
(68, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '61', 'Meeting', '1233454', '1212121', '2023-04-12 03:08:53am', '2023-04-12 03:08:53', NULL, NULL),
(69, 1, 2, 1, 9, 'Create New Decision While creating meeting 62', '76', 'Decision', '1233454', '1212121', '2023-04-12 03:09:15am', '2023-04-12 03:09:15', NULL, NULL),
(70, 1, 2, 1, 9, 'Create New Decision While creating meeting 62', '77', 'Decision', '1233454', '1212121', '2023-04-12 03:09:15am', '2023-04-12 03:09:15', NULL, NULL),
(71, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '62', 'Meeting', '1233454', '1212121', '2023-04-12 03:09:15am', '2023-04-12 03:09:15', NULL, NULL),
(72, 1, 2, 1, 8, 'Create New Event', '48', 'Event', '673423112', '123454321', '2023-04-12 03-13-15am', '2023-04-12 03:13:15', NULL, NULL),
(73, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '', '2023-04-12 05:23:43pm', '2023-04-12 17:23:43', NULL, NULL),
(74, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-04-12 05:25:01pm', '2023-04-12 17:25:01', NULL, NULL),
(75, 34, 82, 78, 5, 'User Login', '34', 'Resident_User', '', '', '2023-04-12 05:28:50pm', '2023-04-12 17:28:50', NULL, NULL),
(76, 34, 82, 78, 13, 'Add to favourite', '65', 'Favourite', '4523', '', '2023-04-12 05:38:09', '2023-04-12 05:38:09', NULL, NULL),
(77, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-04-13 02:50:58am', '2023-04-13 02:50:58', NULL, NULL),
(78, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-04-17 03:42:23am', '2023-04-17 03:42:23', NULL, NULL),
(79, 1, 2, 1, 9, 'Create New Decision While creating meeting 63', '78', 'Decision', '1233454', '1212121', '2023-05-06 07:10:26pm', '2023-05-06 19:10:26', NULL, NULL),
(80, 1, 2, 1, 9, 'Create New Decision While creating meeting 63', '79', 'Decision', '1233454', '1212121', '2023-05-06 07:10:26pm', '2023-05-06 19:10:26', NULL, NULL),
(81, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '63', 'Meeting', '1233454', '1212121', '2023-05-06 07:10:26pm', '2023-05-06 19:10:26', NULL, NULL),
(82, 1, 2, 1, 9, 'Create New Decision While creating meeting 67', '80', 'Decision', '1233454', '1212121', '2023-05-11 10:11:15pm', '2023-05-11 22:11:15', NULL, NULL),
(83, 1, 2, 1, 9, 'Create New Decision While creating meeting 67', '81', 'Decision', '1233454', '1212121', '2023-05-11 10:11:15pm', '2023-05-11 22:11:15', NULL, NULL),
(84, 1, 2, 1, 7, 'Requst New Meeting from Block Manager', '67', 'Meeting', '1233454', '1212121', '2023-05-11 10:11:15pm', '2023-05-11 22:11:15', NULL, NULL),
(85, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 01:58:32am', '2023-05-15 01:58:32', NULL, NULL),
(86, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:12:23am', '2023-05-15 02:12:23', NULL, NULL),
(87, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:13:06am', '2023-05-15 02:13:06', NULL, NULL),
(88, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:21:44am', '2023-05-15 02:21:44', NULL, NULL),
(89, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:23:02am', '2023-05-15 02:23:02', NULL, NULL),
(90, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:23:11am', '2023-05-15 02:23:11', NULL, NULL),
(91, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:25:47am', '2023-05-15 02:25:47', NULL, NULL),
(92, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:25:56am', '2023-05-15 02:25:56', NULL, NULL),
(93, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:29:40am', '2023-05-15 02:29:40', NULL, NULL),
(94, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:30:14am', '2023-05-15 02:30:14', NULL, NULL),
(95, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 02:30:55am', '2023-05-15 02:30:55', NULL, NULL),
(96, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 08:14:02pm', '2023-05-15 20:14:02', NULL, NULL),
(97, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 08:15:30pm', '2023-05-15 20:15:30', NULL, NULL),
(98, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 08:16:43pm', '2023-05-15 20:16:43', NULL, NULL),
(99, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 08:17:10pm', '2023-05-15 20:17:10', NULL, NULL),
(100, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-15 08:30:34pm', '2023-05-15 20:30:34', NULL, NULL),
(101, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 10:55:57am', '2023-05-16 10:55:57', NULL, NULL),
(102, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 10:56:20am', '2023-05-16 10:56:20', NULL, NULL),
(103, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 10:56:38am', '2023-05-16 10:56:38', NULL, NULL),
(104, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 10:57:03am', '2023-05-16 10:57:03', NULL, NULL),
(105, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 10:58:29am', '2023-05-16 10:58:29', NULL, NULL),
(106, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:00:10am', '2023-05-16 11:00:10', NULL, NULL),
(107, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:03:47am', '2023-05-16 11:03:47', NULL, NULL),
(108, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:06:13am', '2023-05-16 11:06:13', NULL, NULL),
(109, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:06:24am', '2023-05-16 11:06:24', NULL, NULL),
(110, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:07:03am', '2023-05-16 11:07:03', NULL, NULL),
(111, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:07:56am', '2023-05-16 11:07:56', NULL, NULL),
(112, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:08:13am', '2023-05-16 11:08:13', NULL, NULL),
(113, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:09:19am', '2023-05-16 11:09:19', NULL, NULL),
(114, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:11:31am', '2023-05-16 11:11:31', NULL, NULL),
(115, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:12:07am', '2023-05-16 11:12:07', NULL, NULL),
(116, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:12:18am', '2023-05-16 11:12:18', NULL, NULL),
(117, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:14:20am', '2023-05-16 11:14:20', NULL, NULL),
(118, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:14:31am', '2023-05-16 11:14:31', NULL, NULL),
(119, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:15:07am', '2023-05-16 11:15:07', NULL, NULL),
(120, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:16:26am', '2023-05-16 11:16:26', NULL, NULL),
(121, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:16:54am', '2023-05-16 11:16:54', NULL, NULL),
(122, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:17:48am', '2023-05-16 11:17:48', NULL, NULL),
(123, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:20:17am', '2023-05-16 11:20:17', NULL, NULL),
(124, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:20:39am', '2023-05-16 11:20:39', NULL, NULL),
(125, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:20:56am', '2023-05-16 11:20:56', NULL, NULL),
(126, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:23:30am', '2023-05-16 11:23:30', NULL, NULL),
(127, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:23:47am', '2023-05-16 11:23:47', NULL, NULL),
(128, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:24:06am', '2023-05-16 11:24:06', NULL, NULL),
(129, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:24:21am', '2023-05-16 11:24:21', NULL, NULL),
(130, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:24:58am', '2023-05-16 11:24:58', NULL, NULL),
(131, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:31:02am', '2023-05-16 11:31:02', NULL, NULL),
(132, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:32:10am', '2023-05-16 11:32:10', NULL, NULL),
(133, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:33:07am', '2023-05-16 11:33:07', NULL, NULL),
(134, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:33:20am', '2023-05-16 11:33:20', NULL, NULL),
(135, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:33:31am', '2023-05-16 11:33:31', NULL, NULL),
(136, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:33:47am', '2023-05-16 11:33:47', NULL, NULL),
(137, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:35:37am', '2023-05-16 11:35:37', NULL, NULL),
(138, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:35:53am', '2023-05-16 11:35:53', NULL, NULL),
(139, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:39:07am', '2023-05-16 11:39:07', NULL, NULL),
(140, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:41:10am', '2023-05-16 11:41:10', NULL, NULL),
(141, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:41:39am', '2023-05-16 11:41:39', NULL, NULL),
(142, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:42:09am', '2023-05-16 11:42:09', NULL, NULL),
(143, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:42:39am', '2023-05-16 11:42:39', NULL, NULL),
(144, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:43:36am', '2023-05-16 11:43:36', NULL, NULL),
(145, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:43:56am', '2023-05-16 11:43:56', NULL, NULL),
(146, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:44:08am', '2023-05-16 11:44:08', NULL, NULL),
(147, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:44:33am', '2023-05-16 11:44:33', NULL, NULL),
(148, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:44:56am', '2023-05-16 11:44:56', NULL, NULL),
(149, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:45:15am', '2023-05-16 11:45:15', NULL, NULL),
(150, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:45:36am', '2023-05-16 11:45:36', NULL, NULL),
(151, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:46:13am', '2023-05-16 11:46:13', NULL, NULL),
(152, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '', '2023-05-16 11:46:32am', '2023-05-16 11:46:32', NULL, NULL),
(153, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:33:03pm', '2023-05-16 12:33:03', NULL, NULL),
(154, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:33:37pm', '2023-05-16 12:33:37', NULL, NULL),
(155, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:34:06pm', '2023-05-16 12:34:06', NULL, NULL),
(156, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:34:20pm', '2023-05-16 12:34:20', NULL, NULL),
(157, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:35:33pm', '2023-05-16 12:35:33', NULL, NULL),
(158, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:36:34pm', '2023-05-16 12:36:34', NULL, NULL),
(159, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:37:38pm', '2023-05-16 12:37:38', NULL, NULL),
(160, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:37:58pm', '2023-05-16 12:37:58', NULL, NULL),
(161, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:38:24pm', '2023-05-16 12:38:24', NULL, NULL),
(162, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:38:34pm', '2023-05-16 12:38:34', NULL, NULL),
(163, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:39:29pm', '2023-05-16 12:39:29', NULL, NULL),
(164, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-16 12:39:53pm', '2023-05-16 12:39:53', NULL, NULL),
(165, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:55:22pm', '2023-05-16 12:55:22', NULL, NULL),
(166, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:55:35pm', '2023-05-16 12:55:35', NULL, NULL),
(167, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:56:47pm', '2023-05-16 12:56:47', NULL, NULL),
(168, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:57:21pm', '2023-05-16 12:57:21', NULL, NULL),
(169, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:58:51pm', '2023-05-16 12:58:51', NULL, NULL),
(170, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:59:29pm', '2023-05-16 12:59:29', NULL, NULL),
(171, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 12:59:42pm', '2023-05-16 12:59:42', NULL, NULL),
(172, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 01:00:09pm', '2023-05-16 13:00:09', NULL, NULL),
(173, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '12312', '12312', '2023-05-16 01:00:34pm', '2023-05-16 13:00:34', NULL, NULL),
(174, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-16 02:56:44pm', '2023-05-16 14:56:44', NULL, NULL),
(175, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-17 02:58:10pm', '2023-05-17 14:58:10', NULL, NULL),
(176, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-17 02:58:47pm', '2023-05-17 14:58:47', NULL, NULL),
(177, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-17 03:00:31pm', '2023-05-17 15:00:31', NULL, NULL),
(178, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-17 03:01:17pm', '2023-05-17 15:01:17', NULL, NULL),
(179, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-17 03:02:40pm', '2023-05-17 15:02:40', NULL, NULL),
(180, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:34:39am', '2023-05-20 01:34:39', NULL, NULL),
(181, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:34:50am', '2023-05-20 01:34:50', NULL, NULL),
(182, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:35:03am', '2023-05-20 01:35:03', NULL, NULL),
(183, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:35:22am', '2023-05-20 01:35:22', NULL, NULL),
(184, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:35:40am', '2023-05-20 01:35:40', NULL, NULL),
(185, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:37:01am', '2023-05-20 01:37:01', NULL, NULL),
(186, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:55:35am', '2023-05-20 01:55:35', NULL, NULL),
(187, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:56:08am', '2023-05-20 01:56:08', NULL, NULL),
(188, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:56:44am', '2023-05-20 01:56:44', NULL, NULL),
(189, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:57:25am', '2023-05-20 01:57:25', NULL, NULL),
(190, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:58:35am', '2023-05-20 01:58:35', NULL, NULL),
(191, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:59:05am', '2023-05-20 01:59:05', NULL, NULL),
(192, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 01:59:56am', '2023-05-20 01:59:56', NULL, NULL),
(193, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:00:26am', '2023-05-20 02:00:26', NULL, NULL),
(194, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:00:43am', '2023-05-20 02:00:43', NULL, NULL),
(195, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:01:18am', '2023-05-20 02:01:18', NULL, NULL),
(196, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:01:58am', '2023-05-20 02:01:58', NULL, NULL),
(197, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:03:32am', '2023-05-20 02:03:32', NULL, NULL),
(198, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:04:04am', '2023-05-20 02:04:04', NULL, NULL),
(199, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:04:23am', '2023-05-20 02:04:23', NULL, NULL),
(200, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:05:55am', '2023-05-20 02:05:55', NULL, NULL),
(201, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:09:00am', '2023-05-20 02:09:00', NULL, NULL),
(202, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:10:53am', '2023-05-20 02:10:53', NULL, NULL),
(203, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:16:05am', '2023-05-20 02:16:05', NULL, NULL),
(204, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:16:38am', '2023-05-20 02:16:38', NULL, NULL),
(205, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:17:26am', '2023-05-20 02:17:26', NULL, NULL),
(206, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:17:38am', '2023-05-20 02:17:38', NULL, NULL),
(207, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:19:06am', '2023-05-20 02:19:06', NULL, NULL),
(208, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:22:22am', '2023-05-20 02:22:22', NULL, NULL),
(209, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:22:36am', '2023-05-20 02:22:36', NULL, NULL),
(210, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:23:24am', '2023-05-20 02:23:24', NULL, NULL),
(211, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:23:37am', '2023-05-20 02:23:37', NULL, NULL),
(212, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:24:00am', '2023-05-20 02:24:00', NULL, NULL),
(213, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:25:54am', '2023-05-20 02:25:54', NULL, NULL),
(214, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:26:06am', '2023-05-20 02:26:06', NULL, NULL),
(215, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:26:20am', '2023-05-20 02:26:20', NULL, NULL),
(216, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:27:43am', '2023-05-20 02:27:43', NULL, NULL),
(217, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:27:58am', '2023-05-20 02:27:58', NULL, NULL),
(218, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:29:56am', '2023-05-20 02:29:56', NULL, NULL),
(219, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:30:07am', '2023-05-20 02:30:07', NULL, NULL),
(220, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:30:22am', '2023-05-20 02:30:22', NULL, NULL),
(221, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:30:52am', '2023-05-20 02:30:52', NULL, NULL),
(222, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:32:18am', '2023-05-20 02:32:18', NULL, NULL),
(223, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:33:20am', '2023-05-20 02:33:20', NULL, NULL),
(224, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:33:38am', '2023-05-20 02:33:38', NULL, NULL),
(225, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:33:51am', '2023-05-20 02:33:51', NULL, NULL),
(226, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:34:46am', '2023-05-20 02:34:46', NULL, NULL),
(227, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:44:01am', '2023-05-20 02:44:01', NULL, NULL),
(228, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:45:57am', '2023-05-20 02:45:57', NULL, NULL),
(229, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:47:01am', '2023-05-20 02:47:01', NULL, NULL),
(230, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:47:35am', '2023-05-20 02:47:35', NULL, NULL),
(231, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:49:13am', '2023-05-20 02:49:13', NULL, NULL),
(232, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:49:40am', '2023-05-20 02:49:40', NULL, NULL),
(233, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:50:04am', '2023-05-20 02:50:04', NULL, NULL),
(234, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:50:26am', '2023-05-20 02:50:26', NULL, NULL),
(235, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:51:15am', '2023-05-20 02:51:15', NULL, NULL),
(236, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:51:29am', '2023-05-20 02:51:29', NULL, NULL),
(237, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:54:16am', '2023-05-20 02:54:16', NULL, NULL),
(238, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:55:01am', '2023-05-20 02:55:01', NULL, NULL),
(239, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:59:11am', '2023-05-20 02:59:11', NULL, NULL),
(240, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 02:59:41am', '2023-05-20 02:59:41', NULL, NULL),
(241, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-20 03:00:14am', '2023-05-20 03:00:14', NULL, NULL),
(242, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 03:33:37pm', '2023-05-21 15:33:37', NULL, NULL),
(243, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 03:33:46pm', '2023-05-21 15:33:46', NULL, NULL),
(244, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 03:34:05pm', '2023-05-21 15:34:05', NULL, NULL),
(245, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 03:34:46pm', '2023-05-21 15:34:46', NULL, NULL),
(246, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 03:35:09pm', '2023-05-21 15:35:09', NULL, NULL),
(247, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:48:27pm', '2023-05-21 19:48:27', NULL, NULL),
(248, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:51:15pm', '2023-05-21 19:51:15', NULL, NULL),
(249, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:54:10pm', '2023-05-21 19:54:10', NULL, NULL),
(250, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:54:26pm', '2023-05-21 19:54:26', NULL, NULL),
(251, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:54:45pm', '2023-05-21 19:54:45', NULL, NULL),
(252, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:55:27pm', '2023-05-21 19:55:27', NULL, NULL),
(253, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:56:17pm', '2023-05-21 19:56:17', NULL, NULL),
(254, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:58:28pm', '2023-05-21 19:58:28', NULL, NULL),
(255, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:58:42pm', '2023-05-21 19:58:42', NULL, NULL),
(256, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:59:14pm', '2023-05-21 19:59:14', NULL, NULL),
(257, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 07:59:53pm', '2023-05-21 19:59:53', NULL, NULL),
(258, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:03:31pm', '2023-05-21 20:03:31', NULL, NULL),
(259, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:04:15pm', '2023-05-21 20:04:15', NULL, NULL),
(260, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:04:27pm', '2023-05-21 20:04:27', NULL, NULL),
(261, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:12:14pm', '2023-05-21 20:12:14', NULL, NULL),
(262, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:12:36pm', '2023-05-21 20:12:36', NULL, NULL),
(263, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:15:04pm', '2023-05-21 20:15:04', NULL, NULL),
(264, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:15:21pm', '2023-05-21 20:15:21', NULL, NULL),
(265, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:20:27pm', '2023-05-21 20:20:27', NULL, NULL),
(266, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:20:42pm', '2023-05-21 20:20:42', NULL, NULL),
(267, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:23:04pm', '2023-05-21 20:23:04', NULL, NULL),
(268, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:24:54pm', '2023-05-21 20:24:54', NULL, NULL),
(269, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:25:11pm', '2023-05-21 20:25:11', NULL, NULL),
(270, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:25:23pm', '2023-05-21 20:25:23', NULL, NULL),
(271, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:25:41pm', '2023-05-21 20:25:41', NULL, NULL),
(272, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:26:17pm', '2023-05-21 20:26:17', NULL, NULL),
(273, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:26:30pm', '2023-05-21 20:26:30', NULL, NULL),
(274, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:26:41pm', '2023-05-21 20:26:41', NULL, NULL),
(275, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-21 08:26:59pm', '2023-05-21 20:26:59', NULL, NULL),
(276, 1, 2, 1, 3, 'Insert New Attendee To Meeting ID : 67.', '20', 'Attendees', '12', '13', '2023-05-22 04-20-34pm', '2023-05-22 16:20:34', NULL, NULL),
(277, 1, 2, 1, 3, 'Insert New Attendee To Meeting ID : 67.', '20', 'Attendees', '12', '13', '2023-05-22 04-20-56pm', '2023-05-22 16:20:56', NULL, NULL),
(278, 1, 2, 1, 3, 'Insert New Attendee To Meeting ID : 67.', '20', 'Attendees', '12', '13', '2023-05-22 04-21-05pm', '2023-05-22 16:21:05', NULL, NULL),
(279, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:11:33', NULL, '2023-05-22 18:11:33', 1),
(280, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:12:02', NULL, '2023-05-22 18:12:02', 1),
(281, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:12:53', NULL, '2023-05-22 18:12:53', 1),
(282, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:13:52', NULL, '2023-05-22 18:13:52', 1),
(283, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:14:02', NULL, '2023-05-22 18:14:02', 1),
(284, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:15:38', NULL, '2023-05-22 18:15:38', 1),
(285, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-22 18:18:26', NULL, '2023-05-22 18:18:26', 1),
(286, 1, 2, 1, 16, 'Updating User password', '1', 'Resident_User', '243431', '23412', '2023:05:22 06-19-10pm', NULL, '2023-05-22 06:19:10', 1),
(287, 1, 2, 1, 16, 'Updating User password', '1', 'Resident_User', '243431', '23412', '2023:05:22 06-20-26pm', NULL, '2023-05-22 06:20:26', 1),
(288, 1, 2, 1, 16, 'Updating User password', '1', 'Resident_User', '243431', '23412', '2023:05:22 06-21-13pm', NULL, '2023-05-22 06:21:13', 1),
(295, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 18:59:51pm', NULL, '2023-05-22 18:59:51', 0),
(296, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:01:34pm', NULL, '2023-05-22 19:01:34', 0),
(297, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:02:56pm', NULL, '2023-05-22 19:02:56', 0),
(298, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:04:15pm', NULL, '2023-05-22 19:04:15', 0),
(299, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:05:58pm', NULL, '2023-05-22 19:05:58', 0),
(300, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:08:10pm', NULL, '2023-05-22 19:08:10', 0),
(301, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:14:21pm', NULL, '2023-05-22 19:14:21', 0),
(302, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:16:09pm', NULL, '2023-05-22 19:16:09', 0),
(303, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:18:40pm', NULL, '2023-05-22 19:18:40', 0),
(304, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-22 19:19:52pm', NULL, '2023-05-22 19:19:52', 0),
(305, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:22 07-26-45pm', NULL, '2023-05-22 07:26:45', NULL),
(306, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:22 07-27-51pm', NULL, '2023-05-22 07:27:51', NULL),
(307, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:22 07-28-21pm', NULL, '2023-05-22 07:28:21', NULL),
(308, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:23 10-55-18am', NULL, '2023-05-23 10:55:18', NULL),
(309, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:23 10-55-26am', NULL, '2023-05-23 10:55:26', NULL),
(310, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:23 10-55-30am', NULL, '2023-05-23 10:55:30', NULL),
(311, 1, 2, 1, 15, 'Updating Apartment Data', '', '', NULL, NULL, '2023:05:23 10-55-39am', NULL, '2023-05-23 10:55:39', NULL),
(312, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 10:59:59am', NULL, '2023-05-23 10:59:59', 0),
(313, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 11:02:20am', NULL, '2023-05-23 11:02:20', 0),
(314, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 11:02:37am', NULL, '2023-05-23 11:02:37', 0),
(315, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 11:02:45am', NULL, '2023-05-23 11:02:45', 0),
(316, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 11:02:52am', NULL, '2023-05-23 11:02:52', 0),
(317, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 11:03:10am', NULL, '2023-05-23 11:03:10', 0),
(318, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-03-52am', NULL, '2023-05-23 11:03:52', NULL),
(319, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-05-20am', NULL, '2023-05-23 11:05:20', NULL),
(320, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-07-53am', NULL, '2023-05-23 11:07:53', NULL),
(321, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-23 11:19:09', NULL, '2023-05-23 11:19:09', 1),
(322, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-22-29am', NULL, '2023-05-23 11:22:29', NULL),
(323, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-30-34am', NULL, '2023-05-23 11:30:34', NULL),
(324, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-34-44am', NULL, '2023-05-23 11:34:44', NULL),
(325, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-36-15am', NULL, '2023-05-23 11:36:15', NULL),
(326, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-36-24am', NULL, '2023-05-23 11:36:24', NULL),
(327, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-39-12am', NULL, '2023-05-23 11:39:12', NULL),
(328, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-39-27am', NULL, '2023-05-23 11:39:27', NULL),
(329, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-40-08am', NULL, '2023-05-23 11:40:08', NULL),
(330, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-40-19am', NULL, '2023-05-23 11:40:19', NULL),
(331, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-52-12am', NULL, '2023-05-23 11:52:12', NULL),
(332, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-54-56am', NULL, '2023-05-23 11:54:56', NULL),
(333, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-57-49am', NULL, '2023-05-23 11:57:49', NULL),
(334, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-58-49am', NULL, '2023-05-23 11:58:49', NULL),
(335, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 11-59-52am', NULL, '2023-05-23 11:59:52', NULL),
(336, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-03-04pm', NULL, '2023-05-23 12:03:04', NULL),
(337, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-05-33pm', NULL, '2023-05-23 12:05:33', NULL),
(338, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-05-53pm', NULL, '2023-05-23 12:05:53', NULL),
(339, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-09-55pm', NULL, '2023-05-23 12:09:55', NULL),
(340, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-11-26pm', NULL, '2023-05-23 12:11:26', NULL),
(341, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-22-52pm', NULL, '2023-05-23 12:22:52', NULL),
(342, 1, 2, 1, 15, 'Update New Event', '1', 'Event', '8372931', '2762312', '2023-05-23 12-23-41pm', NULL, '2023-05-23 12:23:41', NULL),
(343, 1, 2, 1, 3, 'Insert New Email for user', '4', 'Emails', '', '', '2023-05-23 12:45:09', NULL, '2023-05-23 12:45:09', 0),
(344, 1, 2, 1, 3, 'Insert New Email for user', '5', 'Emails', '0', '0', '2023-05-23 12:49:13', NULL, '2023-05-23 12:49:13', 0),
(345, 1, 2, 1, 3, 'Insert New Email for user', '6', 'Emails', '0', '0', '2023-05-23 12:54:42', NULL, '2023-05-23 12:54:42', 1),
(346, 1, 2, 1, 3, 'Insert New Phone Number for user', '1', 'PhoneNums', '0', '0', '2023-05-23 12:54:42', NULL, '2023-05-23 12:54:42', 1),
(347, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:03:57', NULL, '2023-05-23 13:03:57', 1),
(348, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:37:16', NULL, '2023-05-23 13:37:16', 1),
(349, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:39:27', NULL, '2023-05-23 13:39:27', 1),
(350, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:41:50', NULL, '2023-05-23 13:41:50', 1),
(351, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:43:26', NULL, '2023-05-23 13:43:26', 1),
(352, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:44:06', NULL, '2023-05-23 13:44:06', 1),
(353, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:44:39', NULL, '2023-05-23 13:44:39', 1),
(354, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:45:30', NULL, '2023-05-23 13:45:30', 1),
(355, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:47:35', NULL, '2023-05-23 13:47:35', 1),
(356, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:48:54', NULL, '2023-05-23 13:48:54', 1),
(357, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:49:25', NULL, '2023-05-23 13:49:25', 1),
(358, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:50:18', NULL, '2023-05-23 13:50:18', 1),
(359, 1, 2, 1, 3, 'Insert New Phone Number for user', '3', 'PhoneNums', '0', '0', '2023-05-23 13:50:49', NULL, '2023-05-23 13:50:49', 1),
(360, 1, 2, 1, 3, 'Insert New Email for user', '7', 'Emails', '0', '0', '2023-05-23 13:53:28', NULL, '2023-05-23 13:53:28', 1),
(361, 1, 2, 1, 3, 'Insert New Email for user', '7', 'Emails', '0', '0', '2023-05-23 13:56:37', NULL, '2023-05-23 13:56:37', 1),
(362, 1, 2, 1, 3, 'Insert New Email for user', '7', 'Emails', '0', '0', '2023-05-23 13:57:26', NULL, '2023-05-23 13:57:26', 1),
(363, 1, 2, 1, 3, 'Insert New Email for user', '7', 'Emails', '0', '0', '2023-05-23 13:57:54', NULL, '2023-05-23 13:57:54', 1),
(364, 1, 2, 1, 3, 'Insert New Email for user', '7', 'Emails', '0', '0', '2023-05-23 13:58:35', NULL, '2023-05-23 13:58:35', 1),
(365, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:28:57pm', NULL, '2023-05-23 14:28:57', 0),
(366, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:33:55pm', NULL, '2023-05-23 14:33:55', 0),
(367, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:35:16pm', NULL, '2023-05-23 14:35:16', 0),
(368, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:36:26pm', NULL, '2023-05-23 14:36:26', 0),
(369, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:40:08pm', NULL, '2023-05-23 14:40:08', 0),
(370, 1, 2, 1, 16, 'Updating Block only by Block Manager', '', '', NULL, NULL, '2023-05-23 14:42:41pm', NULL, '2023-05-23 14:42:41', 0),
(371, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-23 03:38:09pm', '2023-05-23 15:38:09', NULL, NULL),
(372, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-23 03:39:48pm', '2023-05-23 15:39:48', NULL, NULL),
(373, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-23 03:50:55pm', '2023-05-23 15:50:55', NULL, NULL),
(374, 3, 21, 1, 5, 'User Login', '3', 'Resident_User', '', '12312', '2023-05-23 03:54:23pm', '2023-05-23 15:54:23', NULL, NULL),
(375, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-24 05:01:55pm', '2023-05-24 17:01:55', NULL, NULL),
(376, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-24 20:05:45', NULL, '2023-05-24 20:05:45', 1),
(377, 1, 2, 1, 15, 'Updating User data', '1', 'Resident_User', '3637619', '8274101', '2023-05-24 20:06:21', NULL, '2023-05-24 20:06:21', 1),
(378, 1, 2, 1, 5, 'User Login', '1', 'Resident_User', '', '12312', '2023-05-26 05:09:12pm', '2023-05-26 17:09:12', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `LogType`
--

CREATE TABLE `LogType` (
  `ID` int(11) NOT NULL,
  `Name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explanation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `LogType`
--

INSERT INTO `LogType` (`ID`, `Name`, `Explanation`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'Registration', 'Registration of new user', '2023-02-09 03:46:38', NULL, NULL),
(2, 'Create New Block', 'Creating New Block', '2023-02-09 03:47:05', NULL, NULL),
(3, 'Insert data', 'Inserting Data to database', '2023-02-09 03:47:23', NULL, NULL),
(4, 'Preview data', 'Previewing data from data base', '2023-02-09 03:47:48', NULL, NULL),
(5, 'Login', 'User Login', '2023-02-09 05:48:26', NULL, NULL),
(6, 'Create New Apartment', 'Creating New Apartment', '2023-02-12 06:59:16', NULL, NULL),
(7, 'Request meeting', 'Request meeting from Block Manager', '2023-02-12 07:16:59', NULL, NULL),
(8, 'Create Event', 'Create new event to block residents', '2023-02-12 07:21:39', NULL, NULL),
(9, 'Create Decision', 'Block manager Create New Decision on block ', '2023-02-12 07:24:07', NULL, NULL),
(10, 'Add News', 'Publish News On the Block', '2023-02-12 07:26:58', NULL, NULL),
(11, 'Create Offer', 'Create New Offer to Publish in certain Area', '2023-02-12 07:29:22', NULL, NULL),
(12, 'Add Service', 'Add Nearby Service', '2023-02-12 07:32:27', NULL, NULL),
(13, 'Add Favourite', 'Add liked service or neighbour to favourite ', '2023-02-12 07:35:43', NULL, NULL),
(14, 'Ask to add apartment', 'Ask block manager to add apartment to block', '2023-02-12 07:44:40', NULL, NULL),
(15, 'Update', 'Updating current Data', '2023-02-12 10:35:50', NULL, NULL),
(16, 'Update Password', 'Updating user password', '2023-02-12 10:38:24', NULL, NULL),
(17, 'Add Comment', 'Add comment to a post that is specified in Comment table', '2023-02-17 14:05:31', NULL, NULL),
(18, 'Create Complaint', 'Add New complaint', '2023-02-17 17:30:31', NULL, NULL),
(19, 'Create Suggestion', 'Add New Suggestion', '2023-02-17 17:31:00', NULL, NULL),
(20, 'Payment', 'Pay Fee [Partial / Full]', '2023-02-19 13:22:01', NULL, NULL),
(21, 'Create Financial Account', 'Creating financial account with any creation of blocks or apartments', '2023-02-19 13:58:09', NULL, NULL),
(22, 'Delete Data', 'Delete any records or entities in records', '2023-03-07 07:02:33', NULL, NULL),
(23, 'Chat', 'Send Message to Chat Room', '2023-04-09 09:07:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Meeting`
--

CREATE TABLE `Meeting` (
  `ID` int(11) NOT NULL,
  `Tittle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Body` text COLLATE utf8_unicode_ci,
  `Attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `MeetingLocation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Approval` int(11) DEFAULT NULL,
  `NumOfAttendees` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `BlockManagerID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Meeting`
--

INSERT INTO `Meeting` (`ID`, `Tittle`, `Body`, `Attachment`, `Date`, `MeetingLocation`, `Approval`, `NumOfAttendees`, `UserID`, `BlockManagerID`, `BlockID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, '', '', '', '0000-00-00 00:00:00', 'شقة 4', 1, 2, 1, 1, 1, '2023-02-03 05:16:52', NULL, NULL),
(2, 'FirstMeeting', 'First Meeting', '', '0000-00-00 00:00:00', NULL, 1, 1, 1, 1, 1, '2023-02-03 05:18:51', NULL, NULL),
(3, 'meetingTest1', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-03 11:43:15', NULL, NULL),
(4, 'meetingTest2', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-03 11:45:04', NULL, NULL),
(5, 'meetingTest3', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNkZDgxYTQ5N2YxNzIuNDAwNTE5ODk=.png', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-03 11:50:28', NULL, NULL),
(6, 'meetingTest4', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNkZjkwZjBjMTg1NDcuNjY5MDExNTU=.png', '2023-02-15 13:39:03', NULL, 1, 0, 1, 1, 1, '2023-02-05 01:20:16', NULL, NULL),
(7, 'meetingTest5', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-05 01:20:54', NULL, NULL),
(8, 'meetingTest6', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'Array', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-05 02:38:41', NULL, NULL),
(9, 'meetingTest7', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-05 02:49:35', NULL, NULL),
(10, 'meetingTest8', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'Array', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-05 02:49:45', NULL, NULL),
(11, 'meetingTest9', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNkZmE2OGViNjQwMjcuOTkyNjcxNTg=.png', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-05 02:52:30', NULL, NULL),
(12, 'meetingTest10', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNkZmE2ZmI5YWUzYTUuMjI1OTc5NjI=.png', '2023-02-17 13:42:55', NULL, 1, 0, 1, 1, 1, '2023-02-05 02:54:19', NULL, NULL),
(13, 'meetingTest11', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNlYTJiNjA1YTI3YjMuNDYyNDU0ODA=.png', '0000-00-00 00:00:00', NULL, 1, 0, 1, 1, 1, '2023-02-13 02:21:52', NULL, NULL),
(14, 'meetingTest1', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZWUxZjQwZDA4OWYwLjQyNzA1NDE1.png', '0000-00-00 00:00:00', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-16 02:19:12', NULL, NULL),
(15, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZWUxZjgwNTljY2E3LjM2NDkwMTU3.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-16 02:20:16', NULL, NULL),
(16, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZWU1M2RjYmRjNTA3LjUzMDc4MzQy.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-16 06:03:40', NULL, NULL),
(17, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZWU1NDUyNTEwNTU3LjI2MTM3Njk4.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-16 06:05:38', NULL, NULL),
(18, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZWU1NGZkYWJmYWU5LjI0NzQzODM3.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-16 06:08:29', NULL, NULL),
(19, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmE5N2YyNDJmY2I3LjgzOTg1ODA0.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-26 01:21:22', NULL, NULL),
(20, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmE5OTljYTExOWE1LjMzMTg2MjY4.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-26 01:28:28', NULL, NULL),
(21, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 1, 26, 26, 73, '2023-02-26 15:26:46', NULL, NULL),
(22, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', '', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 26, 26, 73, '2023-02-26 18:48:36', NULL, NULL),
(24, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YTRlNjQyMTA4LjIyNjQ3NDY3.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 13:55:58', NULL, NULL),
(25, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YjE3OGZkNzk4LjI1Nzg0OTA0.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 13:59:19', NULL, NULL),
(26, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YjVkZjMxZmEwLjMwOTY2NjMx.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 14:00:29', NULL, NULL),
(27, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5Yjc2ZDljNDUzLjQ1MDI4MjM0.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 14:00:54', NULL, NULL),
(28, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YjhkNzg4Mzk1LjI5NDQ4NzYz.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 14:01:17', NULL, NULL),
(29, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YmQ2M2FlZTAxLjAwMDIzOTM1.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 14:02:30', NULL, NULL),
(30, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmM5YmY1MGMyYjc5LjAzNTc3OTUy.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 14:03:01', NULL, NULL),
(31, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmNhZjQ0NTI2MjYwLjczMzYzNDQ3.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 15:25:24', NULL, NULL),
(32, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmNhZjdjOGZkNmE3LjkzMDE3Mjcy.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 0, 0, 1, 1, 1, '2023-02-27 15:26:20', NULL, NULL),
(33, 'meetingTest13', 'meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1meetingTest1', 'MTYzZmNhZjk2NjI4NTQwLjExNTY2NTk0.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-02-27 15:26:46', NULL, NULL),
(34, 'meetingTest15', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTYzZmQxMDM0M2FiOGY3LjUyNjA4MzY4.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-02-27 22:19:00', NULL, NULL),
(35, 'meetingTest15', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTYzZmQxZTYwYzBjMDE0LjExNjk3MDM5.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-02-27 23:19:28', NULL, NULL),
(36, 'meetingTest15', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTYzZmUzNGVmYTVjMWYwLjYwMjY1MDQ1.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-02-28 19:07:59', NULL, NULL),
(37, 'meetingTest16', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0MDQ3YTU1MDZhOWU1Ljg3NDIzMjEw.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-03-05 13:17:41', NULL, NULL),
(38, 'meetingTest17', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0MDQ5MTY0ZDZhOGE1LjE0NjQxMDU0.png', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-03-05 14:56:04', NULL, NULL),
(39, 'Meeting title hossam', 'Hossam decription', 'MjY2NDA0OTJhZDU3MjNkOS43MzIyNTQ4NA==.jpg', '2023-03-31 12:53:48', 'Hossam location', 1, 0, 26, 26, 73, '2023-03-05 15:01:33', NULL, NULL),
(40, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', '', '2023-02-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-03-06 16:25:01', NULL, NULL),
(41, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', '', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-03-07 10:31:39', NULL, NULL),
(42, 'اجتماع جمعية عموميه', 'التل', 'Default.jpg', '2023-03-10 16:30:30', 'الحديقة', 1, 1, 34, 34, 78, '2023-03-09 21:59:13', NULL, NULL),
(43, 'اللاللاا', 'ةلات', 'Default.jpg', '2023-03-17 10:00:08', 'اللااا', 1, 0, 34, 34, 78, '2023-03-16 09:53:45', NULL, NULL),
(44, 'ضضضضضض', 'ضضضضضض', 'Default.jpg', '2023-03-17 11:05:08', 'ضضضضضض', 1, 0, 34, 34, 78, '2023-03-16 09:59:14', NULL, NULL),
(45, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-11 14:49:01', NULL, NULL),
(46, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 00:57:20', NULL, NULL),
(47, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:27:30', NULL, NULL),
(48, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0MzVlY2ZmNWQzZmMxLjc0MDY2MDYw.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:27:59', NULL, NULL),
(49, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:30:43', NULL, NULL),
(50, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:31:41', NULL, NULL),
(51, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:32:06', NULL, NULL),
(52, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0MzVmNDQ0ODU0Yzk2Ljc4OTM1MDI2.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 01:59:00', NULL, NULL),
(53, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:00:56', NULL, NULL),
(54, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:01:41', NULL, NULL),
(55, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:02:09', NULL, NULL),
(56, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:02:30', NULL, NULL),
(57, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:12:57', NULL, NULL),
(58, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:14:30', NULL, NULL),
(59, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:16:19', NULL, NULL),
(60, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 02:18:24', NULL, NULL),
(61, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0MzYwNGE1NDBmZjI1LjI1MjQzMzcz.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 03:08:53', NULL, NULL),
(62, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'Default.jpg', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-04-12 03:09:15', NULL, NULL),
(63, 'meetingTest18', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0NTY3YmYyNTRlNzM2LjAwMTU1MDUz.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-05-06 19:10:26', NULL, NULL),
(64, 'meetingTest121', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0NTY4MGMzYjBhMDUxLjQ4MzA5ODI0.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-05-06 19:30:59', NULL, NULL),
(65, 'meetingTest121', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0NTY4NTA5YTZkMDQ1LjI4ODI2MzI2.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-05-06 19:49:13', NULL, NULL),
(66, 'meetingTest121', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0NTY4NWViZTdmNTg3LjczMjYzMDI1.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 0, 1, 1, 1, '2023-05-06 19:52:59', NULL, NULL),
(67, 'meetingTest121', 'meetingTest15/meetingTest15/meetingTest15/meetingTest15', 'MTY0NWQzZGQzY2NkOTE5LjY4OTI0NTE4.png', '2023-03-18 13:39:03', 'شقة الاستاذ صابر', 1, 1, 1, 1, 1, '2023-05-11 22:11:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `MeetingAttach`
--

CREATE TABLE `MeetingAttach` (
  `ID` int(11) NOT NULL,
  `Attach` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MeetingID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `MemberOfTheBoard`
--

CREATE TABLE `MemberOfTheBoard` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Lname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Message`
--

CREATE TABLE `Message` (
  `ID` int(11) NOT NULL,
  `Message` text COLLATE utf8_unicode_ci,
  `Attach` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SenderID` int(11) DEFAULT NULL,
  `ReceiverID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ChatID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Message`
--

INSERT INTO `Message` (`ID`, `Message`, `Attach`, `SenderID`, `ReceiverID`, `ApartmentID`, `BlockID`, `ChatID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'first test Chat Waheed', '', 3, NULL, 21, 1, NULL, '2023-03-02 01:02:19', NULL, NULL),
(2, 'first test Chat Waheed', 'MzYzZmZkYWVkYzVjZGExLjAzNDMyMDk5.png', 3, NULL, 21, 1, NULL, '2023-03-02 01:08:29', NULL, NULL),
(3, 'first test Chat Waheed', 'MTY0MDQ3OGUxYzgxZTM0LjkyNDkzOTAz.png', 1, NULL, 2, 1, NULL, '2023-03-05 13:11:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `News`
--

CREATE TABLE `News` (
  `ID` int(11) NOT NULL,
  `Tittle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LetterOfNews` text COLLATE utf8_unicode_ci,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `News`
--

INSERT INTO `News` (`ID`, `Tittle`, `LetterOfNews`, `Image`, `ResidentID`, `ApartmentID`, `BlockID`, `Date`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(4, 'News1', 'News2createNewscreateNewscreateNews', '', 1, 2, 1, '2023-02-05', '2023-02-05 08:36:53', NULL, NULL),
(5, 'News2', 'News2createNewscreateNewscreateNews', '', 1, 2, 1, '2023-02-05', '2023-02-05 08:38:09', NULL, NULL),
(6, 'News2', 'News2createNewscreateNewscreateNews', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNkZmY3YzQ2ZDM0MDEuNDUwMjQxNTQ=.png', 1, 2, 1, '2023-02-05', '2023-02-05 08:39:00', NULL, NULL),
(7, 'News2', 'News2createNewscreateNewscreateNews', 'bW9keS5tYW41MzFAZ21haWwuY29tNjNlNGZlNTljNWRiMzguMTAzMTcxOTM=.png', 1, 2, 1, '2023-02-09', '2023-02-09 04:08:25', NULL, NULL),
(8, 'News2', 'News2createNewscreateNewscreateNews', 'MTYzZWU1OTQwMWUwOGQ0LjEwODY2OTIz.png', 1, 2, 1, '2023-02-16', '2023-02-16 06:26:40', NULL, NULL),
(9, 'News2', 'News2createNewscreateNewscreateNews', 'MTYzZWU1OTc0NmEyNGM3LjM5ODM2NjA0.png', 1, 2, 1, '2023-02-16', '2023-02-16 06:27:32', NULL, NULL),
(10, 'News2', 'News2createNewscreateNewscreateNews', 'MjY2M2Y3OTM2ZDI1ZmI1MS45MjMzODA0Mg==.jpg', 26, 77, 73, '2023-02-23', '2023-02-23 06:25:17', NULL, NULL),
(11, 'News title ', 'New description nws', 'MjY2M2Y3YTc1M2IzMDljNy4xMTAwMjg3OQ==.jpg', 26, 77, 73, '2023-02-23', '2023-02-23 07:50:11', NULL, NULL),
(12, 'New one', 'Y y h h h h t y y. Rvt y y j h t h yy ', 'MjY2M2Y3YWM0ZTFkNjRkMy4wMTk3NDAzMw==.jpg', 26, 77, 73, '2023-02-23', '2023-02-23 08:11:26', NULL, NULL),
(13, 'New in 2:03', 'G gbb', 'MjY2M2ZiNGJkMDYxY2IyNy4wNTQzODAyNw==.jpg', 26, 77, 73, '2023-02-26', '2023-02-26 02:08:48', NULL, NULL),
(14, 'News2', 'News2createNewscreateNewscreateNews', 'MTYzZmI0ZjI1ZTJlZGU5LjYwNzI3NTI3.png', 1, 2, 1, '2023-02-26 02:23:01pm', '2023-02-26 14:23:01', NULL, NULL),
(15, 'Meeting title', 'Meeting see something ', 'MjY2M2ZiYTMyNDE4ODYwMy4zMjI1NTg5NQ==.jpg', 26, 77, 73, '2023-02-26 08:21:24pm', '2023-02-26 20:21:24', NULL, NULL),
(16, 'احتماع عمارة ١٠٧ رقم١', 'اجتماع مناقشه تجديد المدخل', 'MzQ2M2ZjZjgyZjQ1Y2M3Ni41Njg4MDk0Nw==.jpg', 34, 82, 78, '2023-02-27 08:36:31pm', '2023-02-27 20:36:31', NULL, NULL),
(17, 'الماية هتقطع بكرة الساعه ٥ لحد ٩', 'انقطاع المياع عن الثروه حدايق الاهرام لمده ٤ ساعات', 'MzQ2M2ZjZmY1N2JmZjY4My4xOTQzMTM1Mg==.jpg', 34, 82, 78, '2023-02-27 09:07:03pm', '2023-02-27 21:07:03', NULL, NULL),
(18, 'Meeting 1', 'لاللب', 'MzQ2NDAxY2Y0MmMwYmVmNS45NDM1MDgyNA==.jpg', 34, 82, 78, '2023-03-03 12:43:14pm', '2023-03-03 12:43:14', NULL, NULL),
(19, 'Meeting title ', 'Meeting description ', 'MjY2NDA0OGZhNGIzNGYzNS4wNzE3NDA3Mw==.jpg', 26, 77, 73, '2023-03-05 02:48:36pm', '2023-03-05 14:48:36', NULL, NULL),
(20, 'Meeting title hossam', 'Hossam decription', 'MjY2NDA0OTFkMzIwNDNmNC4wMzA0ODA4Nw==.jpg', 26, 77, 73, '2023-03-05 02:57:55pm', '2023-03-05 14:57:55', NULL, NULL),
(21, 'جمعيه عمومي للعنار٧', 'اجتماع للمناقشه', 'MzQ2NDA1YWUwNzMwZTM2OC4zODMyNDA3Mg==.jpg', 34, 82, 78, '2023-03-06 11:10:31am', '2023-03-06 11:10:31', NULL, NULL),
(22, 'خبر جديد ٦-٣-٢٠٢٣ الساعه ١٢:٣٠ انقطاع الكهرباء', 'تفاصيل الخير انقطاع الكهرباء', 'MzQ2NDA1YzBjZTM1ZWE0NC4wNjA5Nzk2Ng==.jpg', 34, 82, 78, '2023-03-06 12:30:38pm', '2023-03-06 12:30:38', NULL, NULL),
(23, 'News2', 'News2createNewscreateNewscreateNews', 'Default.jpg', 1, 2, 1, '2023-04-10 02:53:54am', '2023-04-10 02:53:54', NULL, NULL),
(24, 'News2', 'News2createNewscreateNewscreateNews', 'Default.jpg', 1, 2, 1, '2023-04-10 02:54:35am', '2023-04-10 02:54:35', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Notification`
--

CREATE TABLE `Notification` (
  `ID` int(11) NOT NULL,
  `Type` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RecordID` int(11) DEFAULT NULL,
  `Sender` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `Receiver` int(11) DEFAULT NULL,
  `LoopAt` datetime DEFAULT NULL,
  `Repetition` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `NotifSettings`
--

CREATE TABLE `NotifSettings` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `HideMeeting` int(11) NOT NULL DEFAULT '0',
  `HideEvent` int(11) NOT NULL,
  `HideNews` int(11) NOT NULL,
  `HideOffers` int(11) NOT NULL,
  `HideChat` int(11) NOT NULL,
  `HideFinancial` int(11) NOT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `NotifSettings`
--

INSERT INTO `NotifSettings` (`ID`, `UserID`, `HideMeeting`, `HideEvent`, `HideNews`, `HideOffers`, `HideChat`, `HideFinancial`, `ApartmentID`, `BlockID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, 0, 1, 0, 0, 0, 0, 2, 1, '2023-04-05 23:40:27', NULL, NULL),
(2, 1, 0, 1, 0, 0, 0, 0, 78, 74, '2023-04-05 23:40:27', NULL, NULL),
(3, 1, 0, 0, 0, 0, 0, 0, 79, 75, '2023-04-05 23:40:27', NULL, NULL),
(4, 1, 0, 0, 0, 0, 0, 0, 80, 76, '2023-04-05 23:40:27', NULL, NULL),
(5, 1, 0, 0, 0, 0, 0, 0, 83, 84, '2023-04-05 23:40:27', NULL, NULL),
(6, 1, 0, 0, 0, 0, 0, 0, 86, 92, '2023-04-05 23:40:27', NULL, NULL),
(7, 1, 0, 0, 0, 0, 0, 0, 90, 96, '2023-04-05 23:40:27', NULL, NULL),
(8, 1, 0, 0, 0, 0, 0, 0, 21, 1, '2023-04-05 23:40:27', NULL, NULL),
(9, 1, 0, 0, 0, 0, 0, 0, 75, 1, '2023-04-05 23:40:27', NULL, NULL),
(10, 1, 0, 0, 0, 0, 0, 0, 91, 96, '2023-04-05 23:40:27', NULL, NULL),
(11, 1, 0, 0, 0, 0, 0, 0, 114, 1, '2023-04-05 23:40:27', NULL, NULL),
(12, 1, 0, 0, 0, 0, 0, 0, 115, 1, '2023-04-05 23:40:27', NULL, NULL),
(13, 1, 0, 0, 0, 0, 0, 0, 116, 1, '2023-04-05 23:40:27', NULL, NULL),
(14, 1, 0, 0, 0, 0, 0, 0, 117, 1, '2023-04-05 23:40:27', NULL, NULL),
(15, 1, 0, 0, 0, 0, 0, 0, 118, 1, '2023-04-05 23:40:27', NULL, NULL),
(16, 1, 0, 0, 0, 0, 0, 0, 119, 1, '2023-04-05 23:40:27', NULL, NULL),
(17, 1, 0, 0, 0, 0, 0, 0, 120, 1, '2023-04-05 23:40:27', NULL, NULL),
(18, 2, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(21, 5, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(22, 18, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(23, 19, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(24, 20, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(25, 21, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(26, 22, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(27, 23, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(28, 24, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(29, 25, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(30, 26, 0, 0, 0, 0, 0, 0, 77, 73, '2023-04-05 23:40:27', NULL, NULL),
(31, 26, 0, 0, 0, 0, 0, 0, 81, 77, '2023-04-05 23:40:27', NULL, NULL),
(32, 26, 0, 0, 0, 0, 0, 0, 75, 1, '2023-04-05 23:40:27', NULL, NULL),
(33, 27, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(34, 28, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(35, 29, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(36, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(37, 31, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(38, 32, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(39, 33, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(40, 34, 0, 0, 0, 0, 0, 0, 82, 78, '2023-04-05 23:40:27', NULL, NULL),
(41, 34, 0, 0, 0, 0, 0, 0, 87, 93, '2023-04-05 23:40:27', NULL, NULL),
(42, 34, 0, 0, 0, 0, 0, 0, 88, 94, '2023-04-05 23:40:27', NULL, NULL),
(43, 35, 0, 0, 0, 0, 0, 0, 0, 1, '2023-04-05 23:40:27', NULL, NULL),
(44, 36, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(45, 37, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(46, 38, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(47, 39, 0, 0, 0, 0, 0, 0, 84, 90, '2023-04-05 23:40:27', NULL, NULL),
(48, 39, 0, 0, 0, 0, 0, 0, 85, 91, '2023-04-05 23:40:27', NULL, NULL),
(49, 40, 0, 0, 0, 0, 0, 0, 89, 95, '2023-04-05 23:40:27', NULL, NULL),
(50, 41, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(51, 17, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-04-05 23:40:27', NULL, NULL),
(52, 1, 0, 1, 0, 0, 0, 0, 2, 1, '2023-05-22 16:58:45', NULL, NULL),
(53, 1, 0, 1, 0, 0, 0, 0, 78, 74, '2023-05-22 16:58:45', NULL, NULL),
(54, 1, 0, 0, 0, 0, 0, 0, 79, 75, '2023-05-22 16:58:45', NULL, NULL),
(55, 1, 0, 0, 0, 0, 0, 0, 80, 76, '2023-05-22 16:58:45', NULL, NULL),
(56, 1, 0, 0, 0, 0, 0, 0, 83, 84, '2023-05-22 16:58:45', NULL, NULL),
(57, 1, 0, 0, 0, 0, 0, 0, 86, 92, '2023-05-22 16:58:45', NULL, NULL),
(58, 1, 0, 0, 0, 0, 0, 0, 90, 96, '2023-05-22 16:58:45', NULL, NULL),
(59, 1, 0, 0, 0, 0, 0, 0, 21, 1, '2023-05-22 16:58:45', NULL, NULL),
(60, 1, 0, 0, 0, 0, 0, 0, 75, 1, '2023-05-22 16:58:45', NULL, NULL),
(61, 1, 0, 0, 0, 0, 0, 0, 91, 96, '2023-05-22 16:58:45', NULL, NULL),
(62, 1, 0, 0, 0, 0, 0, 0, 114, 1, '2023-05-22 16:58:45', NULL, NULL),
(63, 1, 0, 0, 0, 0, 0, 0, 115, 1, '2023-05-22 16:58:45', NULL, NULL),
(64, 1, 0, 0, 0, 0, 0, 0, 116, 1, '2023-05-22 16:58:45', NULL, NULL),
(65, 1, 0, 0, 0, 0, 0, 0, 117, 1, '2023-05-22 16:58:45', NULL, NULL),
(66, 1, 0, 0, 0, 0, 0, 0, 118, 1, '2023-05-22 16:58:45', NULL, NULL),
(67, 1, 0, 0, 0, 0, 0, 0, 119, 1, '2023-05-22 16:58:45', NULL, NULL),
(68, 1, 0, 0, 0, 0, 0, 0, 120, 1, '2023-05-22 16:58:45', NULL, NULL),
(69, 2, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(72, 5, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(73, 18, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(74, 19, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(75, 20, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(76, 21, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(77, 22, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(78, 23, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(79, 24, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(80, 25, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(81, 26, 0, 0, 0, 0, 0, 0, 77, 73, '2023-05-22 16:58:45', NULL, NULL),
(82, 26, 0, 0, 0, 0, 0, 0, 81, 77, '2023-05-22 16:58:45', NULL, NULL),
(83, 26, 0, 0, 0, 0, 0, 0, 75, 1, '2023-05-22 16:58:45', NULL, NULL),
(84, 27, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(85, 28, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(86, 29, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(87, 30, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(88, 31, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(89, 32, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(90, 33, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(91, 34, 0, 0, 0, 0, 0, 0, 82, 78, '2023-05-22 16:58:45', NULL, NULL),
(92, 34, 0, 0, 0, 0, 0, 0, 87, 93, '2023-05-22 16:58:45', NULL, NULL),
(93, 34, 0, 0, 0, 0, 0, 0, 88, 94, '2023-05-22 16:58:45', NULL, NULL),
(94, 35, 0, 0, 0, 0, 0, 0, 0, 1, '2023-05-22 16:58:45', NULL, NULL),
(95, 36, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(96, 37, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(97, 38, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(98, 39, 0, 0, 0, 0, 0, 0, 84, 90, '2023-05-22 16:58:45', NULL, NULL),
(99, 39, 0, 0, 0, 0, 0, 0, 85, 91, '2023-05-22 16:58:45', NULL, NULL),
(100, 40, 0, 0, 0, 0, 0, 0, 89, 95, '2023-05-22 16:58:45', NULL, NULL),
(101, 41, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(102, 17, 0, 0, 0, 0, 0, 0, NULL, NULL, '2023-05-22 16:58:45', NULL, NULL),
(104, 3, 1, 1, 1, 0, 1, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE `Payment` (
  `ID` int(11) NOT NULL,
  `MethodID` int(11) DEFAULT NULL,
  `OriginalFeeAmount` float NOT NULL,
  `Amount` float NOT NULL,
  `Remaining` float NOT NULL,
  `Partial` int(11) DEFAULT NULL,
  `FeeID` int(11) DEFAULT NULL,
  `BillID` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Attachment` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Confirm` int(11) NOT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ExpenseID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `CreatedBy` int(11) DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Payment`
--

INSERT INTO `Payment` (`ID`, `MethodID`, `OriginalFeeAmount`, `Amount`, `Remaining`, `Partial`, `FeeID`, `BillID`, `Attachment`, `Confirm`, `BlockID`, `ApartmentID`, `ResidentID`, `ExpenseID`, `CreatedAt`, `CreatedBy`, `UpdatedAt`, `UpdatedBy`) VALUES
(2, 1, 0, 150, -3084, 0, 1, NULL, '', 0, 1, 2, 1, 2, '2023-02-19 05:29:22', 1, NULL, NULL),
(3, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjE5ODhjMWIxOWQwLjg1OTM1ODY2.png', 0, 1, 2, 1, 2, '2023-02-19 05:33:32', 1, NULL, NULL),
(4, 1, 0, 150, -3084, 0, 1, 'B1A2I1', 'MTYzZjE5OTQ1OGUzZjU4LjQzNjkyOTE1.png', 0, 1, 2, 1, 2, '2023-02-19 05:36:37', 1, NULL, NULL),
(5, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjE5OTY1MThkODc3LjAzMTY5MTE2.png', 0, 1, 2, 1, 2, '2023-02-19 05:37:09', 1, NULL, NULL),
(6, 1, 0, 90, -3084, 1, 1, NULL, 'MTYzZjE5OWIzMTQzZDMyLjE3NTEzNzI2.png', 0, 1, 2, 1, 2, '2023-02-19 05:38:27', 1, NULL, NULL),
(9, 1, 0, 123, 0, 0, 2, NULL, 'MTYzZjE5YjJmOTk2NzQxLjcyMjMxMTg4.png', 0, 1, 2, 1, 1, '2023-02-19 05:44:47', 1, NULL, NULL),
(10, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhNWRmNWNiYzE0LjU5MjgyMzQ2.png', 0, 1, 2, 1, 2, '2023-02-20 00:42:39', 1, NULL, NULL),
(11, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhN2UyNjU3ZjI4Ljk4Nzk2NTAy.png', 0, 1, 2, 1, 2, '2023-02-20 00:51:14', 1, NULL, NULL),
(12, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhODQ2NjNhMTY2LjQ1NTMzNzE5.png', 0, 1, 2, 1, 2, '2023-02-20 00:52:54', 1, NULL, NULL),
(13, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhODdkMWIxMDQ0LjEyNzIzMjgw.png', 0, 1, 2, 1, 2, '2023-02-20 00:53:49', 1, NULL, NULL),
(14, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhYTg2MDUzMzQ5LjE2ODE4NjU4.png', 0, 1, 2, 1, 2, '2023-02-20 01:02:30', 1, NULL, NULL),
(15, 1, 0, 12, -3084, 1, 1, NULL, 'MTYzZjJhYWEwYmE1YWU3Ljg3MTE3NjI4.png', 0, 1, 2, 1, 2, '2023-02-20 01:02:56', 1, NULL, NULL),
(16, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjJhYjUxN2VmNGI1LjY5MTQwMzI5.png', 0, 1, 2, 1, 2, '2023-02-20 01:05:53', 1, NULL, NULL),
(17, 1, 0, 150, -3084, 0, 1, NULL, 'MTYzZjM2OWM4OWNkZTg0LjQwNTU0NTI0.png', 0, 1, 2, 1, 2, '2023-02-20 14:38:32', 1, NULL, NULL),
(18, 1, 0, 78, -3084, 1, 1, NULL, 'MTYzZjM2OWY0NDM5YjI2LjI1MzgyNTky.png', 0, 1, 2, 1, 2, '2023-02-20 14:39:16', 1, NULL, NULL),
(19, 1, 150, 78, -3084, 1, 1, NULL, '', 0, 1, 2, 1, 2, '2023-03-08 19:27:50', 1, NULL, NULL),
(20, 1, 150, 78, -3084, 1, 1, NULL, '', 0, 1, 2, 1, 2, '2023-03-08 21:03:02', 1, NULL, NULL),
(21, 1, 150, 78, -3084, 1, 1, NULL, '', 0, 1, 2, 1, 2, '2023-03-08 21:04:32', 1, NULL, NULL),
(22, 1, 150, 78, -3084, 1, 1, NULL, '', 0, 1, 2, 1, 2, '2023-03-08 21:06:47', 1, NULL, NULL),
(23, 1, 150, 78, -3084, 1, 1, NULL, '', 0, 1, 2, 1, 2, '2023-03-08 21:07:36', 1, NULL, NULL),
(24, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:13:12', 1, NULL, NULL),
(25, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:14:55', 1, NULL, NULL),
(26, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:16:34', 1, NULL, NULL),
(27, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:17:35', 1, NULL, NULL),
(28, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:19:26', 1, NULL, NULL),
(29, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:24:05', 1, NULL, NULL),
(30, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-08 21:25:02', 1, NULL, NULL),
(31, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-22 20:44:31', 1, NULL, NULL),
(32, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-22 20:46:47', 1, NULL, NULL),
(33, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-22 20:48:39', 1, NULL, NULL),
(34, 1, 150, 78, -3084, 1, 1, NULL, '', 1, 1, 2, 1, 2, '2023-03-22 20:50:10', 1, NULL, NULL),
(35, 1, 150, 78, -3084, 1, 1, 'B1A2I9', '', 1, 1, 2, 1, 2, '2023-03-22 20:51:05', 1, NULL, NULL),
(36, 1, 150, 78, -3084, 1, 1, 'B1A2I10', '', 1, 1, 2, 1, 2, '2023-03-25 17:05:36', 1, NULL, NULL),
(39, 1, 100, 78, 0, 1, 4, 'B1A2I12', '', 1, 1, 2, 1, 4, '2023-03-25 21:47:01', 1, NULL, NULL),
(40, 1, 100, 12, 0, 1, 4, 'B1A2I13', '', 1, 1, 2, 1, 4, '2023-03-25 21:47:24', 1, NULL, NULL),
(41, 1, 100, 5, 0, 1, 4, 'B1A2I14', '', 1, 1, 2, 1, 4, '2023-03-26 16:32:14', 1, NULL, NULL),
(42, 1, 100, 1, 0, 1, 4, 'B1A2I15', '', 1, 1, 2, 1, 4, '2023-03-26 16:36:26', 1, NULL, NULL),
(43, 1, 100, 1, 0, 1, 4, 'B1A2I16', '', 1, 1, 2, 1, 4, '2023-03-26 16:41:44', 1, NULL, NULL),
(44, 1, 100, 1, 0, 1, 4, 'B1A2I17', '', 1, 1, 2, 1, 4, '2023-03-26 16:44:10', 1, NULL, NULL),
(45, 1, 100, 1, 0, 1, 4, 'B1A2I18', '', 1, 1, 2, 1, 4, '2023-03-26 16:52:11', 1, NULL, NULL),
(46, 1, 100, 1, 0, 1, 4, 'B1A2I19', '', 1, 1, 2, 1, 4, '2023-03-26 17:02:05', 1, NULL, NULL),
(47, 1, 123, 3, 95, 1, 6, 'B1A2I20', '', 1, 1, 2, 1, 1, '2023-03-26 17:09:52', 1, NULL, NULL),
(48, 1, 123, 5, 95, 1, 6, 'B1A2I21', '', 1, 1, 2, 1, 1, '2023-03-26 17:12:38', 1, NULL, NULL),
(49, 1, 123, 5, 95, 1, 6, 'B1A2I22', '', 1, 1, 2, 1, 1, '2023-03-26 17:16:32', 1, NULL, NULL),
(50, 1, 123, 5, 95, 1, 6, 'B1A2I23', '', 1, 1, 2, 1, 1, '2023-03-26 17:29:42', 1, NULL, NULL),
(51, 1, 123, 5, 95, 1, 6, 'B1A2I24', '', 1, 1, 2, 1, 1, '2023-03-26 17:33:29', 1, NULL, NULL),
(52, 1, 123, 5, 95, 1, 6, 'B1A2I25', '', 1, 1, 2, 1, 1, '2023-03-26 17:37:00', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PaymentMethods`
--

CREATE TABLE `PaymentMethods` (
  `ID` int(11) NOT NULL,
  `Name` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explanation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PaymentMethods`
--

INSERT INTO `PaymentMethods` (`ID`, `Name`, `Explanation`, `BlockID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'Cash', 'Payment By Hand To Hand Method', 1, '2023-02-18 17:23:57', NULL, NULL),
(2, 'Vodafone Cash', 'Payment By Vodafone Cash', 1, '2023-02-18 17:24:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Permission`
--

CREATE TABLE `Permission` (
  `ID` int(11) NOT NULL,
  `PermissionType` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PermissionName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `PhoneNums`
--

CREATE TABLE `PhoneNums` (
  `ID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `PhoneNum` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Hide` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `PhoneNums`
--

INSERT INTO `PhoneNums` (`ID`, `UserID`, `ServiceID`, `PhoneNum`, `Hide`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 1, NULL, '01144338618', 0, '2023-04-02 14:16:10', NULL, NULL),
(2, 1, NULL, '01144338618', 0, '2023-05-23 12:54:42', NULL, NULL),
(3, 1, NULL, '0114433868', 0, '2023-05-23 13:03:57', NULL, NULL),
(4, 1, NULL, '0114433868', 0, '2023-05-23 13:37:16', NULL, NULL),
(5, 1, NULL, '0114433868', 0, '2023-05-23 13:39:27', NULL, NULL),
(6, 1, NULL, '0114433868', 0, '2023-05-23 13:41:50', NULL, NULL),
(7, 1, NULL, '0114433868', 0, '2023-05-23 13:43:26', NULL, NULL),
(8, 1, NULL, '0114433868', 0, '2023-05-23 13:44:06', NULL, NULL),
(9, 1, NULL, '0114433868', 0, '2023-05-23 13:44:39', NULL, NULL),
(10, 1, NULL, '0114433868', 0, '2023-05-23 13:45:30', NULL, NULL),
(11, 1, NULL, '0114433868', 0, '2023-05-23 13:47:35', NULL, NULL),
(12, 1, NULL, '0114433868', 0, '2023-05-23 13:48:54', NULL, NULL),
(13, 1, NULL, '0114433868', 0, '2023-05-23 13:49:25', NULL, NULL),
(14, 1, NULL, '0114433868', 0, '2023-05-23 13:50:18', NULL, NULL),
(15, 1, NULL, '0114433868', 0, '2023-05-23 13:50:49', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Rates`
--

CREATE TABLE `Rates` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `OverAllRate` float NOT NULL,
  `ResidentRate` float NOT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Rates`
--

INSERT INTO `Rates` (`ID`, `ResidentID`, `ApartmentID`, `BlockID`, `ServiceID`, `OverAllRate`, `ResidentRate`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(4, 1, 2, 1, 1, 3, 3, '2023-03-01 15:38:56', NULL, NULL),
(9, 3, 21, 1, 1, 3, 3, NULL, NULL, NULL),
(10, 3, 21, 1, 2, 2.25, 3, NULL, NULL, NULL),
(11, 1, 2, 1, 2, 2.25, 1.5, NULL, NULL, NULL),
(12, 1, 2, 1, 7, 2, 1.5, NULL, '2023-03-01 19:17:41', NULL),
(13, 3, 21, 1, 7, 2, 2.5, NULL, '2023-03-01 19:17:41', 3),
(14, 3, 21, 1, 6, 2.5, 2.5, '2023-03-01 19:21:05', NULL, NULL),
(15, 3, 21, 1, 22, 2.5, 2.5, '2023-03-01 19:22:37', NULL, NULL),
(16, 3, 21, 1, 23, 2.5, 2.5, '2023-03-01 19:23:56', NULL, NULL),
(17, 1, 2, 1, 34, 0.5, 0.5, '2023-03-06 21:13:54', '2023-03-06 21:17:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Region`
--

CREATE TABLE `Region` (
  `ID` int(11) NOT NULL,
  `RegionName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovID` int(11) DEFAULT NULL,
  `CityID` int(11) DEFAULT NULL,
  `RegionNameEN` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Region`
--

INSERT INTO `Region` (`ID`, `RegionName`, `CountryID`, `GovID`, `CityID`, `RegionNameEN`) VALUES
(1, 'ابو النمرس', NULL, 1, NULL, NULL),
(2, 'ابو النمرس', 2, 1, 4, NULL),
(3, 'ابو النمرس', 2, 1, 5, NULL),
(4, 'ابو النمرس', 2, 1, 2, NULL),
(5, 'ابو النمرس', 67, 1, 6, NULL),
(6, 'ابو النمرس', 67, 1, 6, NULL),
(7, 'ابو النمرس', 67, 1, 9, NULL),
(8, 'ابو النمرس', 67, 1, 10, NULL),
(9, 'ابو النمرس', 67, 1, 11, NULL),
(10, 'ابو النمرس', 67, 1, 12, NULL),
(29, 'ابو النمرس', 67, 1, 31, NULL),
(30, 'ابو النمرس', 67, 1, 32, NULL),
(31, 'ابو النمرس', 67, 1, 33, NULL),
(32, 'ابو النمرس', 67, 1, 34, NULL),
(33, 'ابو النمرس', 67, 1, 35, NULL),
(34, 'ابو النمرس', 67, 1, 36, NULL),
(35, 'ابو النمرس', 67, 1, 37, NULL),
(36, 'ابو النمرس', 240, 1, 38, NULL),
(43, 'ابو النمرس', 67, 2, 8, NULL),
(44, 'ابو النمرس', 67, 2, 46, NULL),
(45, 'ابو النمرس', 67, 2, 47, NULL),
(46, 'المهندسين', 67, 1, NULL, 'Mohandeseen'),
(47, 'الزمالك', 67, 1, NULL, 'Zamalek'),
(48, 'الهرم', 67, 1, NULL, 'Haram'),
(49, 'حدائق الأهرام', 67, 1, NULL, 'Hadayek Al Ahram'),
(50, 'فيصل', 67, 1, NULL, 'Faisal'),
(51, 'الشيخ زايد', 67, 1, NULL, 'Sheikh Zayed'),
(52, '6 أكتوبر - الحي 1', 67, 1, NULL, '6 October - Dist1'),
(53, '6 أكتوبر - الحي 2', 67, 1, NULL, '6 October - Dist 2'),
(54, '6 أكتوبر - الحي 3', 67, 1, NULL, '6 October - Dist 3'),
(55, '6 أكتوبر - الحي 4', 67, 1, NULL, '6 October - Dist 4'),
(56, '6 أكتوبر - الحي 5', 67, 1, NULL, '6 October - Dist 5'),
(57, '6 أكتوبر - الحي 6', 67, 1, NULL, '6 October - Dist 6'),
(58, '6 أكتوبر - الحي 7', 67, 1, NULL, '6 October - Dist 7'),
(59, '6 أكتوبر - الحي 9', 67, 1, NULL, '6 October - Dist 9'),
(60, '6 أكتوبر - الحي 10', 67, 1, NULL, '6 October - Dist10'),
(61, '6 أكتوبر - الحي 11', 67, 1, NULL, '6 October - Dist 11'),
(62, '6 أكتوبر - الحي 12', 67, 1, NULL, '6 October - Dist 12'),
(63, 'حدائق أكتوبر', 67, 1, NULL, 'Hadayek October'),
(64, 'الرماية', 67, 1, NULL, 'Al-Remaya'),
(65, 'الدقي', 67, 1, NULL, 'Dokki'),
(66, 'العجوزة', 67, 1, NULL, 'Agouza'),
(67, 'بولاق الدكرور', 67, 1, NULL, 'Bulaq Dakror'),
(68, 'العمرانية', 67, 1, NULL, 'Urbanism'),
(69, 'امبابة', 67, 1, NULL, 'Imbaba'),
(70, 'المنيب', 67, 1, NULL, 'Al-Munib'),
(71, 'منشية القناطر', 67, 1, NULL, 'Mansheyat Al-Qanater'),
(72, 'كرداسة', 67, 1, NULL, 'Kerdasa'),
(73, 'طموه', 67, 1, NULL, 'Tamwah'),
(74, 'بين السرايات', 67, 1, NULL, 'Ben El-Sarayat'),
(75, 'اوسيم', 67, 1, NULL, 'Owsem'),
(76, 'الوراق', 67, 1, NULL, 'El-Waraq'),
(77, 'الواحات البحرية', 67, 1, NULL, 'Bahariya Oasis'),
(78, 'العياط', 67, 1, NULL, 'Al-Ayat'),
(79, 'العجوزة', 67, 1, NULL, 'Agouza'),
(80, 'الصف', 67, 1, NULL, 'Al-Saf'),
(81, 'الصحفيين', 67, 1, NULL, 'El-Sahafeyen'),
(82, 'الحوامدية', 67, 1, NULL, 'Hawamdia'),
(83, 'البدرشين', 67, 1, NULL, 'Badrashin'),
(84, 'ابو رواش', 67, 1, NULL, 'Abu Rawash'),
(85, 'ابو النمرس', 67, 1, NULL, 'Abu Nomros'),
(86, 'مدينة 6 اكتوبر', 67, 2, NULL, 'October 6 City'),
(87, 'وسط البلد', 67, 2, NULL, 'downtown'),
(88, 'مصر القديمة', 67, 2, NULL, 'Ancient Egypt'),
(89, 'مصر الجديدة', 67, 2, NULL, 'Heliopolis'),
(90, 'مدينة نصر', 67, 2, NULL, 'Nasr City'),
(91, 'مدينة السلام', 67, 2, NULL, 'El-Salam'),
(92, 'مدينة 15 مايو', 67, 2, NULL, 'May 15th City'),
(93, 'كوبري القبة', 67, 2, NULL, 'Dome bridge'),
(94, 'غمرة', 67, 2, NULL, 'Ghamra'),
(95, 'عين شمس', 67, 2, NULL, 'Ain Shams'),
(96, 'عين الصيرة', 67, 2, NULL, 'Ain El-Sera'),
(97, 'عزبة النخل', 67, 2, NULL, 'Ezbet al-Nakhl'),
(98, 'عابدين', 67, 2, NULL, 'Abdeen'),
(99, 'طرة', 67, 2, NULL, 'Tora'),
(100, 'شبرا', 67, 2, NULL, 'Shubra'),
(101, 'روض الفرج', 67, 2, NULL, 'Rod El-Farag'),
(102, 'دار السلام', 67, 2, NULL, 'Dar AISalaam'),
(103, 'حلوان', 67, 2, NULL, 'Helwan'),
(104, 'حلمية الزيتون', 67, 2, NULL, 'Helmyat El-Zaytoon'),
(105, 'حدائق القبة', 67, 2, NULL, 'Dome Gardens'),
(106, 'جسر السويس', 67, 2, NULL, 'Suez Bridge'),
(107, 'جاردن سيتي', 67, 2, NULL, 'garden City'),
(108, 'بولاق', 67, 2, NULL, 'Bulaq'),
(109, 'باب اللوق', 67, 2, NULL, 'Bab Al-Luq'),
(110, 'الهايكستب', 67, 2, NULL, 'hikstep'),
(111, 'النزهة الجديدة', 67, 2, NULL, 'New Nozha'),
(112, 'الموسكي', 67, 2, NULL, 'musky'),
(113, 'المنيل', 67, 2, NULL, 'Manial'),
(114, 'المقطم', 67, 2, NULL, 'Mokattam'),
(115, 'المعصرة', 67, 2, NULL, 'Maasara'),
(116, 'المعادي', 67, 2, NULL, 'Maadi'),
(117, 'المطرية', 67, 2, NULL, 'Matarya'),
(118, 'المرج', 67, 2, NULL, 'Marg'),
(119, 'القاهرة الجديدة', 67, 2, NULL, 'New Cairo'),
(120, 'الفجالة', 67, 2, NULL, 'Faggala'),
(121, 'العتبة', 67, 2, NULL, 'Attaba'),
(122, 'العباسية', 67, 2, NULL, 'Abbasia'),
(123, 'الظاهر', 67, 2, NULL, 'Al-Dhaher'),
(124, 'الشروق', 67, 2, NULL, 'Al-Shorouq'),
(125, 'الشرابية', 67, 2, NULL, 'El-Sharabyea'),
(126, 'السيدة زينب', 67, 2, NULL, 'El-Sayeda Zainab');

-- --------------------------------------------------------

--
-- Table structure for table `Resident_Devices_Tokens`
--

CREATE TABLE `Resident_Devices_Tokens` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `GoogleToken` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MobileOS` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DeviceID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfDevices` int(11) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UpdatedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Resident_Devices_Tokens`
--

INSERT INTO `Resident_Devices_Tokens` (`ID`, `ResidentID`, `BlockID`, `GoogleToken`, `MobileOS`, `DeviceID`, `NumOfDevices`, `CreatedAt`, `UpdatedAt`) VALUES
(82, 1, 1, '1', 'android', '1', 3, '2023-05-22 02:26:17', NULL),
(83, 1, 1, '3', 'android', '2', 3, '2023-05-22 02:26:30', '2023-05-21 20:26:41'),
(84, 1, 1, '2', 'android', '3', 3, '2023-05-22 02:26:59', NULL),
(85, 3, 1, '2', 'android', '3', 1, '2023-05-23 21:38:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Resident_Subscription`
--

CREATE TABLE `Resident_Subscription` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `SubscriptionID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Resident_User`
--

CREATE TABLE `Resident_User` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UserName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNum` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MartialStatus` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `StatusID` int(11) DEFAULT NULL,
  `OTP` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Hide` int(11) NOT NULL,
  `FcmRegistrationID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Resident_User`
--

INSERT INTO `Resident_User` (`ID`, `Name`, `UserName`, `Email`, `Password`, `PhoneNum`, `Image`, `MartialStatus`, `StatusID`, `OTP`, `Hide`, `FcmRegistrationID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'Muhammad Waheed', 'MuhammadWaheed531', 'mody.man531@gmail.com', '$2y$10$zuRM4N0pebx5RC9fVyX4LednIH6d5PxdgUv2xlAvJPQQoEV3zhgbi', '+201144338618', 'MTY0NmU0NDBkOGNlMzUzLjYxMDE3NjI2.png', 'Single', 2, NULL, 0, NULL, '0000-00-00 00:00:00', '2023-05-24 20:06:21', 1),
(2, 'Hossam Bhi', 'HossamBasha', 'hossambhi@gmail.com', '$2y$10$GUsmOaD88Xjlpzk1PwK2Z.RxoNGBkNbUgTyy3UD3SUVbyTRlW55De', '1099086281', NULL, 'Single', 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(3, 'Muhammad Waheed531', NULL, 'mohamedwaheed73780@gmail.com', '$2y$10$mypUOqjmvmtBsA432JuiTOUhYCXlplXPWLYAGWNYCDSBx73eQOu2q', '1014584099', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(5, NULL, NULL, 'omarezzat@gmail.com', '$2y$10$XRdUhgoIaX2fTULpLJw2XegZ2ghGWbJZcHxfQkYpc6UQLs51OVbK2', '1001807845', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(17, NULL, NULL, 'test@test.com', '$2y$10$wPnvvXSvIb.b4ixfRZzL6OKp056rZRdn5l4nT67fTIU3CqjemVW3i', '1037027050', NULL, NULL, 3, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(18, NULL, NULL, 'test1@test.com', '$2y$10$AlviEhlb0BHRdAkaDxpRHeMf5AnDTdotDOX4KCUICD7FWyGbnzGUm', '1037027055', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(19, NULL, NULL, 'test2@test.com', '$2y$10$0ncMZx3cBkWNa3plCPetD.UKEsJQowwkNDd8evrubXtlrcANBJi/.', '1037027005', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(20, NULL, NULL, 'test3@test.com', '$2y$10$Ao7HEu1RgWTAR1FGBJG/uegBic81L2kZ3aRxaXppl3h.byqVxdTR.', '1037027000', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(21, NULL, NULL, 'test4@test.com', '$2y$10$pLep0nUZc7kas.qD8X1qeOlUacyPa54pQMbg/tuOmS0I1EHpnyCEm', '1037027001', NULL, NULL, 2, NULL, 0, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL),
(22, NULL, NULL, 'test5@test.com', '$2y$10$6U2kbrmbyVvTce/0RiUh7.JwszafZRuVHXH/GfsIps5yBe.mcoi5C', '1037027002', NULL, NULL, 2, NULL, 0, NULL, NULL, '0000-00-00 00:00:00', NULL),
(23, NULL, NULL, 'test6@test.com', '$2y$10$7psfr.CanOZe8DlHAVEwSe6SRybv2nZonsEOb0BvROx6I87sPGAru', '1003702701', NULL, NULL, 2, NULL, 0, NULL, '2023-02-12 07:14:53', '0000-00-00 00:00:00', NULL),
(24, 'OmarEzzat', NULL, 'omarEzzat2@gmail.com', '$2y$10$Z9Oc3DS/klCPV/8KTCl0HOzUHoVeLi0KlulKCsCPpMgrIYwo76R.6', '1119310400', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 01:50:24', NULL, NULL),
(25, 'Hossam Pasha', NULL, 'hossambasha9900@gmail.com', '$2y$10$NVf9mZ3LNRXuQirRfinyjecSsbQ1Gcb142iFUEh3VBmjdmWaw2CTq', '1099086282', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 01:56:45', NULL, NULL),
(26, 'Hossam', NULL, 'hossambhi990@gmail.com', '$2y$10$zMQDwMAj4AaUqlNmwUa96eSkG6QHkHMph6F63n1ejYhUqzQsORtnK', '01099086283', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 02:18:13', NULL, NULL),
(27, 'OmarEzzat', NULL, 'omarEzzat3@gmail.com', '$2y$10$M7oqOOzQEMtoBq58RGz..uilZKxd9LPuA8UudQ1C9yA1MVmit9NSi', '01119310401', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 10:50:35', NULL, NULL),
(28, 'OmarEzzat', NULL, 'omarEzzat4@gmail.com', '$2y$10$dTKt6njKoMPgDYUSGtpoJ.UgWhDezgfbBFTYKDdITTq7r8MvU84YS', '01119310402', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 10:53:35', NULL, NULL),
(29, 'OmarEzzat', NULL, 'omarEzzat5@gmail.com', '$2y$10$YhGOfbFALp86djmoof.2a.IJRmTv2hMwQRZbYGJIuHoEfm/fwaFhK', '01119310403', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 10:54:03', NULL, NULL),
(30, 'OmarEzzat', NULL, 'omarEzzat6@gmail.com', '$2y$10$LTvNWuQsSJT5Ckd1jOo1YeS6D16L9gzhNMAyaLIC4KKbymgqDkSuS', '01119310404', NULL, NULL, 2, NULL, 0, NULL, '2023-02-20 10:55:33', NULL, NULL),
(31, 'OmarEzzat', NULL, 'OmarEzzat7@gmail.com', '$2y$10$FXmqRoISSHa0ZGwjJXFjQuRZQG/lgOX5e0Zzwvizm.7uuTJWf9IXm', '01119310405', NULL, NULL, 2, NULL, 0, NULL, '2023-02-23 03:29:04', NULL, NULL),
(32, 'OmarEzzat', NULL, 'omarezzat8@gmail.com', '$2y$10$GQCgsHoTHldWXteAJ2Ad0OxaobgQlFOrK.gi1qybL68ww0g2sB68e', '01119310406', NULL, NULL, 2, NULL, 0, NULL, '2023-02-23 03:31:17', NULL, NULL),
(33, 'Mak', NULL, 'mk@khalifaonline.com', '$2y$10$hsu9f5rK0UO3hJ3vS6XFUO5eIg6K/JFDi2Lq7OQ92o8Zc1G/8bGX2', '+021114442161', NULL, NULL, 2, NULL, 0, NULL, '2023-02-27 11:42:03', NULL, NULL),
(34, 'محمد خليفة', NULL, 'mk@diginovia.com', '$2y$10$U/P1HBdyDcGT1204zRJq5Oc0.jvselPafQmC/DvHS8A9ewOb9rIlK', '+0201114442161', NULL, NULL, 2, NULL, 0, NULL, '2023-02-27 02:39:10', NULL, NULL),
(35, 'WatchMan', NULL, 'watchmantest@gmail.com', '$2y$10$io7NOW7mlJm3O.hP3q0EcehCAcR5ZZ5i5CWpYJatN2W.5WVIq64Li', '01119310407', NULL, NULL, 2, NULL, 0, NULL, '2023-03-05 12:36:54', NULL, NULL),
(36, 'Omar ezzat', NULL, 'oezzat272@gmail.com', '$2y$10$FEa0CGFhqcAVG9DqU764Bes4gykGTydRrE8aTgBmVNnwJV6iyiXrO', '+0201001807845', NULL, NULL, 2, NULL, 0, NULL, '2023-03-05 01:37:24', NULL, NULL),
(37, 'KhalifaCompouterGroup', NULL, 'khalifacompoutergroup234@gmail.com', '$2y$10$YbVbVFflakzwRKxm39KC0uoP6.pxiVS11upEkYb1OMlxGXEpskWP6', '01119310408', NULL, NULL, 2, NULL, 0, NULL, '2023-03-06 04:16:08', NULL, NULL),
(38, 'KhalifaCompouterGroup', NULL, 'khalifacompoutergroup_khalifacompoutergroup234@gmail.com', '$2y$10$AGcINz4zAGwvWZEGf17NOO.KDD91Ab7dHdOx7ONWGs.pa2mvkYhEa', '01119310409', NULL, NULL, 2, NULL, 0, NULL, '2023-03-06 04:18:22', NULL, NULL),
(39, 'Mostafa ', NULL, 'alexexpo2011@gmail.com', '$2y$10$vnmBN3wRUedXK4g15BAAd.WQY70Y2wdmUoNnraxOlZwx46cjz25pS', '+021001809624', NULL, NULL, 2, NULL, 0, NULL, '2023-03-06 04:51:08', NULL, NULL),
(40, 'Hassan', NULL, 'o@o.com', '$2y$10$SdiPa4NSc4Z8ALujYEKKHuN5v1DeN7ncYkOvPVpCBN5a0E7q2AzIu', '+021119310400', NULL, NULL, 2, NULL, 0, NULL, '2023-03-15 05:10:16', NULL, NULL),
(41, 'KhalifaCompouterGroup', 'KhalifaCompouterGroup', 'khalifacompoutergroup.khalifacompoutergroup234@gmail.com', '$2y$10$VBLIrvxRcnN5iK2kCHEvSeP6LtYEmlMbDpqG0qTWTTP3wz5ZkfKp.', '01110310407', NULL, NULL, 2, NULL, 0, NULL, '2023-04-05 08:34:08', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Restrection`
--

CREATE TABLE `Restrection` (
  `ID` int(11) NOT NULL,
  `Restrict_Name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explanation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SubscriptionID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `RES_APART_BLOCK_ROLE`
--

CREATE TABLE `RES_APART_BLOCK_ROLE` (
  `ID` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `RoleID` int(11) DEFAULT NULL,
  `StatusID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `RES_APART_BLOCK_ROLE`
--

INSERT INTO `RES_APART_BLOCK_ROLE` (`ID`, `ResidentID`, `ApartmentID`, `BlockID`, `RoleID`, `StatusID`) VALUES
(2, 1, 2, 1, 1, 2),
(115, 3, 21, 1, 6, 2),
(118, 26, 77, 73, 1, 2),
(119, 1, 78, 74, 1, 2),
(120, 1, 79, 75, 1, 2),
(121, 1, 80, 76, 1, 2),
(122, 26, 81, 77, 1, 2),
(123, 34, 82, 78, 1, 2),
(124, 35, NULL, 1, 7, 2),
(125, 1, 83, 84, 1, 2),
(126, 26, 75, 1, 6, 2),
(127, 39, 84, 90, 1, 2),
(128, 39, 85, 91, 1, 2),
(129, 1, 86, 92, 1, 2),
(130, 34, 87, 93, 1, 2),
(131, 34, 88, 94, 1, 2),
(132, 40, 89, 95, 1, 2),
(133, 1, 90, 96, 1, 2),
(134, 1, 21, 1, 6, 2),
(135, 1, 75, 1, 6, 2),
(137, 1, 91, 96, 6, 2),
(138, 3, 92, 96, 6, 1),
(139, 1, 114, 1, 6, 2),
(140, 1, 115, 1, 6, 2),
(141, 1, 116, 1, 6, 2),
(142, 1, 117, 1, 6, 2),
(143, 1, 118, 1, 6, 2),
(144, 1, 119, 1, 6, 2),
(145, 1, 120, 1, 6, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Role`
--

CREATE TABLE `Role` (
  `ID` int(11) NOT NULL,
  `RoleName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Role`
--

INSERT INTO `Role` (`ID`, `RoleName`) VALUES
(1, 'Block Manager'),
(2, 'Cashier'),
(3, 'Member Of The Board'),
(4, 'Vendor'),
(5, 'Client'),
(6, 'Resident'),
(7, 'Watchman / الحارس');

-- --------------------------------------------------------

--
-- Table structure for table `Role_Permissions`
--

CREATE TABLE `Role_Permissions` (
  `ID` int(11) NOT NULL,
  `RoleID` int(11) DEFAULT NULL,
  `PermissionID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Service`
--

CREATE TABLE `Service` (
  `ID` int(11) NOT NULL,
  `Name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNumI` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNumII` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNumIII` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNumIV` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Rate` float NOT NULL,
  `Favorite` int(11) DEFAULT NULL,
  `CategoryID` int(11) DEFAULT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `Latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovernateID` int(11) DEFAULT NULL,
  `CityID` int(11) DEFAULT NULL,
  `RegionID` int(11) DEFAULT NULL,
  `CompoundID` int(11) DEFAULT NULL,
  `StreetID` int(11) DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Service`
--

INSERT INTO `Service` (`ID`, `Name`, `Description`, `PhoneNumI`, `PhoneNumII`, `PhoneNumIII`, `PhoneNumIV`, `Image`, `Rate`, `Favorite`, `CategoryID`, `ResidentID`, `ApartmentID`, `BlockID`, `Latitude`, `Longitude`, `CountryID`, `GovernateID`, `CityID`, `RegionID`, `CompoundID`, `StreetID`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(42, 'مصرف ابو ظبي الاسلامي', 'بنك معاملات الاسلامية', '19951', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(43, 'البنك التجاري الدولي CIB', NULL, '33878767', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(44, 'بنك الاسكندرية', NULL, '19033', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(45, 'بنك القاهرة', NULL, '37796492', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(46, 'بنك التعمير و الاسكان', NULL, '33899813', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(47, 'مركز ابن سينا', NULL, '37762433', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(48, 'مركز الاهرام الطبى', NULL, '1159171988', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(49, 'اى ام سى المركز الطبى المصرى', NULL, '37802499', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(50, 'المركز الاسلامى الطبى', NULL, '33829115', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(51, 'مركز الامل لامراض الكلى', NULL, '35873974', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(52, 'صيدلية الهرم', NULL, '33881105', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(53, 'العزبي', NULL, '19600', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(54, 'صيدلية الشروق', NULL, '35825236', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(55, 'صيدلية احمد ماهرة', NULL, '19461', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(56, 'صيدلية مينا هاوس', NULL, '233851847', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(57, 'بيتزا كينج', 'بيتزا', '19519', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(58, 'قصر الاهرام للمشويات - ابو شقرة', 'مشويات', '235844257', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(59, 'لاسيرا', 'معجنات', '35841150', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(60, 'الصياد للمأكولات البحرية', 'أسماك', '233888006', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(61, 'دجاج تكا', 'دجاج', '19099', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(62, 'العمدة', NULL, '235873394', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(63, 'اسواق الصحابة', NULL, '1152493359', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(64, 'اسواق الحرمين', NULL, '233827970', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(65, 'السويس', NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(66, 'اسواق العزيزية', NULL, '235686995', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 48, NULL, NULL, NULL, NULL, NULL),
(67, 'بنك اتش اس بى سى - HSBC', NULL, '19007', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(68, 'كيو ان بى الاهلى - QNB', NULL, '19700', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(69, 'بنك ايه بى سى - ABC', NULL, '19123', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(70, 'البنك التجارى الدولى - CIB', NULL, '19666', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(71, 'البنك الاهلى اليونانى', NULL, '16272', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(72, 'صيدليات سيف', NULL, '19199', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(73, 'صيدليات العزبى', NULL, '19600', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(74, 'صيدلية د شريف الجنيدى', NULL, '233442290', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(75, 'فارماسى وان', NULL, '19771', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(76, 'صيدلية د صفاء', NULL, '233453336', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(77, 'المركز الدولى للعلاج الطبيعى وعلاج الالام', NULL, '237611124', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(78, 'مركز القلب والاوعية الدموية', NULL, '233386916', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(79, 'مركز العاصمة الطبى', NULL, '237617322', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(80, 'مركز الشفاء الطبى', NULL, '237600837', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(81, 'المركز الطبى الدولى', NULL, '233059011', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(82, 'مطعم ابو غالى للمأكولات البحرية', NULL, '233354885', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(83, 'مطعم اللؤلؤة', NULL, '233358448', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(84, 'مطعم شيراز', NULL, '233356908', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(85, 'مطعم وكافيه كلاود ناين', NULL, '233468439', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(86, 'مطعم وكافيه باك يارد', NULL, '233035676', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(87, 'سوبر ماركت شيخون', NULL, '233036640', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(88, 'سعودى ماركت', NULL, '16176', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(89, 'سوبر ماركت صن شاين', NULL, '233383317', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(90, 'سوبر ماركت جوهرة المدينة', NULL, '237613564', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(91, 'اسواق لبنان', NULL, '233047154', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 46, NULL, NULL, NULL, NULL, NULL),
(92, 'صيدليات كايرو ', NULL, '233905112', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(93, 'صيدليات 24', NULL, '19421', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(94, 'صيدليات حلمى', NULL, '16442', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(95, 'صيدلية رعاية', NULL, '233908694', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(96, 'صيدليات ابو على', NULL, '19141', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(97, 'اكسبشن ماركت', NULL, '1063771888', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(98, 'بيم ستورز', NULL, '1113800062', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(99, 'سوبر ماركت اولاد البلد', NULL, '1111075781', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(100, 'الحذيفى ماركت', NULL, '1001280557', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(101, 'اسواق مكة', NULL, '1143602273', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(102, 'مركز الاهرام للعلاج الطبيعى والتخسيس', NULL, '0233800741', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(103, 'الفا للعيادات التخصصية', NULL, '239743854', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(104, 'مركز شفا الطبى', NULL, '233968912', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(105, 'مركز تبارك للاطفال', NULL, '233800336', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(106, 'برميم للعلاج الطبيعى والتأهيل الشامل للاطفال', NULL, '233801774', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(107, 'مطعم الشرقاوى', 'مأكولات شرقية', '1126856911', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(108, 'مطعم وكافيه سبكترا', NULL, '19491', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(109, 'اكسبشن العالمية ', 'مخابز ومعجنات وحلوى محلات', '16687', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(110, 'ستار فش', 'ماكولات بحرية', '233742559', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(111, 'ع طاسة', NULL, '1200781155', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(112, 'مخبوزات أكلير', NULL, '1063203074', NULL, NULL, NULL, NULL, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(113, ' الوردة الشامية ', NULL, '1100888046', NULL, NULL, NULL, NULL, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(114, 'مخبز زغطوط', NULL, '1024697069', NULL, NULL, NULL, NULL, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(115, 'مخبز الحرمين', NULL, '1143796679', NULL, NULL, NULL, NULL, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(116, 'مخبز خير زمان', NULL, '1099353528', NULL, NULL, NULL, NULL, 0, NULL, 22, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 49, NULL, NULL, NULL, NULL, NULL),
(117, 'صيدلية الزغبى', NULL, '223824250', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(118, 'صيدلية العاصمة', NULL, '222743752', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(119, 'صيدلية علبة', NULL, '222633683', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(120, 'صيدليات العزبى', NULL, '19600', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(121, 'صيدلية البرلسى', NULL, '222622285', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(122, 'البنك التجارى الدولى - CIB', NULL, '19666', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(123, 'بنك الكويت الوطنى', NULL, '19336', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(124, 'البنك الاهلى المصرى', NULL, '19623', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(125, 'بنك الاسكندرية', NULL, '19033', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(126, 'المصرف العربى الدولى', NULL, '19604', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(127, 'تيك اواى رابعة', NULL, '222631123', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(128, 'دجاج تكا', NULL, '19099', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(129, 'توم اند بصل', NULL, '16405', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(130, 'بعلبك', NULL, '222641111', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(131, 'الدوار', NULL, '16603', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(132, 'مستشفى مدينة نصر', NULL, '222611402', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(133, 'مركز مصر لامراض الكلى', NULL, '222753508', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(134, 'مركز مصر لعلاج الاورام', NULL, '222873379', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(135, 'مركز د مجدى حسان', NULL, '1009977072', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(136, 'ابداع النخبة للاستشارات النفسية', NULL, '224035081', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(137, 'اولاد رجب', NULL, '19225', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(138, 'اسواق فاميلى', NULL, '222701800', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(139, 'اسواق المدينة', NULL, '222600267', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(140, 'الهنا فارم', NULL, '223052197', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(141, 'اسواق ام القرى', NULL, '224732732', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 89, NULL, NULL, NULL, NULL, NULL),
(142, 'صيدليات العزبى', NULL, '19600', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(143, 'صيدليات سيف', NULL, '19199', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(144, 'صيدلية د محمد فهمى مبارك', NULL, '225284428', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(145, 'صيدليات على وعلى', NULL, '19905', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(146, 'صيدلية الشعب', NULL, '223586385', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(147, 'اسواق المدينة', NULL, '225201405', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(148, 'التوحيد', NULL, '1229555975', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(149, 'الحرم الحسينى', NULL, '1005269203', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(150, 'اسواق البخارى', NULL, '1066988393', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(151, 'اسواق الحمد', NULL, '229706350', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(152, 'الدوار', NULL, '16603', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(153, 'اسماك الحرية', NULL, '225180166', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(154, 'البرجولا', NULL, '225283562', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(155, 'حضرموت المعادى', NULL, '224470999', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(156, 'ستيك اوت', NULL, '225195519', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(157, 'البنك التجارى الدولى - CIB', NULL, '19666', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(158, 'البنك العربي', NULL, '19100', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(159, 'البنك الاهلى المصرى', NULL, '225286031', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(160, 'البنك العربى الافريقى الدولى', NULL, '19555', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(161, 'بنك الشركة المصرفية العربية الدولية', NULL, '16668', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(162, 'مستشفى السلام الدولى', NULL, '19885', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(163, 'مركز القاهرة لامراض الكلى - سى كيه سى', NULL, '223598971', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(164, 'اى كير كلينيك - ا د معتز غيث', NULL, '225161313', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(165, 'بشائر الجنة', NULL, '225183849', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(166, 'المركز السويسرى الطبى بالقاهرة', NULL, '225286895', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 115, NULL, NULL, NULL, NULL, NULL),
(167, 'صيدليات ابو العز', NULL, '238522662', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(168, 'صيدلية د مها', NULL, '238360662', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(169, 'صيدلية نادى الجزيرة الرياضى', NULL, '238303269', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 55, NULL, NULL, NULL, NULL, NULL),
(170, 'صيدليات النادى', NULL, '16196', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(171, 'صيدلية د عماد', NULL, '238366263', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(172, 'بليتش بريت', NULL, '1286554914', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(173, 'مركز حياة', NULL, '238382303', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(174, 'مستشفى الصفوة - ا د سراج زكريا', NULL, '16361', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(175, 'عيادات ام القرى', NULL, '238361973', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 58, NULL, NULL, NULL, NULL, NULL),
(176, 'المركز الدولى لطب الاسنان', NULL, '1224675554', NULL, NULL, NULL, NULL, 0, NULL, 4, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 53, NULL, NULL, NULL, NULL, NULL),
(177, 'البنك التجارى الدولى', NULL, '19666', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 53, NULL, NULL, NULL, NULL, NULL),
(178, 'البنك الاهلى المصرى', NULL, '19623', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(179, 'بنك الكويت الوطنى', NULL, '19336', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(180, 'بنك الاستثمار العربى', NULL, '16697', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 45, NULL, NULL, NULL, NULL, NULL),
(181, 'البنك الاهلى المتحد', NULL, '19072', NULL, NULL, NULL, NULL, 0, NULL, 12, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 55, NULL, NULL, NULL, NULL, NULL),
(182, 'اطلانتس ريستوران اند كافيه', NULL, '16649', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(183, 'استاكوزا', NULL, '1009904401', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(184, 'حاتى ابو حمزة', NULL, '238326887', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 57, NULL, NULL, NULL, NULL, NULL),
(185, 'دجاج تكا', NULL, '19099', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(186, 'مطعم صهاريج عدن', NULL, '238358922', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 52, NULL, NULL, NULL, NULL, NULL),
(187, 'القدس', NULL, '238377386', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 54, NULL, NULL, NULL, NULL, NULL),
(188, 'تروفاليو', NULL, '238378326', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 54, NULL, NULL, NULL, NULL, NULL),
(189, 'اولاد رجب', NULL, '19225', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(190, 'سبينيس', NULL, '16005', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(191, 'اسواق العبد', NULL, '1061111292', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(192, 'صيدلية ميريهام مدحت', NULL, '1006001777', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(193, 'صييدليات رشدي', NULL, '19011', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(194, 'صيدلية شاهين', NULL, '1112420006', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(195, 'صيدلية د منى', NULL, '0101 267 3300', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(196, 'سيتروس', NULL, '233777070', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(197, 'توينكي', NULL, '02 33844307', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(198, 'اكسبشن ماركت', NULL, '02 33765528', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(199, 'سوق الرماية', NULL, '02 33776243', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(200, 'أسواق القدس', NULL, '1123858518', NULL, NULL, NULL, NULL, 0, NULL, 3, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(201, 'مشويات إكسبشن', NULL, '233765528', NULL, NULL, NULL, NULL, 0, NULL, 2, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL),
(202, 'التقوى ماركت', NULL, '1011736930', NULL, NULL, NULL, NULL, 0, NULL, 1, NULL, NULL, NULL, NULL, NULL, 67, NULL, NULL, 64, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ServiceCategory`
--

CREATE TABLE `ServiceCategory` (
  `ID` int(11) NOT NULL,
  `Name_ar` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Name_en` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `explanation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ServiceCategory`
--

INSERT INTO `ServiceCategory` (`ID`, `Name_ar`, `Name_en`, `explanation`, `Image`) VALUES
(1, 'صيدليات', NULL, NULL, NULL),
(2, 'مطاعم', NULL, NULL, NULL),
(3, 'سوبرماركت', NULL, NULL, NULL),
(4, 'أطباء / مستشفيات', NULL, NULL, NULL),
(5, 'سباك', NULL, NULL, NULL),
(6, 'كهربائي', NULL, NULL, NULL),
(7, 'ادوات صحية', NULL, NULL, NULL),
(8, 'أثاث / منجد', NULL, NULL, NULL),
(9, 'محل/سوق خضار', NULL, NULL, NULL),
(10, 'حلاق / كوافير', NULL, NULL, NULL),
(11, 'شركات اتصالات', NULL, NULL, NULL),
(12, 'بنوك / صرافة', NULL, NULL, NULL),
(13, 'كافيه / مقاهي', NULL, NULL, NULL),
(14, 'نقاشة / ديكور', NULL, NULL, NULL),
(15, 'مرافق وخدمات حكومية', NULL, NULL, NULL),
(16, 'سواقين / نقل', NULL, NULL, NULL),
(17, 'عمال مشال', NULL, NULL, NULL),
(18, 'نظافة', NULL, NULL, NULL),
(19, 'أمن / حراسة', NULL, NULL, NULL),
(20, 'شرطة', NULL, NULL, NULL),
(21, 'مواقف مواصلات', NULL, NULL, NULL),
(22, 'مخبز', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Status`
--

CREATE TABLE `Status` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explanation` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Status`
--

INSERT INTO `Status` (`ID`, `Name`, `Explanation`) VALUES
(1, 'Binding', 'Waiting for confirmation from block manager'),
(2, 'Active', 'activated and confirmed by block manager'),
(3, 'Banned', 'Banned by Super Admin'),
(4, 'Annually', 'Repeat Annually (Per Year)'),
(5, 'Monthly', 'Repeat Monthly (Per Month)'),
(6, 'Weekly', 'Repeat Weekly (Per Week)'),
(7, 'Daily', 'Repeat Daily (Per Day)'),
(8, 'ساكنة', 'لها مالك ويوجد بها سكان'),
(9, 'مغلقة', 'لها مالك لكن ليس بها سكان'),
(10, 'تحت التشطيب', 'غير قابلة للسكن');

-- --------------------------------------------------------

--
-- Table structure for table `Street`
--

CREATE TABLE `Street` (
  `ID` int(11) NOT NULL,
  `StreetName` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NumOfBlocks` int(11) DEFAULT NULL,
  `CountryID` int(11) DEFAULT NULL,
  `GovID` int(11) DEFAULT NULL,
  `CityID` int(11) DEFAULT NULL,
  `RegionID` int(11) DEFAULT NULL,
  `CompundID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Street`
--

INSERT INTO `Street` (`ID`, `StreetName`, `NumOfBlocks`, `CountryID`, `GovID`, `CityID`, `RegionID`, `CompundID`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'الثروة المعدنية', 100, 2, 2, 2, 4, 1),
(3, 'سوق الثلاثاء القديم', NULL, 67, 17, 8, 4, 1),
(4, '26 يوليو', NULL, 67, 17, 8, 4, 1),
(5, '26 يوليو', NULL, 67, 7, 9, 4, 1),
(6, '26 يوليو', NULL, 67, 7, 9, 7, 1),
(7, 'الجمهورية', NULL, 67, 16, 10, 8, 1),
(8, 'سوق الثلاثاء القديم', NULL, 67, 7, 11, 9, 1),
(9, 'جامع خاطر', NULL, 67, 7, 11, 9, 1),
(10, 'البهواشي', NULL, 67, 7, 11, 9, 1),
(11, 'الشيمي', NULL, 67, 16, 10, 8, 1),
(12, 'الجيش', NULL, 67, 16, 10, 8, 1),
(13, 'test', NULL, 67, 16, 10, 8, 1),
(14, 'test1', NULL, 67, 16, 10, 8, 1),
(15, 'test2', NULL, 67, 16, 10, 8, 1),
(16, 'test2', NULL, 67, 16, 10, 8, 4),
(17, 'test', NULL, 67, 18, 12, 10, 5),
(36, 'test1', NULL, 67, 36, 31, 29, 24),
(37, 'test2', NULL, 67, 37, 32, 30, 25),
(38, 'test3', NULL, 67, 38, 33, 31, 26),
(39, 'test4', NULL, 67, 38, 33, 31, 26),
(40, 'test5', NULL, 67, 38, 33, 31, 26),
(41, 'test6', NULL, 67, 39, 34, 32, 27),
(42, 'test7', NULL, 67, 40, 35, 33, 28),
(43, 'test8', NULL, 67, 41, 36, 34, 29),
(44, 'ابوقير البحري', NULL, 67, 42, 37, 35, 1),
(45, 'ابوقير', NULL, 67, 42, 37, 35, 1),
(46, 'ابوقير1', NULL, 67, 42, 37, 35, 1),
(47, 'القدس', NULL, 67, 8, 6, 5, 29),
(48, 'bay', NULL, 240, 43, 38, 36, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Subscription`
--

CREATE TABLE `Subscription` (
  `ID` int(11) NOT NULL,
  `Sub_Name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Explanation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Sub_Date` date DEFAULT NULL,
  `PricePerMonth` int(11) DEFAULT NULL,
  `PricePerYear` int(11) DEFAULT NULL,
  `PeriodByMonth` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `Suggestion`
--

CREATE TABLE `Suggestion` (
  `ID` int(11) NOT NULL,
  `Suggest` text COLLATE utf8_unicode_ci,
  `Likes` int(11) NOT NULL,
  `DisLikes` int(11) NOT NULL,
  `ResidentID` int(11) DEFAULT NULL,
  `ApartmentID` int(11) DEFAULT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `Date` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CreatedAt` datetime DEFAULT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `UpdatedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `Suggestion`
--

INSERT INTO `Suggestion` (`ID`, `Suggest`, `Likes`, `DisLikes`, `ResidentID`, `ApartmentID`, `BlockID`, `Date`, `CreatedAt`, `UpdatedAt`, `UpdatedBy`) VALUES
(1, 'Test 1 waheed', 0, 0, 1, 2, 1, '2023-02-18 02-04-26am', '2023-02-18 02:04:26', NULL, NULL),
(2, 'Suggestion', 0, 1, 26, 77, 73, '2023-03-06 08-01-35pm', '2023-03-06 20:01:35', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SuperAdmin`
--

CREATE TABLE `SuperAdmin` (
  `ID` int(11) NOT NULL,
  `Fname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Lname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Username` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Password` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PhoneNum` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `SuperAdmin`
--

INSERT INTO `SuperAdmin` (`ID`, `Fname`, `Lname`, `Username`, `Email`, `Password`, `PhoneNum`) VALUES
(1, 'محمد', 'وحيد', 'MohamedWaheed531', 'mohamed@GMAIL.COM', 'AJHALJKHLA', 1144338618);

-- --------------------------------------------------------

--
-- Table structure for table `Voting`
--

CREATE TABLE `Voting` (
  `ID` int(11) NOT NULL,
  `Cause` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Infavour` int(11) DEFAULT NULL,
  `Opposed` int(11) DEFAULT NULL,
  `Choice` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MeetingID` int(11) NOT NULL,
  `BlockID` int(11) DEFAULT NULL,
  `BlockManagerID` int(11) DEFAULT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AdsAndOffers`
--
ALTER TABLE `AdsAndOffers`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `StatusID` (`StatusID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovernateID` (`GovernateID`),
  ADD KEY `CityID` (`CityID`),
  ADD KEY `RegionID` (`RegionID`),
  ADD KEY `CompoundID` (`CompoundID`),
  ADD KEY `StreetID` (`StreetID`);

--
-- Indexes for table `Apartment`
--
ALTER TABLE `Apartment`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `StatusID` (`StatusID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Attendees`
--
ALTER TABLE `Attendees`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `BILL`
--
ALTER TABLE `BILL`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Block` (`Block`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `FK_BillApartment2` (`Apartment`),
  ADD KEY `PaymentID` (`PaymentID`);

--
-- Indexes for table `Block`
--
ALTER TABLE `Block`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `FK_GovID` (`GovernateID`),
  ADD KEY `FK_CITYID` (`CityID`),
  ADD KEY `FK_RegionID` (`RegionID`),
  ADD KEY `FK_CompoundID` (`CompoundID`),
  ADD KEY `FK_StreetID` (`StreetID`),
  ADD KEY `StatusID` (`StatusID`);

--
-- Indexes for table `BlockManager`
--
ALTER TABLE `BlockManager`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`);

--
-- Indexes for table `BlockPaymentMethod`
--
ALTER TABLE `BlockPaymentMethod`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Cashier`
--
ALTER TABLE `Cashier`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`);

--
-- Indexes for table `Chat`
--
ALTER TABLE `Chat`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `City`
--
ALTER TABLE `City`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovID` (`GovID`);

--
-- Indexes for table `Comment`
--
ALTER TABLE `Comment`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Compound`
--
ALTER TABLE `Compound`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovID` (`GovID`),
  ADD KEY `CityID` (`CityID`),
  ADD KEY `RegionID` (`RegionID`);

--
-- Indexes for table `Country`
--
ALTER TABLE `Country`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Decision`
--
ALTER TABLE `Decision`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `BlockManagerID` (`BlockManagerID`),
  ADD KEY `MeetingID` (`MeetingID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Emails`
--
ALTER TABLE `Emails`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ServiceID` (`ServiceID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Event`
--
ALTER TABLE `Event`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Expense`
--
ALTER TABLE `Expense`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Favourite`
--
ALTER TABLE `Favourite`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CategoryID` (`CategoryID`),
  ADD KEY `ServiceID` (`ServiceID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `NeighbourID` (`NeighbourID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Fee`
--
ALTER TABLE `Fee`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BillID` (`BillID`),
  ADD KEY `ExpenseID` (`ExpenseID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `PaymentMethod` (`PaymentMethod`),
  ADD KEY `CashierID` (`CashierID`),
  ADD KEY `RepeatStatusID` (`RepeatStatusID`);

--
-- Indexes for table `FinancialAcount`
--
ALTER TABLE `FinancialAcount`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `FinancialLog`
--
ALTER TABLE `FinancialLog`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `LogTypeID` (`LogTypeID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `PaymentID` (`PaymentID`);

--
-- Indexes for table `Governate`
--
ALTER TABLE `Governate`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`);

--
-- Indexes for table `Income`
--
ALTER TABLE `Income`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BillID` (`BillID`),
  ADD KEY `FinancialAcountID` (`FinancialAcountID`),
  ADD KEY `PaymentID` (`PaymentID`),
  ADD KEY `ResidentID` (`ResidentID`);

--
-- Indexes for table `Likes`
--
ALTER TABLE `Likes`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `Logs`
--
ALTER TABLE `Logs`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `LogTypeID` (`LogTypeID`);

--
-- Indexes for table `LogType`
--
ALTER TABLE `LogType`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Meeting`
--
ALTER TABLE `Meeting`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `BlockManagerID` (`BlockManagerID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `MeetingAttach`
--
ALTER TABLE `MeetingAttach`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `MemberOfTheBoard`
--
ALTER TABLE `MemberOfTheBoard`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `Message`
--
ALTER TABLE `Message`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SenderID` (`SenderID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `News`
--
ALTER TABLE `News`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Notification`
--
ALTER TABLE `Notification`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `NotifSettings`
--
ALTER TABLE `NotifSettings`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `ExpenseID` (`ExpenseID`),
  ADD KEY `BillID` (`BillID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `FeeID` (`FeeID`),
  ADD KEY `MethodID` (`MethodID`),
  ADD KEY `CreatedBy` (`CreatedBy`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `PaymentMethods`
--
ALTER TABLE `PaymentMethods`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`);

--
-- Indexes for table `Permission`
--
ALTER TABLE `Permission`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `PhoneNums`
--
ALTER TABLE `PhoneNums`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `ServiceID` (`ServiceID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Rates`
--
ALTER TABLE `Rates`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `ServiceID` (`ServiceID`);

--
-- Indexes for table `Region`
--
ALTER TABLE `Region`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovID` (`GovID`),
  ADD KEY `CityID` (`CityID`);

--
-- Indexes for table `Resident_Devices_Tokens`
--
ALTER TABLE `Resident_Devices_Tokens`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`);

--
-- Indexes for table `Resident_Subscription`
--
ALTER TABLE `Resident_Subscription`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `SubscriptionID` (`SubscriptionID`);

--
-- Indexes for table `Resident_User`
--
ALTER TABLE `Resident_User`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `PhoneNum` (`PhoneNum`),
  ADD KEY `StatusID` (`StatusID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `Restrection`
--
ALTER TABLE `Restrection`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `SubscriptionID` (`SubscriptionID`);

--
-- Indexes for table `RES_APART_BLOCK_ROLE`
--
ALTER TABLE `RES_APART_BLOCK_ROLE`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `RoleID` (`RoleID`),
  ADD KEY `StatusID` (`StatusID`),
  ADD KEY `ResidentID` (`ResidentID`);

--
-- Indexes for table `Role`
--
ALTER TABLE `Role`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Role_Permissions`
--
ALTER TABLE `Role_Permissions`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `RoleID` (`RoleID`),
  ADD KEY `PermissionID` (`PermissionID`);

--
-- Indexes for table `Service`
--
ALTER TABLE `Service`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CategoryID` (`CategoryID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovernateID` (`GovernateID`),
  ADD KEY `CityID` (`CityID`),
  ADD KEY `RegionID` (`RegionID`),
  ADD KEY `StreetID` (`StreetID`),
  ADD KEY `FK_Service_Compound` (`CompoundID`);

--
-- Indexes for table `ServiceCategory`
--
ALTER TABLE `ServiceCategory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Status`
--
ALTER TABLE `Status`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Street`
--
ALTER TABLE `Street`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `CountryID` (`CountryID`),
  ADD KEY `GovID` (`GovID`),
  ADD KEY `RegionID` (`RegionID`),
  ADD KEY `CityID` (`CityID`);

--
-- Indexes for table `Subscription`
--
ALTER TABLE `Subscription`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Suggestion`
--
ALTER TABLE `Suggestion`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `ResidentID` (`ResidentID`),
  ADD KEY `ApartmentID` (`ApartmentID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `UpdatedBy` (`UpdatedBy`);

--
-- Indexes for table `SuperAdmin`
--
ALTER TABLE `SuperAdmin`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `PhoneNum` (`PhoneNum`);

--
-- Indexes for table `Voting`
--
ALTER TABLE `Voting`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `BlockID` (`BlockID`),
  ADD KEY `BlockManagerID` (`BlockManagerID`),
  ADD KEY `MeetingID` (`MeetingID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AdsAndOffers`
--
ALTER TABLE `AdsAndOffers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `Apartment`
--
ALTER TABLE `Apartment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `Attendees`
--
ALTER TABLE `Attendees`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `Block`
--
ALTER TABLE `Block`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `BlockManager`
--
ALTER TABLE `BlockManager`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `BlockPaymentMethod`
--
ALTER TABLE `BlockPaymentMethod`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Cashier`
--
ALTER TABLE `Cashier`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Chat`
--
ALTER TABLE `Chat`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `City`
--
ALTER TABLE `City`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `Comment`
--
ALTER TABLE `Comment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `Complaint`
--
ALTER TABLE `Complaint`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `Compound`
--
ALTER TABLE `Compound`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `Country`
--
ALTER TABLE `Country`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=254;

--
-- AUTO_INCREMENT for table `Decision`
--
ALTER TABLE `Decision`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `Emails`
--
ALTER TABLE `Emails`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `Event`
--
ALTER TABLE `Event`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `Expense`
--
ALTER TABLE `Expense`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Favourite`
--
ALTER TABLE `Favourite`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `Fee`
--
ALTER TABLE `Fee`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `FinancialAcount`
--
ALTER TABLE `FinancialAcount`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `FinancialLog`
--
ALTER TABLE `FinancialLog`
  MODIFY `ID` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `Governate`
--
ALTER TABLE `Governate`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `Income`
--
ALTER TABLE `Income`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Likes`
--
ALTER TABLE `Likes`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `Logs`
--
ALTER TABLE `Logs`
  MODIFY `ID` double NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=379;

--
-- AUTO_INCREMENT for table `LogType`
--
ALTER TABLE `LogType`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `Meeting`
--
ALTER TABLE `Meeting`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `MeetingAttach`
--
ALTER TABLE `MeetingAttach`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `MemberOfTheBoard`
--
ALTER TABLE `MemberOfTheBoard`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Message`
--
ALTER TABLE `Message`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `News`
--
ALTER TABLE `News`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `Notification`
--
ALTER TABLE `Notification`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `NotifSettings`
--
ALTER TABLE `NotifSettings`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `Payment`
--
ALTER TABLE `Payment`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `PaymentMethods`
--
ALTER TABLE `PaymentMethods`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Permission`
--
ALTER TABLE `Permission`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `PhoneNums`
--
ALTER TABLE `PhoneNums`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `Rates`
--
ALTER TABLE `Rates`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `Region`
--
ALTER TABLE `Region`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `Resident_Devices_Tokens`
--
ALTER TABLE `Resident_Devices_Tokens`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `Resident_Subscription`
--
ALTER TABLE `Resident_Subscription`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Resident_User`
--
ALTER TABLE `Resident_User`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `Restrection`
--
ALTER TABLE `Restrection`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `RES_APART_BLOCK_ROLE`
--
ALTER TABLE `RES_APART_BLOCK_ROLE`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `Role`
--
ALTER TABLE `Role`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Role_Permissions`
--
ALTER TABLE `Role_Permissions`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Service`
--
ALTER TABLE `Service`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `ServiceCategory`
--
ALTER TABLE `ServiceCategory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `Status`
--
ALTER TABLE `Status`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `Street`
--
ALTER TABLE `Street`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `Subscription`
--
ALTER TABLE `Subscription`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Suggestion`
--
ALTER TABLE `Suggestion`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `SuperAdmin`
--
ALTER TABLE `SuperAdmin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Voting`
--
ALTER TABLE `Voting`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `AdsAndOffers`
--
ALTER TABLE `AdsAndOffers`
  ADD CONSTRAINT `AdsAndOffers_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_10` FOREIGN KEY (`CompoundID`) REFERENCES `Compound` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_11` FOREIGN KEY (`StreetID`) REFERENCES `Street` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_3` FOREIGN KEY (`StatusID`) REFERENCES `Status` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_4` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_5` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_6` FOREIGN KEY (`CountryID`) REFERENCES `Country` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_7` FOREIGN KEY (`GovernateID`) REFERENCES `Governate` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_8` FOREIGN KEY (`CityID`) REFERENCES `City` (`ID`),
  ADD CONSTRAINT `AdsAndOffers_ibfk_9` FOREIGN KEY (`RegionID`) REFERENCES `Region` (`ID`);

--
-- Constraints for table `Apartment`
--
ALTER TABLE `Apartment`
  ADD CONSTRAINT `Apartment_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Apartment_ibfk_2` FOREIGN KEY (`StatusID`) REFERENCES `Status` (`ID`),
  ADD CONSTRAINT `Apartment_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Attendees`
--
ALTER TABLE `Attendees`
  ADD CONSTRAINT `Attendees_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Attendees_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Attendees_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Attendees_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `BILL`
--
ALTER TABLE `BILL`
  ADD CONSTRAINT `BILL_ibfk_1` FOREIGN KEY (`Block`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `BILL_ibfk_2` FOREIGN KEY (`Block`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `BILL_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `BILL_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `BILL_ibfk_5` FOREIGN KEY (`PaymentID`) REFERENCES `Payment` (`ID`),
  ADD CONSTRAINT `FK_BillApartment2` FOREIGN KEY (`Apartment`) REFERENCES `Apartment` (`ID`);

--
-- Constraints for table `Block`
--
ALTER TABLE `Block`
  ADD CONSTRAINT `Block_ibfk_1` FOREIGN KEY (`CountryID`) REFERENCES `Country` (`ID`),
  ADD CONSTRAINT `Block_ibfk_2` FOREIGN KEY (`StatusID`) REFERENCES `Status` (`ID`),
  ADD CONSTRAINT `FK_CITYID` FOREIGN KEY (`CityID`) REFERENCES `City` (`ID`),
  ADD CONSTRAINT `FK_CompoundID` FOREIGN KEY (`CompoundID`) REFERENCES `Compound` (`ID`),
  ADD CONSTRAINT `FK_GovID` FOREIGN KEY (`GovernateID`) REFERENCES `Governate` (`ID`),
  ADD CONSTRAINT `FK_RegionID` FOREIGN KEY (`RegionID`) REFERENCES `Region` (`ID`),
  ADD CONSTRAINT `FK_StreetID` FOREIGN KEY (`StreetID`) REFERENCES `Street` (`ID`);

--
-- Constraints for table `BlockPaymentMethod`
--
ALTER TABLE `BlockPaymentMethod`
  ADD CONSTRAINT `BlockPaymentMethod_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `BlockPaymentMethod_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `BlockPaymentMethod_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Chat`
--
ALTER TABLE `Chat`
  ADD CONSTRAINT `Chat_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Comment`
--
ALTER TABLE `Comment`
  ADD CONSTRAINT `Comment_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Comment_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Comment_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Comment_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Complaint`
--
ALTER TABLE `Complaint`
  ADD CONSTRAINT `Complaint_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Complaint_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Complaint_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Complaint_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Decision`
--
ALTER TABLE `Decision`
  ADD CONSTRAINT `Decision_ibfk_1` FOREIGN KEY (`BlockManagerID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_3` FOREIGN KEY (`MeetingID`) REFERENCES `Meeting` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_4` FOREIGN KEY (`BlockManagerID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_5` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_6` FOREIGN KEY (`MeetingID`) REFERENCES `Meeting` (`ID`),
  ADD CONSTRAINT `Decision_ibfk_7` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Emails`
--
ALTER TABLE `Emails`
  ADD CONSTRAINT `Emails_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Emails_ibfk_2` FOREIGN KEY (`ServiceID`) REFERENCES `Service` (`ID`),
  ADD CONSTRAINT `Emails_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Event`
--
ALTER TABLE `Event`
  ADD CONSTRAINT `Event_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Event_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Event_ibfk_3` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Event_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Event_ibfk_5` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Event_ibfk_6` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Favourite`
--
ALTER TABLE `Favourite`
  ADD CONSTRAINT `Favourite_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_5` FOREIGN KEY (`CategoryID`) REFERENCES `ServiceCategory` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_6` FOREIGN KEY (`ServiceID`) REFERENCES `Service` (`ID`),
  ADD CONSTRAINT `Favourite_ibfk_7` FOREIGN KEY (`NeighbourID`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Fee`
--
ALTER TABLE `Fee`
  ADD CONSTRAINT `Fee_ibfk_1` FOREIGN KEY (`ExpenseID`) REFERENCES `Expense` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_2` FOREIGN KEY (`CashierID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_3` FOREIGN KEY (`CreatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_5` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_6` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Fee_ibfk_7` FOREIGN KEY (`RepeatStatusID`) REFERENCES `Status` (`ID`);

--
-- Constraints for table `FinancialAcount`
--
ALTER TABLE `FinancialAcount`
  ADD CONSTRAINT `FinancialAcount_ibfk_1` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `FinancialAcount_ibfk_2` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `FinancialAcount_ibfk_3` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `FinancialAcount_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `FinancialLog`
--
ALTER TABLE `FinancialLog`
  ADD CONSTRAINT `FinancialLog_ibfk_1` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_10` FOREIGN KEY (`LogTypeID`) REFERENCES `LogType` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_11` FOREIGN KEY (`PaymentID`) REFERENCES `Payment` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_2` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_3` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_5` FOREIGN KEY (`LogTypeID`) REFERENCES `LogType` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_6` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_7` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_8` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `FinancialLog_ibfk_9` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Likes`
--
ALTER TABLE `Likes`
  ADD CONSTRAINT `Likes_ibfk_1` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Likes_ibfk_2` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Likes_ibfk_3` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Likes_ibfk_4` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Logs`
--
ALTER TABLE `Logs`
  ADD CONSTRAINT `Logs_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_2` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_3` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_4` FOREIGN KEY (`LogTypeID`) REFERENCES `LogType` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_6` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_7` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Logs_ibfk_8` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Meeting`
--
ALTER TABLE `Meeting`
  ADD CONSTRAINT `Meeting_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Meeting_ibfk_2` FOREIGN KEY (`BlockManagerID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Meeting_ibfk_3` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Meeting_ibfk_4` FOREIGN KEY (`BlockManagerID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Meeting_ibfk_5` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Meeting_ibfk_6` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Message`
--
ALTER TABLE `Message`
  ADD CONSTRAINT `Message_ibfk_1` FOREIGN KEY (`SenderID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Message_ibfk_2` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Message_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Message_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `News`
--
ALTER TABLE `News`
  ADD CONSTRAINT `News_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `News_ibfk_2` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `News_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `News_ibfk_4` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `News_ibfk_5` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `NotifSettings`
--
ALTER TABLE `NotifSettings`
  ADD CONSTRAINT `NotifSettings_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `NotifSettings_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Payment`
--
ALTER TABLE `Payment`
  ADD CONSTRAINT `Payment_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_10` FOREIGN KEY (`ExpenseID`) REFERENCES `Expense` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_2` FOREIGN KEY (`CreatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_4` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_5` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_6` FOREIGN KEY (`MethodID`) REFERENCES `PaymentMethods` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_7` FOREIGN KEY (`FeeID`) REFERENCES `Fee` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_8` FOREIGN KEY (`BillID`) REFERENCES `BILL` (`ID`),
  ADD CONSTRAINT `Payment_ibfk_9` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `PaymentMethods`
--
ALTER TABLE `PaymentMethods`
  ADD CONSTRAINT `PaymentMethods_ibfk_1` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `PhoneNums`
--
ALTER TABLE `PhoneNums`
  ADD CONSTRAINT `PhoneNums_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `PhoneNums_ibfk_2` FOREIGN KEY (`ServiceID`) REFERENCES `Service` (`ID`),
  ADD CONSTRAINT `PhoneNums_ibfk_3` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Rates`
--
ALTER TABLE `Rates`
  ADD CONSTRAINT `Rates_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_5` FOREIGN KEY (`ServiceID`) REFERENCES `Service` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_6` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_7` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_8` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Rates_ibfk_9` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`);

--
-- Constraints for table `Resident_Devices_Tokens`
--
ALTER TABLE `Resident_Devices_Tokens`
  ADD CONSTRAINT `Resident_Devices_Tokens_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `Resident_User`
--
ALTER TABLE `Resident_User`
  ADD CONSTRAINT `Resident_User_ibfk_1` FOREIGN KEY (`StatusID`) REFERENCES `Status` (`ID`),
  ADD CONSTRAINT `Resident_User_ibfk_2` FOREIGN KEY (`UpdatedBy`) REFERENCES `Resident_User` (`ID`);

--
-- Constraints for table `RES_APART_BLOCK_ROLE`
--
ALTER TABLE `RES_APART_BLOCK_ROLE`
  ADD CONSTRAINT `RES_APART_BLOCK_ROLE_ibfk_1` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `RES_APART_BLOCK_ROLE_ibfk_2` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `RES_APART_BLOCK_ROLE_ibfk_3` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `RES_APART_BLOCK_ROLE_ibfk_4` FOREIGN KEY (`RoleID`) REFERENCES `Role` (`ID`),
  ADD CONSTRAINT `RES_APART_BLOCK_ROLE_ibfk_5` FOREIGN KEY (`StatusID`) REFERENCES `Status` (`ID`);

--
-- Constraints for table `Service`
--
ALTER TABLE `Service`
  ADD CONSTRAINT `Service_ibfk_1` FOREIGN KEY (`CategoryID`) REFERENCES `ServiceCategory` (`ID`),
  ADD CONSTRAINT `Service_ibfk_10` FOREIGN KEY (`StreetID`) REFERENCES `Street` (`ID`),
  ADD CONSTRAINT `Service_ibfk_2` FOREIGN KEY (`ResidentID`) REFERENCES `Resident_User` (`ID`),
  ADD CONSTRAINT `Service_ibfk_3` FOREIGN KEY (`ApartmentID`) REFERENCES `Apartment` (`ID`),
  ADD CONSTRAINT `Service_ibfk_4` FOREIGN KEY (`BlockID`) REFERENCES `Block` (`ID`),
  ADD CONSTRAINT `Service_ibfk_5` FOREIGN KEY (`CountryID`) REFERENCES `Country` (`ID`),
  ADD CONSTRAINT `Service_ibfk_6` FOREIGN KEY (`GovernateID`) REFERENCES `Governate` (`ID`),
  ADD CONSTRAINT `Service_ibfk_7` FOREIGN KEY (`CityID`) REFERENCES `City` (`ID`),
  ADD CONSTRAINT `Service_ibfk_8` FOREIGN KEY (`RegionID`) REFERENCES `Region` (`ID`),
  ADD CONSTRAINT `Service_ibfk_9` FOREIGN KEY (`CompoundID`) REFERENCES `Compound` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
